INSERT INTO users (name, email, framework) VALUES ('mkyong', 'mkyong@gmail.com', 'Spring MVC, GWT');
INSERT INTO users (name, email, framework) VALUES ('alex', 'alex@yahoo.com', 'Spring MVC, PLAY');
INSERT INTO users (name, email, framework) VALUES ('joel', 'joel@gmail.com', 'Spring MVC, JSF 2');
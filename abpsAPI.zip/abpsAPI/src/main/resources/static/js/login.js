$(function(){
	$.support.cors = true;

	$('#Done').on('click',function(){
	
		if($.ageValidation()){
			
			var requestData={};
			$('input[name],select[name]').each(function(){
				requestData[$(this).attr('name')] = $(this).val();
			});

			$.ajax({
				type:"POST",	
				url: "http://localhost:8080/IPLoginController/authorize",
				contentType:"text/html",
				data: JSON.stringify(requestData),
				success:function(data){
					alert(data.message);
					var message = data.message;
					if(message=="success"){
						var href = 'index.html';
						window.location.href = href ;
					}					
				},
				error:function(data){
					alert("error");
				}
			});

		}

	});

}) 
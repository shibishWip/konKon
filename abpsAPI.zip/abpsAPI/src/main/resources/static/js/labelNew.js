$(document).ready(function($http){
	$.support.cors = true;
	
	var labels = "";
	$('label[for]').each(function(){
		labels = labels + "," + $(this).attr('for') ;			
	});
	labels = labels.substring(1);

	var codeIndex = "";
	$('select[codeIndex]').each(function(){
		codeIndex = codeIndex + "," + $(this).attr('codeIndex') ;			
	});
	codeIndex = codeIndex.substring(1);
	

	var labelData = {};
	var codeIndexData = {};
	var requestData = {};

	labelData['key'] ="0:en";
	labelData['value'] = labels;
	labelData['type'] = "LIT";

	codeIndexData['key'] = codeIndex;
	codeIndexData['value'] = codeIndex;
	codeIndexData['type'] = "CVT";

	
	requestData['labels'] = labelData;
	requestData['codeIndex'] = codeIndexData;

	
	$.ajax({
			type:"POST",	
			url: "http://localhost:8080/IPLabelsUtility/getLabels",
			contentType:"text/html",
			data: JSON.stringify(requestData),
			success:function(data){
	
				var labelOutput = data.labelOutput;
	
				$('label[for]').each(function(){
					this.innerHTML = labelOutput[$(this).attr('for')] ;		
				 });
			},
			error:function(data){
				alert("eror");
			}
		});		
});
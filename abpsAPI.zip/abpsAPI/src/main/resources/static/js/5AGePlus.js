$.extend({
	trimAll:function(option){
		var param = option + '';
		var result = '';
		if((typeof param == 'string')&&(param.constructor == String)){
			var strArray = param.split(' ');
			if(strArray.length > 0){
				for(var i in strArray){
					result += strArray[i];
				}
			}
		}
		return result;
	},
	resetMenu:function(options){
		var width = 1,CC = 1,maxwidth = 0,objectMenuUL = document.getElementsByClassName('header-main-ul')[0];
		if(document.getElementsByClassName('header-main-ul').length > 0){
			if(options !== undefined){
				if(options.width !== undefined){
					width = option*1;
				}
				if(options.CC !== undefined){
					CC = options.CC*1;
				}
			}
			$('.header-menu-float-left').on('mouseenter',function(){
				var moveL = function(thisE,CC,width,maxwidth){
					if(CC>0){
						CC-=1;
						$(thisE).next().scrollLeft(width*CC);
						setTimeout(moveL($(thisE),CC,width,maxwidth),1000);
					};
				}
				moveL($(this),CC,width,maxwidth);
			})
			$('.header-menu-float-right').on('mouseenter',function(){
				var moveR = function(thisE,CC,width,maxwidth){
					if(width*(CC) <= maxwidth){
						CC+=1;
						$(thisE).prev().scrollLeft(width*CC);
						setTimeout(moveR($(thisE),CC,width,maxwidth),1000);
					}
				}
				moveR($(this),CC,width,maxwidth);
			})
			if(window.innerWidth > 980){
				if($('.header-main-ul').hasClass('header-main-ul-moreWidth')){
					if(window.innerWidth > 1170){
						$('.header-main-ul').removeClass('header-main-ul-moreWidth');
						if($('.header-main-ul').width() > ($('.header-main').width() - $('.header-logo').width() - $('.header-userinfo').width() - 20)){
							$('.header-main-ul').addClass('header-main-ul-moreWidth');
							objectMenuUL.style.overflow = 'auto';
							maxwidth = objectMenuUL.scrollWidth - $('.header-main-ul').parent().width();
							objectMenuUL.style.overflow = 'hidden';
							$('.header-menu-float').show();
						}else{
							$('.header-main-ul').removeClass('header-main-ul-moreWidth');
							$('.header-menu-float').hide();
						}
					}
				}else{
					if($('.header-main-ul').width() > ($('.header-main').width() - $('.header-logo').width() - $('.header-userinfo').width() - 20)){
						$('.header-main-ul').addClass('header-main-ul-moreWidth');
						objectMenuUL.style.overflow = 'auto';
						maxwidth = objectMenuUL.scrollWidth - $('.header-main-ul').parent().width();
						objectMenuUL.style.overflow = 'hidden';
						$('.header-menu-float').show();
					}else{
						$('.header-main-ul').removeClass('header-main-ul-moreWidth');
						$('.header-menu-float').hide();
					}
				}
			}else{
				$('.header-main-ul').removeClass('header-main-ul-moreWidth');
				$('.header-menu-float').hide();
			}
		}
	},
	ageValidation:function(options){
		var obj = {
			elementValue:'',
			elementType:'',
			elementCheck:{
				mandatory:false,
				tpye:'',
				length:[0,2],
				message:''
			}
		}
		var resultFlag = true;
		var messages = {
			mandatory:'This can not be empty.',
			larger:'You can not type longer than',
			lesser:'You can not type lesser than',
			length:'The length should between &&& and &&&',
			date:'Only date allowed, format ddMMMyyyy',
			number:'Only number allowed',
			max:'larger than max value ',
			min:'lesser than min value ',
			decimal:'decimal length should be '
		}
		if(options){
			$.extend(obj,options);
			
		}else{
			var errorDiv = $('<div class="age-valid-info"><span id="age-valid-message"></span></div>');
			$('[data-ageValid-type]').each(function(){
				$(this).on('change keyup',function(){
					var objectE = this;
					if($(objectE).parent().find('.age-valid-info').length > 0){
						$(objectE).parent().find('.age-valid-info').remove();
					}
					validFunction(objectE);
				});
				var objectE = this;
				var validFunction = function(param){
					var messagesTemp = messages;
					var inputValue = $.trim($(param).val());
					if($(param).attr('data-ageValid-message')){
						var temp = 't='+$(param).attr('data-ageValid-message');
						temp = eval(temp);
						$.extend(messagesTemp,temp);
					}
					if($(param).attr('data-ageValid-mandatory')){
						if(inputValue == ''){
							$(errorDiv).css({
								'top':$(param).position().top+36,
								'left':$(param).position().left+5
							}).find('#age-valid-message').text(messagesTemp.mandatory);
							$(param).parent().append(errorDiv);
							$(param).focus();
							resultFlag = false;
							return;
						}
					}
					var lengthList = [];
					if($(param).attr('data-ageValid-length')){
						lengthList = $(param).attr('data-ageValid-length').split(',');
						if(lengthList.length == 1){
							lengthList[1] = lengthList[0];
							lengthList[0] = 0;
						}else if($.trimAll(lengthList[0]).length == 0 || lengthList[0] == null || lengthList[0] <= 0){
							lengthList[0] = 0;
						}
					}
					var type = $(param).attr('data-ageValid-type');
					if(type=='d' && inputValue){
						var ddMMMyyyy = /^((0[1-9])|([1-2]\d{1})|(3[01]{1}))(Jan|Feb|Mar|Apr|Maj|Jun|Jul|Aug|Sep|Oct|Nov|Dec){1}([12]\d{3})$/;
						if(!ddMMMyyyy.test(inputValue)){
							$(errorDiv).css({
								'top':$(param).position().top+36,
								'left':$(param).position().left+5
							}).find('#age-valid-message').text(messagesTemp.date);
							$(param).parent().append(errorDiv);
							$(param).focus();
							resultFlag = false;
							return;
						}
					}else if(type=='f' && inputValue){
						if(!/^\d{0,}(\.?)\d{0,}$/.test(inputValue)){
							$(errorDiv).css({
								'top':$(param).position().top+36,
								'left':$(param).position().left+5
							}).find('#age-valid-message').text(messagesTemp.number);
							$(param).parent().append(errorDiv);
							$(param).focus();
							resultFlag = false;
							return;
						}else if(!/^[1-9]{1}\d{0,6}((\.\d{0,4}[1-9]{1})?)$/.test(inputValue) && $(param).attr('data-ageValid-decimal')){
							$(errorDiv).css({
									'top':$(param).position().top+36,
									'left':$(param).position().left+5
								}).find('#age-valid-message').text(messagesTemp.decimal + $(param).attr('data-ageValid-decimal'));
								$(param).parent().append(errorDiv);
								$(param).focus();
								resultFlag = false;
								return;
						}else if($(param).attr('data-ageValid-max') && parseFloat(inputValue) > $(param).attr('data-ageValid-max')){
							$(errorDiv).css({
									'top':$(param).position().top+36,
									'left':$(param).position().left+5
								}).find('#age-valid-message').text(messagesTemp.max + $(param).attr('data-ageValid-max'));
								$(param).parent().append(errorDiv);
								$(param).focus();
								resultFlag = false;
								return;
						}else if($(param).attr('data-ageValid-min') && parseFloat(inputValue) < $(param).attr('data-ageValid-min')){
							$(errorDiv).css({
									'top':$(param).position().top+36,
									'left':$(param).position().left+5
								}).find('#age-valid-message').text(messagesTemp.min + $(param).attr('data-ageValid-min'));
								$(param).parent().append(errorDiv);
								$(param).focus();
								resultFlag = false;
								return;
						}
					}else if(type=='n' && inputValue){
						if(!RegExp('^\\d{0,}$').test(inputValue)){
							$(errorDiv).css({
								'top':$(param).position().top+36,
								'left':$(param).position().left+5
							}).find('#age-valid-message').text(messagesTemp.number);
							$(param).parent().append(errorDiv);
							$(param).focus();
							resultFlag = false;
							return;
						}
					}
					
					if($(param).attr('data-ageValid-length')){
						var lengthList = $(param).attr('data-ageValid-length').split(',');
						if(lengthList.length == 1){
							lengthList[1] = lengthList[0];
							lengthList[0] = 0;
						}else if($.trimAll(lengthList[0]).length == 0 || lengthList[0] == null || lengthList[0] <= 0){
							lengthList[0] = 0;
						}
						if(inputValue.length > lengthList[1]*1 || inputValue.length < lengthList[0]*1 ){
							var tempMessageList = messagesTemp.length.split('&&&');
							var resultMessage = tempMessageList[0] + lengthList[0] + tempMessageList[1] + lengthList[1] + tempMessageList[2];
							$(errorDiv).css({
								'top':$(param).position().top+36,
								'left':$(param).position().left+5
							}).find('#age-valid-message').text(resultMessage);
							$(param).parent().append(errorDiv);
							$(param).focus();
							resultFlag = false;
							return;
						}
					}
				}
				validFunction(objectE);
			})
		}
		return resultFlag;
	}
})
$.fn.extend({
	tabRun:function(){
		if($(this).children().length > 0){
			var checkflag = false;
			$(this).children().each(function(){
				$(this).on('click',function(){
					var tabId = $.trimAll($(this).text()) + 'Tab';
					$('.age-form-tab').hide();
					$(this).parent().children().each(function(){$(this).removeClass().addClass('age-tab-menu-li')});
					$(this).removeClass().addClass('age-tab-menu-selected');
					var bodyHeight = document.body.scrollTop || document.documentElement.scrollTop;
					var targetE = $(this).parent().parent();
					if(window.innerWidth > 980){
						$(targetE).css('position','relative');
						$(targetE).css('top','0px');
					}else{
						var startHeight = $(targetE).parents('.age-block-row').position().top;
						if(bodyHeight > startHeight){
							if(bodyHeight + $(targetE).height() <= startHeight + $(targetE).parents('.age-block-row').height()){
								$(targetE).css('top',bodyHeight+'px');
							}else{
								$(targetE).css('top',startHeight + $(targetE).parents('.age-block-row').height() - $(targetE).height() -22+'px');
							}
						}else{
							$(targetE).css('top',startHeight+'px');
						}
					}
					
					$('#'+tabId).show();
				});
			});
			$(this).children().eq(0).click();
			if(tempData.tabs===undefined||tempData.tabs.length == 0){
				var tabsTemp = [];
				tabsTemp[0] = $(this).attr('id');
				tempData.tabs = tabsTemp;
			}else{
				var tabsTemp = tempData.tabs;
				tabsTemp[tabsTemp.length +1] = $(this).attr('id');
				tempData.tabs = tabsTemp;
			}
		}
	},
	tableWidthCalc:function(){
		$(this).each(function(){
			if($(this).find('tbody tr').length > 0){
				if($(this).prev().hasClass('age-table-clone')){
					$(this).prev().remove();
					this.parentElement.scrollTop = 0;
					$(this).find('thead').show();
				}
				var tr = $('<tr></tr>');
				var head = $(this).find('thead tr').eq(0).children();
				$(this).find('tbody tr').eq(0).children().each(function(i){
					var width = $(head).eq(i).width()>$(this).width()?$(head).eq(i).width():$(this).width();
					var td = $('<td></td>');
					$(this).width(width);
					td.text($(head).eq(i).text()).width(width).on('click',function(){
						$(head).eq(i).click();
					});
					tr.append(td);
				});
				var table = $('<table cellSpacing="0" class="age-table age-table-clone"></table>').append($('<thead></thead>').append(tr)).width($(this).width());
				$(this).parent().prepend(table);
				$(this).css('margin-top',0-$(this).find('thead').height() + 'px');
				
				$(this).parent().on('scroll',function(){
					$(this).children('.age-table-clone').css('top',this.scrollTop);
				});
			}
		});
	},
	titlePopup:function(){
		$(this).each(function(i){
			var divarrow = $('<div class="age-title-arrow"></div>');
			var divinfo = $('<div class="age-title-info"></div>').text($(this).attr("title"));
			var div = $('<div class="age-title-popup"></div>');
			var id = '5AGe'+(Math.random()+'').split('.')[1];
			div.attr('id',id).hide();
			$('body').append(div);
			if($(this).attr("title")){
				if($(this).attr('data-title-arrow')=='left'){
					div.addClass('popup-left').append(divarrow).append(divinfo).css({'left':$(this).offset().left*1-$(div).width()-10,'top':$(this).offset().top+(this.offsetHeight-$(div).height()-10)/2})
				}else if($(this).attr('data-title-arrow')=='right'){
					div.addClass('popup-right').append(divarrow).append(divinfo).css({'left':$(this).offset().left*1+this.offsetWidth,'top':$(this).offset().top+(this.offsetHeight-$(div).height()-10)/2})
				}else if($(this).attr('data-title-arrow')=='bottom'){
					div.addClass('popup-bottom').append(divarrow).append(divinfo).css({'left':$(this).offset().left*1-($(div).width()-10-this.offsetHeight)/2,'top':$(this).offset().top+this.offsetHeight})
				}else{
					div.addClass('popup-top').append(divarrow).append(divinfo).css({'left':$(this).offset().left*1-($(div).width()-10-this.offsetHeight)/2,'top':$(this).offset().top-$(div).height()-10})
				}
			}
			$(this).attr('data-title-no',id).removeAttr('title');
			$(this).on('mouseover',function(){
				$('#'+$(this).attr('data-title-no')).show(200);
			}).on('mouseout',function(){
				$('#'+$(this).attr('data-title-no')).hide(200);
			});
		});
	},
	showDialog:function(){
		$(this).each(function(){
			var bodyHeight = document.body.scrollTop || document.documentElement.scrollTop;
			$(this).on('click',function(){
				if($(this).attr('dialog-id')){
					if($(this).attr('target-id')){
						$('#'+$(this).attr('dialog-id')).attr('target-id',$(this).attr('target-id'));
					}
					if($(this).attr('target-name') && $(this).attr('target-no')){
						$('#'+$(this).attr('dialog-id')).attr('target-name',$(this).attr('target-name')).attr('target-no',$(this).attr('target-no'));
					}
					if(window.innerWidth > 980){
						$('#'+$(this).attr('dialog-id')).css('top',$('#'+$(this).attr('dialog-id')).position().top + window.screen.height/2 - 425 +'px').show()
					}else{
						$('#'+$(this).attr('dialog-id')).height(window.innerHeight).css('top',(document.body.scrollTop || document.documentElement.scrollTop)+'px').show()
					}
					$('.age-dialog table').tableWidthCalc();
					$('body').css('overflow-y','hidden');
					$('.age-dialog table tbody').height($('.age-dialog table').height() - $('.age-dialog table thead').height());
					$('.age-dialog table tbody').css('max-height',$('.age-dialog table').height() - $('.age-dialog table thead').height());
					$('.age-dialog-backdrop').show();
				}
			});
			$('#'+$(this).attr('dialog-id')).find('.age-form-button').on('click',function(){
				var target = $(this).parents('.age-dialog').attr('target-id');
				var raidoName = $(this).parents('.age-dialog').find('input[type="radio"]').eq(0).attr('name');
				if($('[name="'+raidoName+'"]:checked').val()){
					if(target){
						$('#'+target).val($('[name="'+raidoName+'"]:checked').val());
					}else{
						target = $(this).parents('.age-dialog').attr('target-name');
						targetCount = $(this).parents('.age-dialog').attr('target-no');
						$('[data-loop-name="'+target+'"]').eq(targetCount*1).val($('[name="'+raidoName+'"]:checked').val());
					}
					$('body').css('overflow-y','auto');
					$(this).parents('.age-dialog').hide();
					$('.age-dialog-backdrop').hide();
				}else{
					alert('Please choose one radio.');
				}
			});
			$('.age-dialog-backdrop').on('click',function(){
				$('body').css('overflow-y','auto');
				$('.age-dialog').hide();
				$(this).hide();
			});
		});
	},
	openCloseDiv:function(){
		if($('[age-hide-img]').length > 0){
			$('[age-hide-img]').on('click',function(){
				if($(this).children('.age-form-slabel-img').hasClass('age-form-slabel-imgdown')){
					$(this).children('.age-form-slabel-img').removeClass('age-form-slabel-imgdown');
					$(this).next().show(300);
				}else{
					$(this).children('.age-form-slabel-img').addClass('age-form-slabel-imgdown');
					$(this).next().hide(300);
				}
			}).each(function(){
				$(this).append($('<span class="age-form-slabel-img"> </span>'));
			});
		}
		if($('#open-all')){
			$('#open-all').on('click',function(){
				$('[age-hide-img] .age-form-slabel-img').each(function(){
					$(this).addClass('age-form-slabel-imgdown');
					$(this).parent().next().hide(300);
				});
				$('#open-all').hide();
				$('#close-all').show();
			});
		}
		if($('#close-all')){
			$('#close-all').on('click',function(){
				$('[age-hide-img] .age-form-slabel-imgdown').each(function(){
					$(this).removeClass('age-form-slabel-imgdown');
					$(this).parent().next().show(300);
				});
				$('#close-all').hide();
				$('#open-all').show();
			});
		}
		$('#open-all').show();
	},
	showCalendar:function(){
		$(this).each(function(i){
			$(this).on('click',function(){
				$('#'+$(this).attr('calendar-id')).css({
					'top':$(this).prev().position().top + 30 + 'px',
					'left':$(this).prev().position().left+5 + 'px'
				}).toggle(20);
			});
			$(this).prev().on('click',function(){
				$('#'+$(this).next().attr('calendar-id')).css({
					'top':$(this).position().top + 30 + 'px',
					'left':$(this).position().left+5 + 'px'
				}).toggle(20);
			});
		});
	}
});
var tempData = {};
$(function(){
	$('.age-footer-main').css("position",document.body.scrollHeight==document.body.offsetHeight?'absolute':'');
	$(window).on('scroll',function(){
		if(tempData.tabs!==undefined && tempData.tabs.length > 0){
			var tabs = tempData.tabs;
			var bodyHeight = document.body.scrollTop || document.documentElement.scrollTop;
			for(var i in tabs){
				var targetE = $('#'+tabs[i]).parent()[0];
				var startHeight = $(targetE).parents('.age-block-row').position().top;
				if(window.innerWidth > 980){
					$(targetE).css('position','relative');
					if(bodyHeight > startHeight){
						if(bodyHeight + $(targetE).height() <= startHeight + $(targetE).parents('.age-block-row').height()){
							$(targetE).css('top',(bodyHeight-startHeight)+'px');
						}else{
							$(targetE).css('top',$(targetE).parents('.age-block-row').height() - $(targetE).height() -22+'px');
						}
					}else{
						$(targetE).css('top','0px');
					}
				}else{
					if(bodyHeight > startHeight){
						if(bodyHeight + $(targetE).height() <= startHeight + $(targetE).parents('.age-block-row').height()){
							$(targetE).css('top',bodyHeight+'px');
						}else{
							$(targetE).css('top',startHeight + $(targetE).parents('.age-block-row').height() - $(targetE).height() -22+'px');
						}
					}else{
						$(targetE).css('top',startHeight+'px');
					}
				}
			}
		}
	});
	$('.age-body-main').resize(function(){
		var bodyHeight = document.body.scrollTop || document.documentElement.scrollTop;
		$('.age-footer-main').css("position",document.body.scrollHeight==document.body.offsetHeight?'absolute':'');
		if($('.age-footer-main').length > 0){
			$('.age-footer-main').css('top',bodyHeight+window.innerHeight - 50 +'px');
		}
	});
	$('[menu-click]').on('click',function(){
		var p = $(this).prev();
		if(p.attr('hide-flag')){
			p.removeAttr('hide-flag',false).show(1000,'swing');
		}else{
			p.attr('hide-flag',true).hide(1000,'swing');
		}
	});
	$.resetMenu(50);
	$(window).resize(function(){
		if(window.innerWidth > 980){
			$('.header-menu').show();
			$('.age-footer-block>div').eq(0).removeClass().addClass('age-footer-block-left');
			$('.age-footer-block>div').eq(1).removeClass().addClass('age-footer-block-right');
		}else{
			$('.header-menu').hide();
			$('.age-footer-block>div').removeClass().addClass('age-footer-block-block');
		}
		$.resetMenu(50);
		var bodyHeight = document.body.scrollTop || document.documentElement.scrollTop;
		$('.age-footer-main').css("position",document.body.scrollHeight==document.body.offsetHeight?'absolute':'');
		if($('.age-footer-main').length > 0){
			$('.age-footer-main').css('top',bodyHeight+window.innerHeight - 50 +'px');
		}
	})
	$('.header-userinfo').on('click',function(){
		if($('#logoff')===undefined || $('#logoff').length == 0){
			var modal = $('<dialog id="logoff"><h2>Do you really want to log off ?</h2></dialog>');
			var btnOK = $('<botton class="age-form-button">OK</botton>').on('click',function(){
				this.parentElement.close();
				window.location.href = '../../login.html'
			});
			var btnCancel = $('<botton class="age-form-button">Cancel</botton>').on('click',function(){
				this.parentElement.close();
			});
			modal.append(btnCancel).append(btnOK);
			$('.age-body-main').prepend(modal);
			document.getElementById('logoff').showModal();
		}else{
			document.getElementById('logoff').showModal();
		}
	});
	if($('[input-enter]').length > 0){
		$('[input-enter]').each(function(){
			if($(this).next()){
				var next = $(this).next();
				if(next.text != 'IN'){
					$(this).width($(this).width()*1-37).css({
						"border-top-right-radius": "0px",
				    	"border-bottom-right-radius": "0px"
					});
					var parentTemp = $(this).parent();
					var span = $('<span class="enter-img">IN</span>').on('click',function(){
						$('form').submit();
					})
					parentTemp.append(span);
				}
			}
		});
	}
	if(window.innerWidth > 980){
		$('.header-menu').show();
		$('.age-footer-block>div').eq(0).removeClass().addClass('age-footer-block-left');
		$('.age-footer-block>div').eq(1).removeClass().addClass('age-footer-block-right');
	}else{
		$('.age-footer-block>div').removeClass().addClass('age-footer-block-block');
		$('.header-menu').hide();
	}
})
var storage = function(key,value){
	if(key){
		if(value){
			localStorage.setItem(key, value);
		}else{
			return localStorage.getItem(key);
		}
	}else{
		return localStorage;
	}
}
var Storage = {
	"length":function(){
		return localStorage.length;
	},
	"set":function(key, value){
		return localStorage.setItem(key, value);
	},
	"get":function(key){
		return localStorage.getItem(key);
	},
	"remove":function(key){
		return localStorage.removeItem(key);
	},
	"clear":function(){
		localStorage.clear();
	}
}

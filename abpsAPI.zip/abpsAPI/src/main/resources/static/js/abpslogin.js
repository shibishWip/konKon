$(document).ready(function() {	
	
		$('#strPrefAltCard').attr("disabled", "disabled");
		$('#StrBillPayCycleDt').attr("disabled", "disabled");
		$('#StrBillPayCycleDue').attr("disabled", "disabled");
		$('#RegExpDateStr').attr("disabled", "disabled");
		$("#StrAltCardChkFlag").val('1');
	
  	$("#ChkFlag").click(function () {
      	if ($(this).is(":checked")) {
      		$("#StrAltCardChkFlag").val('2');
	            $("#strPrefAltCard").removeAttr("disabled");
	            $("#StrBillPayCycleDt").removeAttr("disabled");
	            $("#StrBillPayCycleDue").removeAttr("disabled");
	            
	            $('#StrBillPayCycleDt').removeClass('form-select-disable');
	      	  	$('#StrBillPayCycleDue').removeClass('form-select-disable');
	      	  	$('#strPrefAltCard').removeClass('form-text-disable');
	      	  	
	      	  	$('#strPrefAltCard').addClass('form-text');
	      		$('#StrBillPayCycleDt').addClass('form-select');
	      		$('#StrBillPayCycleDue').addClass('form-select');
	      	  	
      	}
      	else{
      		var cardNmbr = $('#cardNmbr').val();
      		$("#StrCardNmbr").val(cardNmbr);
      		$("#StrAltCardChkFlag").val('1');
      		 $('#strPrefAltCard').attr("disabled", "disabled");
      		 $('#StrBillPayCycleDt').attr("disabled", "disabled");
      		 $('#StrBillPayCycleDue').attr("disabled", "disabled");
      		 
      		 $('#strPrefAltCard').val('');
      		 $('#StrBillPayCycleDt').val('');
      		 $('#StrBillPayCycleDue').val('');
      		 
      		$('#strPrefAltCard').removeClass('form-text');
      		$('#StrBillPayCycleDt').removeClass('form-select');
      		$('#StrBillPayCycleDue').removeClass('form-select');
      		 
	      		$('#strPrefAltCard').addClass('form-text-disable');
	      		$('#StrBillPayCycleDt').addClass('form-select-disable');
	      		$('#StrBillPayCycleDue').addClass('form-select-disable');
      	}
  	});
	    	
	  $("#StrRegChekExpprivate").click(function () {
    		 if ($(this).is(":checked")) {
        		 $("#RegExpDateStr").removeAttr("disabled");
        		 $('#RegExpDateStr').removeClass('form-text-expiry1');
        		 $('#RegExpDateStr').addClass('form-text-expiry');
        	}else{
        		$('#RegExpDateStr').attr("disabled", "disabled");
        		$('#RegExpDateStr').val('');
        		$('#RegExpDateStr').removeClass('form-text-expiry');
        		$('#RegExpDateStr').addClass('form-text-expiry1');
        	}
    	});  
});

function loadPartner(){
		
	var strPymtChannel = $("#MerchNmbr :selected").text();
	var strPartnerVal = $('#MerchNmbr').val();
	var splitPartner=strPartnerVal.split('-');
	var strMerchNmbr=splitPartner[0];
	var strPayChennal=splitPartner[1];
	var strMerchOrg=splitPartner[2];
	
	if(splitPartner[1]=="0"){
		$("#PymtChannel").val("Customer-Initiated");
	}else if(splitPartner[1]=="1"){
		$("#PymtChannel").val("Merchant-Initiated");
	}else if(splitPartner[1]=="2"){
		$("#PymtChannel").val("System-Initiated");
	}else if(splitPartner[1]=="3"){
		$("#PymtChannel").val("All Channels");
	}		
	var splitPayChann=strPymtChannel.split('-');
	$("#StrDescription").val(splitPayChann[1]);
	$("#StrMerchOrg").val(strMerchOrg);
	$("#StrMerchNmbr").val(strMerchNmbr);
	$("#StrPymtChannel").val(strPayChennal);
	$('#StrDescription').attr("disabled", "disabled");
	$('#PymtChannel').attr("disabled", "disabled");
}


$(function(){
	//$('#test').showDialog();
	$('[dialog-id="FNAReferenceNoPopup"]').showDialog();
	$('[dialog-id="paymentAccountNoPopup"]').showDialog();
	$('[dialog-id="RiderPopup"]').showDialog();
	$("#riderTable tbody tr").each(function(){
		$(this).children('td').each(function(){
			var width=$("#riderTable tbody").width()-30;
			$(this).css({
				'padding-left':width/6-105 + 'px',
				'padding-right':width/6-105 + 'px'
			});
		});
	});
	$("#riderTable thead tr").eq(0).children().each(function(){
		$(this).width(($(".age-table tbody").width()-30)/3);
	});
	if($('.age-form-slabel[age-hide-img]').length > 0){
		$('.age-form-slabel[age-hide-img]').openCloseDiv();
	}
	$('#firstPremiumDate,#expiryDate,#dob').datepicker({
		dateFormat: "ddMyy",
		monthNamesShort:[ "Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ],
		changeMonth: true,
		changeYear:true
	});
	$('.glyphicon-calendar').on('click',function(){
		$(this).prev().focus();
	});
	$('#userOut').on('click',function(){
		window.location = "/ABPSLogin/login";
	});
	$('#Save').on('click',function(){
		if($("#ChkFlag").is(":checked")){
		var cardNmbr= $("#strPrefAltCard").val();
  		$("#StrCardNmbr").val(cardNmbr);
		}
			var requestData={};
			$('input[name]:not([type="radio"]),select[name]').each(function(){
			
				requestData[$(this).attr('name')] = $(this).val();
			});
			
			console.log(requestData);
			$.support.cors = true;
			$.ajax({
				type:"POST",	
				url: "/Accounts/ABPSADD",
				contentType:"text/html",
				data: JSON.stringify(requestData),
				success:function(data){
					console.log(data);
					if(data.responseBody.action == "NEW"){
						jAlert('New Registration Successfully Completed', 'Registration Confirmation', function(r){
							if(r){
								location.reload();
							}
						});
					}
					else if((data.responseBody.errCode == "9999") || (data.responseBody.errCode == "9998"))
					{		
						console.log(data);
						jAlert(data.responseBody.message, 'Registration Error');
					}
					
				},
				error:function(data){
					console.info(data);
				}
			});
		
	});
var listModule = angular.module('NewRegistrationModule',[]);
	listModule.config(function($httpProvider) {
    $httpProvider.defaults.headers.put['Accept'] = 'application/json, text/javascript, */*; q=0.01'; 
    $httpProvider.defaults.headers.post['Accept'] = 'application/json, text/javascript, */*; q=0.01';  
});

listModule.controller('AccountsListController',function($scope,$http){
		var strCardNmbr = $('#StrCardNmbr').val();
		var strCardOrg = $('#StrCardOrg').val();
		var strCardLogo = $('#StrCardLogo').val();
				
		var requestData = {};
		requestData['StrCardOrg']  = strCardOrg;
		requestData['StrCardNmbr'] = strCardNmbr;
		requestData['StrCardLogo'] = strCardLogo;
		console.log(requestData);
		$http.post('/Accounts/ABPSLIST',requestData).then(function (data) {			
		console.info(data.data);
		$scope.searchResults = data.data.responseBody;
		//$scope.merchDesc = data.data.merchDesc; 
		}.bind(this));
});

listModule.controller('MerchantsListController',function($scope,$http){
		var requestData = {};
		requestData['StrMerchOrg'] = $scope.StrMerchOrg;
		requestData['StrMerchNmbr'] =$scope.StrMerchNmbr;
		console.log(requestData);
		
		$http.post('/Merchants/MERCHLIST',requestData).then(function (data) {
		console.info(data.data);
		var responseData = data.data.responseBody;
		var count=0;
		$scope.searchResults = responseData;
		window.setTimeout(function(){$('#listDropdown').tableWidthCalc();},1);
		}.bind(this));
});

})
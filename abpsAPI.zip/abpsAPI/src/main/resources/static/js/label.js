
$(document).ready(function($http){
	$.support.cors = true;
	var labels = "";
	var requestData = {};
	$('label[for]').each(function(){
		labels = labels + "," + $(this).attr('for') ;			
	});
	
	labels = labels.substring(1);
	requestData['labels'] = labels ;
	requestData['language'] = "en";
	requestData['ctrl_1'] = "0";
	$.ajax({
			type:"POST",	
			url: "http://localhost:8080/IPGenUtility/getLabels",
			contentType:"text/html",
			data: JSON.stringify(requestData),
			success:function(data){
				$('label[for]').each(function(){
					this.innerHTML = data[$(this).attr('for')] ;		
				 });					
			},
			error:function(data){
				alert("eror");
			}
		});		
});

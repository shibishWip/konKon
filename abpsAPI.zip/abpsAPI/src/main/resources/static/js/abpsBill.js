$(function(){
	$('#test').showDialog();
	$('[dialog-id="FNAReferenceNoPopup"]').showDialog();
	$('[dialog-id="paymentAccountNoPopup"]').showDialog();
	$('[dialog-id="RiderPopup"]').showDialog();
	$("#riderTable tbody tr").each(function(){
		$(this).children('td').each(function(){
			var width=$("#riderTable tbody").width()-30;
			$(this).css({
				'padding-left':width/6-105 + 'px',
				'padding-right':width/6-105 + 'px'
			});
		});
	});
	$("#riderTable thead tr").eq(0).children().each(function(){
		$(this).width(($(".age-table tbody").width()-30)/3);
	});
	if($('.age-form-slabel[age-hide-img]').length > 0){
		$('.age-form-slabel[age-hide-img]').openCloseDiv();
	}
	$('#firstPremiumDate,#expiryDate,#dob').datepicker({
		dateFormat: "ddMyy",
		monthNamesShort:[ "Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ],
		changeMonth: true,
		changeYear:true
	});
	$('.glyphicon-calendar').on('click',function(){
		$(this).prev().focus();
	});
	$('#Save').on('click',function(){
		if($.ageValidation()){
			var requestData={};
			$('input[name]:not([type="radio"]),select[name]').each(function(){
			
				requestData[$(this).attr('name')] = $(this).val();
			});
			
			
			console.info(requestData);
			$.support.cors = true;
			$.ajax({
				type:"POST",	
				url: "http://localhost:8080/Accounts/ABPSADD",
				contentType:"text/html",
				data: JSON.stringify(requestData),
				success:function(data){
					if(data.responseBody.message){
						alert(data.responseBody.message);
					}else{			
						data.responseBody.backURI= "ABPSCreate&List.html";
					}
					
				},
				error:function(data){
					console.info(data);
				}
			});
		}
	});

var listModule = angular.module('ListModule',[]).config(function($httpProvider) {
    $httpProvider.defaults.headers.put['Accept'] = 'application/json, text/javascript, */*; q=0.01'; 
    $httpProvider.defaults.headers.post['Accept'] = 'application/json, text/javascript, */*; q=0.01';  
});
listModule.controller('ListController',function($scope,$http){

	$scope.callBack = function(){
		var requestData = {};
		requestData['StrCardOrg'] = $scope.UnderWriter;
		requestData['StrCardNmbr'] = $scope.MakerId;
		console.log(requestData);
		
		$http.post('http://localhost:8080/Accounts/ABPSLIST',requestData).then(function (data) {
			
			console.info(data.data);
			var responseData = data.data.responseBody;
			var count=0;
			for(var l in responseData){
				responseData[count].accountClassValid = (count%2==0)?'age-table-bluetr':'';
				count++;
			}
			$scope.searchResults = responseData;
			window.setTimeout(function(){$('#listTable').tableWidthCalc();},1);
		}.bind(this));
		
	}
	$scope.callBack = function(){
		var requestData = {};
		requestData['strMerchOrg'] ='000';
		requestData['strStatus'] = $scope.Status;
		console.log(requestData);
		
		$http.post('http://localhost:8080/Merchants/MERCHLIST',requestData).then(function (data) {
			
			console.info(data.data);
			var responseData = data.data.responseBody;
			var count=0;
			for(var l in responseData){
				responseData[count].merchClassValid = (count%2==0)?'age-table-bluetr':'';
				count++;
			}
			$scope.searchResults = responseData;
			window.setTimeout(function(){$('#listDropdown').tableWidthCalc();},1);
		}.bind(this));
		
	}
});

})
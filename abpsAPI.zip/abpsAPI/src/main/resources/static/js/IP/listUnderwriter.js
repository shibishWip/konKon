$(function(){
	$('table').tableWidthCalc();
	$('[dialog-id]').showDialog();	
	$('#Add').on('click',function(){
		window.location.href = 'IPUnderwriterNew.html';
	});	
	$('.age-dialog .age-form-button').on('click',function(){
		var id = $(this).parents('.age-dialog').attr('target-id');
		$('#'+id).val('AaBbCc12321');
		$('body').css('overflow-y','auto');
		$('.age-dialog').hide();
		$('.age-dialog-backdrop').hide();
	});
	$.support.cors = true;
})
var uwListModule = angular.module('UWListModule',[]).config(function($httpProvider) {
    $httpProvider.defaults.headers.put['Accept'] = 'application/json, text/javascript, */*; q=0.01'; 
    $httpProvider.defaults.headers.post['Accept'] = 'application/json, text/javascript, */*; q=0.01';  
});
uwListModule.controller('UwListController',function($scope,$http){

//angular.module('ListModule',[]).controller('ListController',function($scope,$http){
	$scope.callBack = function(){
		var requestData = {};
		requestData['ctrl_1'] = $scope.strCtrl1;
		//requestData['strCtrl2'] = $scope.strCtrl2;
		requestData['strUWCode'] = $scope.UnderWriter;
		requestData['strMakerID'] = $scope.MakerId;
		requestData['strStatus'] = $scope.Status;
		//http://163.36.205.201:8080/SpringMVCDemo/showListings
		//http://10.114.188.99:8081/showListing3
		console.log(requestData);
		
		$http.post('http://localhost:8080/IPUnderwriter/UWLISTING',requestData).then(function (data) {
			
		//$http.jsonp('http://10.114.188.99:8081/showListing3',{data:requestData}).then(function (data) {
		//$http.post('http://10.114.188.99:8081/ApplicationListing' ,requestData,{withCredentials: true}).then(function (data) {
			console.info(data.data);
			var responseData = data.data.responseBody;
			//$scope.response = responseData;
			//$scope.strCtrl1 = responseData.ctrl_1;
			//$scope.strCtrl2 = responseData.strCtrl2;
			//$scope.UnderWriter = responseData.strUWCode;
			//$scope.MakerId = responseData.strMakerID;
			var count=0;
			for(var l in responseData){
				responseData[count].trClassValid = (count%2==0)?'age-table-bluetr':'';
				count++;
			}
			$scope.searchResults = responseData;
			window.setTimeout(function(){$('#underwriterListTable').tableWidthCalc();},1);
		}.bind(this));
		
		// var responseData = jsonData.responseBody;
			// $scope.response = responseData;
			// $scope.strCtrl1 = responseData.strCtrl1;
			// $scope.strCtrl2 = responseData.strCtrl2;
			// $scope.InsureAccoNo = responseData.strSearchInsuranceAccountNumber;
			// $scope.Product = responseData.strSearchProductCode;
			// $scope.AppliNo = responseData.strSearchApplicationNumber;
			// $scope.IPAStatus = responseData.strIPAStatus=='Paid'?'PD':'';
			// $scope.PolicyNumber = responseData.strSearchPolicyNumber;
			// var count=0;
			// for(var l in responseData.objIPApplicationPolicyListDom){
				// responseData.objIPApplicationPolicyListDom[count].trClassValid = (count%2==0)?'age-table-bluetr':'';
				// count++;
			// }
			// $scope.searchResults = responseData.objIPApplicationPolicyListDom;
			// window.setTimeout(function(){$('#applicationListTable').tableWidthCalc();},1);
		
	}
	$scope.view = function(applyNo){
	var href = 'IPUnderwriterDetails.html';
		if(storage()){
			Storage.set('uwNo',applyNo);
		}else{
			href += '?uwNo='+applyNo;
			
		}
		window.location.href = href;
	}
});
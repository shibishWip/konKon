$(function(){
	$('table').tableWidthCalc();
	$('[dialog-id]').showDialog();	
	$('#Add').on('click',function(){
		window.location.href = 'IPApplicationNew.html';
	});	
	$('.age-dialog .age-form-button').on('click',function(){
		var id = $(this).parents('.age-dialog').attr('target-id');
		$('#'+id).val('AaBbCc12321');
		$('body').css('overflow-y','auto');
		$('.age-dialog').hide();
		$('.age-dialog-backdrop').hide();
	});
})
angular.module('ListModule',[]).controller('ListController',function($scope,$http){
	$scope.callBack = function(){
			var responseData = jsonData.responseBody;
			//var responseData = data.data;
			var requestData = {};
		requestData['strCtrl1'] = 0;
		requestData['strCtrl2'] = 0;
			$http.post('http://163.36.205.201:8080/SpringMVCDemo/showListings',requestData).then(function (data){console.info('showListings');console.info(data);});
			//$http.post('http://10.114.188.99:8080/SpringMVCDemo/showListing3',requestData).then(function (data){console.info('showListing');console.info(data);});
			$scope.response = responseData;
			$scope.strCtrl1 = responseData.strCtrl1;
			$scope.strCtrl2 = responseData.strCtrl2;
			$scope.InsureAccoNo = responseData.strSearchInsuranceAccountNumber;
			$scope.Product = responseData.strSearchProductCode;
			$scope.AppliNo = responseData.strSearchApplicationNumber;
			$scope.IPAStatus = responseData.strIPAStatus=='Paid'?'PD':'';
			$scope.PolicyNumber = responseData.strSearchPolicyNumber;
			var count=0;
			for(var l in responseData.objIPApplicationPolicyListDom){
				responseData.objIPApplicationPolicyListDom[count].strInsuranceAccountNumber = responseData.objIPApplicationPolicyListDom[count].strInsuranceAccountNumber+count;
				responseData.objIPApplicationPolicyListDom[count].trClassValid = (count%2==0)?'age-table-bluetr':'';
				count++;
			}
			$scope.searchResults = responseData.objIPApplicationPolicyListDom;
			window.setTimeout(function(){$('#applicationListTable').tableWidthCalc();},1);
	}
	$scope.by = 'strInsuranceAccountNumber';
	$scope.reverses = true;
	$scope.roderClick = function(param){
		$scope.reverses = (param==$scope.by)?!$scope.reverses:true;
	}
	$scope.hrefLink = function(param){
		alert(param);
	}
});
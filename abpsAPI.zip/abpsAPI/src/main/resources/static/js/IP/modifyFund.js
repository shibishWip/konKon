$(function(){
	$('#Back').on('click',function(){
		history.go(-1);
	});	
	$('#Done').on('click',function(){
		if($.ageValidation()){
			var requestData={};
			requestData.group_id="8800";
			requestData.fund_ctrl_1="88";
			requestData.fund_ctrl_2="001";
			requestData.fund_ctrl_3="000";
			requestData.fund_ctrl_4="0000";
			
			$('input[name]:not([type="radio"]),select[name]').each(function(){
				requestData[$(this).attr('name')] = $(this).val();
			});
			console.info(requestData);
			$.support.cors = true;
			$.ajax({
				type:"POST",	
				url: "http://localhost:8080/IPFund/FundMODIFY",
				contentType:"text/html",
				data: JSON.stringify(requestData),
				success:function(data){
				window.location.href = "SuccessfulFundMod.html?data="+JSON.stringify(data.responseBody);
				},
				error:function(data){
					console.info(data);
				}
			});
		}
	});
	$.support.cors = true;
})
angular.module('FundModModule',[]).controller('FundModController',function($scope,$http){
	var requestData = {};
	if(storage()){
		requestData['fundCode'] = Storage.get('fundCode');
		requestData['uwCode'] = Storage.get('uwCode');
	}else{
		


		//var data = window.location.href.split('&');
		var data = window.location.search;
		
		if (data.indexOf("?") != -1) {
			var str = data.substr(1);
			strs = str.split("&");
			for(var i = 0; i < strs.length; i ++) {
				requestData[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
			}
		}
		alert("e");
		alert(requestData['uwCode']);
		alert(requestData['fundCode']);


		
	}
	
		var href = 'http://localhost:8080/IPFund/FundVIEW/'+requestData['uwCode']+'/'+requestData['fundCode'];
	
	$http.get(href).then(function (data) {
		alert("et");
		var responseBody = data.data.responseBody;
		if(responseBody.fund_code == undefined){
			responseBody['fund_code'] = requestData['fundCode'];
		}
		$scope.responsebody = responseBody;
		alert("et2");
		window.setTimeout(function(){
			var selects = document.getElementsByTagName('select');
			for(var i=0;i<selects.length;i++){
				var select = selects[i]
				for(var j=0;j<select.attributes.length;j++){
					var attr = select.attributes[j]
					if(attr.nodeName == 'value'){
						select.value = attr.nodeValue;
						break;
					}
				}
			}
		},1);
	}.bind(this));
	
	
});





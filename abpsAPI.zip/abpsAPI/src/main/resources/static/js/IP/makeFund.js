$(function(){
	
if($('.age-form-slabel[age-hide-img]').length > 0){
		$('.age-form-slabel[age-hide-img]').openCloseDiv();
	}
	//$('#calendarspan').showCalendar();
	$('#effectiveDate,#expiryDate,#productStartDate,#productEndDate').datepicker({
		dateFormat: "yy-mm-dd",
		monthNamesShort:[ "Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ],
		changeMonth: true,
		changeYear:true
	});
	$('.glyphicon-calendar').on('click',function(){
		$(this).prev().focus();
	});
	$('#Done').on('click',function(){
		if($.ageValidation()){
			var requestData={};
			requestData.group_id="8800";
			requestData.fund_ctrl_1="88";
			requestData.fund_ctrl_2="001";
			requestData.fund_ctrl_3="000";
			requestData.fund_ctrl_4="0000";
			$('input[name]:not([type="radio"]),select[name]').each(function(){
				requestData[$(this).attr('name')] = $(this).val();
			});
			
			console.info(requestData);
			$.support.cors = true;
			$.ajax({
				type:"POST",	
				url: "http://localhost:8080/IPFund/FundADD",
				contentType:"text/html",
				data: JSON.stringify(requestData),
				success:function(data){
					if(data.responseBody.message){
						alert(data.responseBody.message);
					}else{	
						data.responseBody.backURI= "IPFundList.html";	
						window.location.href = "Successful.html?data="+JSON.stringify(data.responseBody);
					}
				},
				error:function(data){
					console.info(data);
				}
			});
		}
	});
	
})
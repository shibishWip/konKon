$(document).ready(function() {
	
	  alert("1111133333");
	  var strPymtChannel = $('#StrPymtChannel').val();
	  alert("pay"+strPymtChannel)
	  $('#strPrefAltCard').attr("disabled", "disabled");
	  $('#StrBillPayCycleDt').attr("disabled", "disabled");
	  $('#StrBillPayCycleDue').attr("disabled", "disabled");
	  $('#StrRegExpDate').attr("disabled", "disabled");
	  
	  $('#strPrefAltCard').addClass('input-disabled')
	  $('#StrBillPayCycleDt').addClass('input-disabled')
	  $('#StrBillPayCycleDue').addClass('input-disabled')
	  $('#StrRegChekExpprivate').addClass('input-disabled')
	
	$(function () {
    	$("#StrAltCardChkFlag").click(function () {
        	if ($(this).is(":checked")) {
	            $("#strPrefAltCard").removeAttr("disabled");
	            $("#StrBillPayCycleDt").removeAttr("disabled");
	            $("#StrBillPayCycleDue").removeAttr("disabled");
	            $(this).removeClass('input-disabled');
        	}else{
        		 $('#strPrefAltCard').attr("disabled", "disabled");
        		 $('#StrBillPayCycleDt').attr("disabled", "disabled");
        		 $('#StrBillPayCycleDue').attr("disabled", "disabled");
        		
        	}
    	});
    	
    	$("#StrRegChekExpprivate").click(function () {
        	if ($(this).is(":checked")) {
	            $("#StrRegExpDate").removeAttr("disabled");
        	}else{
        		$('#StrRegExpDate').attr("disabled", "disabled");
        	}
    	});
    	
	});
	  

});

function loadPartner(){
	alert("select");
	
	var strPymtChannel = $("#StrMerchNmbr :selected").text();
	var strPymtChanVal = $('#StrMerchNmbr').val();
	alert("strPymtChanVal"+strPymtChanVal);
		
	var splitPayChann=strPymtChannel.split('-');
	$("#StrDescription").val(splitPayChann[1]);
	$('#StrDescription').attr("disabled", "disabled");
	alert("select end");
}
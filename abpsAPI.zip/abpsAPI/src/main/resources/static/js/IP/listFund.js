$(function(){
	$('table').tableWidthCalc();
	$('[dialog-id]').showDialog();	
	$('#Add').on('click',function(){
		window.location.href = 'IPFundNew.html';
	});	
	$.support.cors = true;
})
var listModule = angular.module('FundListModule',[]).config(function($httpProvider) {
    $httpProvider.defaults.headers.put['Accept'] = 'application/json, text/javascript, */*; q=0.01'; 
    $httpProvider.defaults.headers.post['Accept'] = 'application/json, text/javascript, */*; q=0.01';  
});
listModule.controller('FundListController',function($scope,$http){
//angular.module('ListModule',[]).controller('ListController',function($scope,$http){
	$scope.callBack = function(){
		
		var requestData = {};
		requestData['fund_code'] = $scope.FundCode;
		requestData['uw_code'] = $scope.UnderWriter;
		requestData['maker_id'] = $scope.MakerId;
		requestData['status'] = $scope.Status;
		
		
		$http.post('http://localhost:8080/IPFund/FundLISTING',requestData).then(function (data) {
		
		
			console.info(data.data);
			var responseData = data.data.responseBody;
			var count=0;
			for(var l in responseData){
				responseData[count].trClassValid = (count%2==0)?'age-table-bluetr':'';
				count++;
			}
			$scope.searchResults = responseData;
			window.setTimeout(function(){$('#fundListTable').tableWidthCalc();},1);
		}.bind(this));

		
		
	}
	$scope.view = function(fundCode,uwCode){
	var href = 'IPFundDetail.html';
		if(storage()){
			Storage.set('fundCode',fundCode);
			Storage.set('uwCode',uwCode);
		}else{
			alert(fundCode + " "+ uwCode);
			href += '?fundCode='+fundCode+'&uwCode='+uwCode;
			
		}
		window.location.href = href;
	}
});
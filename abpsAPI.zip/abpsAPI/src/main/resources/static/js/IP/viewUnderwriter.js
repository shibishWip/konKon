$(function(){
	$("table tbody tr").each(function(){
		$(this).children('td').each(function(){
			var width=$("table tbody").width()-30;
			$(this).css({
				'padding-left':width/6-90 + 'px',
				'padding-right':width/6-85 + 'px'
			});
		});
	});
	$("table thead tr").eq(0).children().each(function(){
		$(this).width(($("table tbody").width()-33)/3);
	});
	if($('.age-form-slabel[age-hide-img]').length > 0){
		$('.age-form-slabel[age-hide-img]').openCloseDiv();
	}
	$('#Back').on('click',function(){
		history.go(-1);
	});
})
angular.module('UWViewModule',[]).controller('UWViewController',function($scope,$http){
	var requestData = {};
	if(storage()){
		requestData['UWName'] = Storage.get('uwNo');
		
	}else{
		var data = window.location.href.split('=')[1];
		requestData['UWName'] = data;
	
	}
	//http://10.114.188.99:8080/SpringMVCDemo/view
	var href = 'http://localhost:8080/IPUnderwriter/UWVIEW/'+requestData['UWName'].replace('#','');
	$http.get(href).then(function (data) {	
   //$http.get(href).success(function (data) {	

		var responseBody = data.data.responseBody;
	//	var responseBody = data.responseBody;
		
		
		if(responseBody.strUWCode == undefined){
			responseBody['strUWCode'] = requestData['UWName'];
		}
		$scope.responsebody = responseBody;
		alert(responsebody.strCompanyNationality);
		window.setTimeout(function(){
			var selects = document.getElementsByTagName('select');
			for(var i=0;i<selects.length;i++){
				var select = selects[i]
				for(var j=0;j<select.attributes.length;j++){
					var attr = select.attributes[j]
					if(attr.nodeName == 'value'){
						select.value = attr.nodeValue;
						break;
					}
				}
			}
		},1);
	}.bind(this));
	
//	$scope.auth = function(uwNo){
//	var requestData = {};
//	if(storage()){
//		requestData['strSearchApplicationNumber'] = Storage.get('uwNo');
//	}else{
//		var data = window.location.href.split('=')[1];
//		requestData['strSearchApplicationNumber'] = data;
//	}
//	var href = 'http://10.114.188.99:8081/ApplicationAuth/'+requestData['strSearchApplicationNumber'].replace('#','');
//	$http.get(href).success(function (data) {	
//		//$scope.response = responseBody;
//		window.location.href = "Successful.html?data="+JSON.stringify(data);
//		
//	}).error(function(data){
//		alert(data.message);
//	});
//
//}
});


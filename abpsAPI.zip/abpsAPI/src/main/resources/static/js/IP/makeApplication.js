$(function(){
	$('#test').showDialog();
	$('[dialog-id="FNAReferenceNoPopup"]').showDialog();
	$('[dialog-id="paymentAccountNoPopup"]').showDialog();
	$('[dialog-id="RiderPopup"]').showDialog();
	$("#riderTable tbody tr").each(function(){
		$(this).children('td').each(function(){
			var width=$("#riderTable tbody").width()-30;
			$(this).css({
				'padding-left':width/6-105 + 'px',
				'padding-right':width/6-105 + 'px'
			});
		});
	});
	$("#riderTable thead tr").eq(0).children().each(function(){
		$(this).width(($(".age-table tbody").width()-30)/3);
	});
	if($('.age-form-slabel[age-hide-img]').length > 0){
		$('.age-form-slabel[age-hide-img]').openCloseDiv();
	}
	//$('#calendarspan').showCalendar();
	$('#firstPremiumDate,#expiryDate,#dob').datepicker({
		dateFormat: "ddMyy",
		monthNamesShort:[ "Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ],
		changeMonth: true,
		changeYear:true
	});
	$('.glyphicon-calendar').on('click',function(){
		$(this).prev().focus();
	});
	$('#Done').on('click',function(){
		if($.ageValidation()){
			var requestData={};
			$('input[name]:not([type="radio"]),select[name]').each(function(){
				requestData[$(this).attr('name')] = $(this).val();
			});
			
			//rider
			var loopList = [];
			var loop = {};
			$('[data-loop="objRiderListDom"]').find('[data-loop-name]').each(function(i){
				if((i)%3 == 0){
					loop = {};
				}
				loop[$(this).attr('data-loop-name')] = $(this).val();
				if((i+1)%3 == 0){
				loopList[parseInt(i/3)] = loop;
				}
			});
			requestData["objIPRiderList"] = loopList;
			
			//insured
			loopList = [];
			loop = {};
			$('[data-loop="insured"]').find('[data-loop-name]').each(function(i){
				if((i)%5 == 0){
					loop = {};
				}
				loop[$(this).attr('data-loop-name')] = $(this).val();
				if((i+1)%5 == 0){
				loopList[parseInt(i/5)] = loop;
				}
			});
			requestData["objIPInsuredList"] = loopList;
			//http://localhost:8081/AIAController/AIA/CAIAApplicaiton
			//
			console.info(requestData);
			$.support.cors = true;
			$.ajax({
				type:"POST",	
				url: "http://10.114.188.99:8081/FromMongodb/ApplnAdd",
				data: JSON.stringify(requestData),
				success:function(data){
					//window.location.href = "Successful.html?applnNo="+data;
					window.location.href = "Successful.html?data="+JSON.stringify(data);
				},
				error:function(data){
					console.info(data);
				}
			});
		}
	});
	
})
$(function(){
	$("table tbody tr").each(function(){
		$(this).children('td').each(function(){
			var width=$("table tbody").width()-30;
			$(this).css({
				'padding-left':width/6-90 + 'px',
				'padding-right':width/6-85 + 'px'
			});
		});
	});
	$("table thead tr").eq(0).children().each(function(){
		$(this).width(($("table tbody").width()-33)/3);
	});
	if($('.age-form-slabel[age-hide-img]').length > 0){
		$('.age-form-slabel[age-hide-img]').openCloseDiv();
	}
	$('#Back').on('click',function(){
		history.go(-1);
	});
	


	$.support.cors = true;

})
angular.module('FundViewModule',[]).controller('FundViewController',function($scope,$http){
	var requestData = {};
	if(storage()){
		requestData['fundCode'] = Storage.get('fundCode');
		requestData['uwCode'] = Storage.get('uwCode');
	}else{
		


		//var data = window.location.href.split('&');
		var data = window.location.search;
		
		if (data.indexOf("?") != -1) {
			var str = data.substr(1);
			strs = str.split("&");
			for(var i = 0; i < strs.length; i ++) {
				requestData[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
			}
		}
		alert("e");
		alert(requestData['uwCode']);
		alert(requestData['fundCode']);


		
	}
	
		var href = 'http://localhost:8080/IPFund/FundVIEW/'+requestData['uwCode']+'/'+requestData['fundCode'];
	
	$http.get(href).then(function (data) {
		alert("et");
		var responseBody = data.data.responseBody;
		if(responseBody.fund_code == undefined){
			responseBody['fund_code'] = requestData['fundCode'];
		}
		$scope.responsebody = responseBody;
		alert("et2");
		window.setTimeout(function(){
			var selects = document.getElementsByTagName('select');
			for(var i=0;i<selects.length;i++){
				var select = selects[i]
				for(var j=0;j<select.attributes.length;j++){
					var attr = select.attributes[j]
					if(attr.nodeName == 'value'){
						select.value = attr.nodeValue;
						break;
					}
				}
			}
		},1);
	}.bind(this));
	
	$scope.auth = function(fundNo){
	
	var requestData = {};
	if(storage()){
		requestData['fundCode'] = Storage.get('fundNo');
	}else{
		var data = window.location.href.split('=')[1];
		requestData['fundCode'] = data;
	}
	var href = 'http://localhost:8080/IPFund/FundSTATUS/'+requestData['fundCode'].replace('#','')+'/authorise';
	//var href = 'http://localhost:8080/IPFund/FundSTATUS/125/authorise';
	alert(href);
	$http.get(href).success(function (data) {	
		data.responseBody.backURI= "IPFundList.html";		
		window.location.href = "Successful.html?data="+JSON.stringify(data.responseBody);
		
	}).error(function(data){
		alert(data.message);
	});

}

$scope.modify = function(fundCode,uwCode){
	var href = 'IPFundModify.html';
		if(storage()){
			Storage.set('fundCode',fundCode);
			Storage.set('uwCode',uwCode);
		}else{
			href += '?fundCode='+fundCode+'&uwCode='+uwCode;
			
		}
		window.location.href = href;
	}
});


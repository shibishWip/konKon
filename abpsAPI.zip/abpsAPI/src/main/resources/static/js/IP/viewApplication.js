$(function(){
	$("table tbody tr").each(function(){
		$(this).children('td').each(function(){
			var width=$("table tbody").width()-30;
			$(this).css({
				'padding-left':width/6-90 + 'px',
				'padding-right':width/6-85 + 'px'
			});
		});
	});
	$("table thead tr").eq(0).children().each(function(){
		$(this).width(($("table tbody").width()-33)/3);
	});
	if($('.age-form-slabel[age-hide-img]').length > 0){
		$('.age-form-slabel[age-hide-img]').openCloseDiv();
	}
	$('#Back').on('click',function(){
		history.go(-1);
	});
})
angular.module('ViewModule',[]).controller('ViewController',function($scope,$http){
	var requestData = {};
	if(storage()){
		requestData['strSearchApplicationNumber'] = Storage.get('applnNo');
	}else{
		var data = window.location.href.split('=')[1];
		requestData['strSearchApplicationNumber'] = data;
	}
	//http://10.114.188.99:8080/SpringMVCDemo/view
	var href = 'http://10.114.188.99:8081/ApplicationView/'+requestData['strSearchApplicationNumber'].replace('#','');
	$http.get(href).then(function (data) {
		var responseBody = data.data.responseBody
		if(responseBody.strApplicationNumber == undefined){
			responseBody['strApplicationNumber'] = requestData['strSearchApplicationNumber'];
		}
		$scope.response = responseBody;
		$scope.riderResults = [];
		if(responseBody.objIPRiderList){
			$scope.riderResults = responseBody.objIPRiderList;
		}
		$scope.insured = [];
		if(responseBody.objInsuredList.length > 0){
			$scope.insured = responseBody.objInsuredList[0];
		}
		window.setTimeout(function(){
			var selects = document.getElementsByTagName('select');
			for(var i=0;i<selects.length;i++){
				var select = selects[i]
				for(var j=0;j<select.attributes.length;j++){
					var attr = select.attributes[j]
					if(attr.nodeName == 'value'){
						select.value = attr.nodeValue;
						break;
					}
				}
			}
		},1);
	}.bind(this));
	
	$scope.auth = function(applnNo){
	var requestData = {};
	if(storage()){
		requestData['strSearchApplicationNumber'] = Storage.get('applnNo');
	}else{
		var data = window.location.href.split('=')[1];
		requestData['strSearchApplicationNumber'] = data;
	}
	var href = 'http://10.114.188.99:8081/ApplicationAuth/'+requestData['strSearchApplicationNumber'].replace('#','');
	$http.get(href).success(function (data) {	
		//$scope.response = responseBody;
		data.backURI = "IPApplicationList.html";
		window.location.href = "Successful.html?data="+JSON.stringify(data);
		
	}).error(function(data){
		alert(data.message);
	});

}
});


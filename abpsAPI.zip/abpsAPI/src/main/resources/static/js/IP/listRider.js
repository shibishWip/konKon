
$(function(){
	
	$('table').tableWidthCalc();
	$('[dialog-id]').showDialog();	
	$('#Add').on('click',function(){
		window.location.href = 'IPRiderNew.html';
	});	
	$.support.cors = true;
})

var listModule = angular.module('RiderListModule',[]).config(function($httpProvider) {
    $httpProvider.defaults.headers.put['Accept'] = 'application/json, text/javascript, */*; q=0.01'; 
    $httpProvider.defaults.headers.post['Accept'] = 'application/json, text/javascript, */*; q=0.01';  
});
listModule.controller('RiderListController',function($scope,$http){

	$scope.callBack = function(){		
		var requestData = {};
		requestData['strRiderType'] = $scope.RecordType;
		requestData['strRiderCode'] = $scope.RiderCode;
		requestData['maker_ID'] = $scope.MakerId;
		requestData['strUWCode'] = $scope.Underwriter;
		requestData['strStatus'] = $scope.Status;
		
		
		$http.post('http://localhost:8080/IPRider/RiderLISTING',requestData).then(function (data) {
			
		
				console.info(data.data);
			var responseData = data.data.responseBody;
			var count=0;
			for(var l in responseData){
				responseData[count].trClassValid = (count%2==0)?'age-table-bluetr':'';
				count++;
			}
			$scope.searchResults = responseData;
			window.setTimeout(function(){$('#riderListTable').tableWidthCalc();},1);
		}.bind(this));
		
		
		
	}
	$scope.view = function(riderCode,uwCode){
	var href = 'IPRiderDetail.html';
		if(storage()){
			Storage.set('riderCode',riderCode);
			Storage.set('uwCode',uwCode);
		}else{
			href += '?uwCode='+uwCode+'&riderCode='+riderCode;
			
		}
		window.location.href = href;
	}
});
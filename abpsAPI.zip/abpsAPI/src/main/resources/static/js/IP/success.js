
$(function(){
	//$('#done').on('click',function(){
	//	window.location.href = 'IPApplicationList.html';
	//});	

})

var successModule = angular.module('SuccessModual',[]);

successModule.controller('SuccessController',function($scope){
			var str = window.location.href.split('=')[1];
			$scope.data = eval('(' + str + ')');
		});
		
successModule.controller('buttonCtrl',function($scope){	
		var str = window.location.href.split('=')[1];
		$scope.data = eval('(' + str + ')');		
		$scope.done = function(backURI){	
	
		window.location.href = backURI;

	}
});



		
		

		

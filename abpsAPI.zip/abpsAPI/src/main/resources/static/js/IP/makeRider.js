$(function(){
	$('#Done').on('click',function(){
		if($.ageValidation()){
			var requestData={};
			requestData.group_id="8800";
			requestData.ctrl_1="88";
			requestData.ctrl_2="001";
			requestData.ctrl_3="000";
			requestData.ctrl_4="0000";
			requestData.strLocalName="localName";
			//requestData.strMaker_ID="SYSTEM";
			$('input[name]:not([type="radio"]),select[name]').each(function(){
				requestData[$(this).attr('name')] = $(this).val();
			});
			
			console.info(requestData);
			$.support.cors = true;
			$.ajax({
				type:"POST",	
				url: "http://localhost:8080/IPRider/RiderADD",
				contentType:"text/html",
				data: JSON.stringify(requestData),
				success:function(data){
					if(data.responseBody.message){
						alert(data.responseBody.message);
					}else{	
						data.responseBody.backURI= "IPRiderList.html";
						window.location.href = "Successful.html?data="+JSON.stringify(data.responseBody);
					}
				},
				error:function(data){
					console.info(data);
				}
			});
		}
	});
	
})

package com.citi.cards.abps.json.response;

import org.springframework.stereotype.Component;

@Component

public class Ica80OutAreaCrd {

	private String ica80_do_crd_embosser_name_1;

	private String ica80_do_crd_acct_nbr;

	private String ica80_do_crd_new_card_nbr;

	private String ica80_do_crd_status;

	private String ica80_do_crd_block_code;

	private String ica80_do_crd_date_expire;

	private String ica80_do_crd_cust_nbr;

	private int ica80_do_crd_cust_org;

	private int ica80_do_crd_type;

	private String ica80_do_crd_card_nbr;

	private int ica80_do_crd_org;

	public String getIca80_do_crd_acct_nbr() {
		return ica80_do_crd_acct_nbr;
	}

	public void setIca80_do_crd_acct_nbr(String ica80_do_crd_acct_nbr) {
		this.ica80_do_crd_acct_nbr = ica80_do_crd_acct_nbr;
	}

	public String getIca80_do_crd_new_card_nbr() {
		return ica80_do_crd_new_card_nbr;
	}

	public void setIca80_do_crd_new_card_nbr(String ica80_do_crd_new_card_nbr) {
		this.ica80_do_crd_new_card_nbr = ica80_do_crd_new_card_nbr;
	}

	public String getIca80_do_crd_status() {
		return ica80_do_crd_status;
	}

	public void setIca80_do_crd_status(String ica80_do_crd_status) {
		this.ica80_do_crd_status = ica80_do_crd_status;
	}

	public String getIca80_do_crd_block_code() {
		return ica80_do_crd_block_code;
	}

	public void setIca80_do_crd_block_code(String ica80_do_crd_block_code) {
		this.ica80_do_crd_block_code = ica80_do_crd_block_code;
	}

	public String getIca80_do_crd_date_expire() {
		return ica80_do_crd_date_expire;
	}

	public void setIca80_do_crd_date_expire(String ica80_do_crd_date_expire) {
		this.ica80_do_crd_date_expire = ica80_do_crd_date_expire;
	}

	public String getIca80_do_crd_cust_nbr() {
		return ica80_do_crd_cust_nbr;
	}

	public void setIca80_do_crd_cust_nbr(String ica80_do_crd_cust_nbr) {
		this.ica80_do_crd_cust_nbr = ica80_do_crd_cust_nbr;
	}

	public int getIca80_do_crd_cust_org() {
		return ica80_do_crd_cust_org;
	}

	public void setIca80_do_crd_cust_org(int ica80_do_crd_cust_org) {
		this.ica80_do_crd_cust_org = ica80_do_crd_cust_org;
	}

	public int getIca80_do_crd_type() {
		return ica80_do_crd_type;
	}

	public void setIca80_do_crd_type(int ica80_do_crd_type) {
		this.ica80_do_crd_type = ica80_do_crd_type;
	}

	public String getIca80_do_crd_card_nbr() {
		return ica80_do_crd_card_nbr;
	}

	public void setIca80_do_crd_card_nbr(String ica80_do_crd_card_nbr) {
		this.ica80_do_crd_card_nbr = ica80_do_crd_card_nbr;
	}

	public int getIca80_do_crd_org() {
		return ica80_do_crd_org;
	}

	public void setIca80_do_crd_org(int ica80_do_crd_org) {
		this.ica80_do_crd_org = ica80_do_crd_org;
	}

	public void setIca80_do_crd_embosser_name_1(String ica80_do_crd_embosser_name_1) {
		this.ica80_do_crd_embosser_name_1 = ica80_do_crd_embosser_name_1;
	}

	@Override
	public String toString() {
		return "ClassPojo [ica80_do_crd_embosser_name_1 = " + ica80_do_crd_embosser_name_1
				+ ", ica80_do_crd_acct_nbr = " + ica80_do_crd_acct_nbr + ", ica80_do_crd_new_card_nbr = "
				+ ica80_do_crd_new_card_nbr + ", ica80_do_crd_status = " + ica80_do_crd_status
				+ ", ica80_do_crd_block_code = " + ica80_do_crd_block_code + ", ica80_do_crd_date_expire = "
				+ ica80_do_crd_date_expire + ", ica80_do_crd_cust_nbr = " + ica80_do_crd_cust_nbr
				+ ", ica80_do_crd_cust_org = " + ica80_do_crd_cust_org + ", ica80_do_crd_type = " + ica80_do_crd_type
				+ ", ica80_do_crd_card_nbr = " + ica80_do_crd_card_nbr + ", ica80_do_crd_org = " + ica80_do_crd_org
				+ "]";
	}
}

package com.citi.cards.abps.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.citi.cards.abps.entity.ExceptionEntity;
import com.citi.cards.abps.entity.pojo.AccountsEntity;
import com.citi.cards.abps.entity.pojo.AccountsListEntity;
import com.citi.cards.abps.entity.pojo.AccountsPKClass;
import com.citi.cards.abps.repository.AccountsRepository;
import com.citi.cards.abps.service.AccountsService;
import com.citi.cards.abps.util.UtilityBean;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class AccountsServiceImpl implements AccountsService {
	@Autowired
	AccountsRepository abpsAccRep;
	@Autowired
	Environment env;

	private static ExceptionEntity exceptionEntity = null;

	@Override
	public List<AccountsListEntity> find(Map conditions) throws Exception {
		ObjectMapper objM = new ObjectMapper();
		String retstr = objM.writeValueAsString(conditions);
		AccountsPKClass obj = objM.readValue(retstr, AccountsPKClass.class);

		return abpsAccRep.findByConditions(conditions);
	}

	@Override
	public AccountsEntity enquiry(String cardNum) throws Exception {
		AccountsEntity primarykey = getPKClass(cardNum);
		return abpsAccRep.enquiry(primarykey);
	}

	@Override
	public void update(AccountsEntity bean) throws Exception {
		if (this.exist(bean)) {
			abpsAccRep.delete(bean);
			this.save(bean);
		} else {
			throw new Exception("ABPS " + bean.getStrAcctNmbr() + " IS NOT EXIST!");
		}

	}

	@Override

	public void save(AccountsEntity bean) throws Exception {

		if (this.exist(bean)) {
			exceptionEntity = new ExceptionEntity("9999", bean.getStrUtilAcctNmbr(),
					"   BILL REGISTRATION IS ALREADY EXIST");
			throw new Exception(bean.getStrUtilAcctNmbr());
		} else {
			bean.setStrCreateTimeStamp(UtilityBean.getTimestamp());
			abpsAccRep.save(bean);
		}
	}

	@Override
	public void delete(AccountsEntity bean) throws Exception {
		if (this.exist(bean)) {
			bean.setStrStatus("E");
		} else {
			throw new Exception("ABPS " + bean.getStrUtilAcctNmbr() + " IS NOT AVAILABLE TO DELETE!");
		}

	}

	@Override
	public boolean exist(AccountsEntity bean) throws Exception {
		AccountsEntity pkClass = new AccountsEntity();
		pkClass.setStrCardOrg(bean.getStrCardOrg());
		pkClass.setStrCardLogo(bean.getStrCardLogo());
		pkClass.setStrCardNmbr(bean.getStrCardNmbr());
		pkClass.setStrMerchOrg(bean.getStrMerchOrg());
		pkClass.setStrMerchNmbr(bean.getStrMerchNmbr());
		pkClass.setStrUtilAcctNmbr(bean.getStrUtilAcctNmbr());
		return abpsAccRep.exist(pkClass);
	}

	public AccountsEntity getPKClass(String cardNum) {
		AccountsEntity pkClass = new AccountsEntity();
		pkClass.setStrCardNmbr(cardNum);
		return pkClass;
	}

	@Override
	public void updateStatus(AccountsEntity bean, String status) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean exist(AccountsPKClass bean) throws Exception {
		AccountsPKClass pkClass = new AccountsPKClass();
		pkClass.setStrCardOrg(bean.getStrCardOrg());
		pkClass.setStrCardLogo(bean.getStrCardLogo());
		pkClass.setStrCardNmbr(bean.getStrCardNmbr());
		pkClass.setStrMerchOrg(bean.getStrMerchOrg());
		pkClass.setStrMerchNmbr(bean.getStrMerchNmbr());
		pkClass.setStrUtilAcctNmbr(bean.getStrUtilAcctNmbr());
		return abpsAccRep.exist(pkClass);
	}

}

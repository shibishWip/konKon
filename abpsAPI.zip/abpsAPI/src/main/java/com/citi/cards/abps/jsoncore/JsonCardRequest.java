package com.citi.cards.abps.jsoncore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.citi.cards.abps.entity.pojo.AccountsEntity;
import com.citi.cards.abps.json.request.AbpsCardsInqReq;
import com.citi.cards.abps.json.request.EUACA024Operation;
import com.citi.cards.abps.json.request.Euica80InArea;
import com.citi.cards.abps.json.request.Mca80HeaderData;
import com.citi.cards.abps.json.request.Mca80InData;
import com.citi.cards.abps.json.request.UtlCwsMessageInterface801;

@Component
@Service
public class JsonCardRequest {

	@Autowired
	AbpsCardsInqReq abpsCardsInqReq;
	@Autowired
	Mca80HeaderData mca80HeaderData;
	@Autowired
	Mca80InData mca80InData;
	@Autowired
	Euica80InArea euica80InArea;
	@Autowired
	UtlCwsMessageInterface801 utlCwsMessageInterface801;
	@Autowired
	EUACA024Operation euaca024Operation;

	// abpsCardsInq - REQ
	public String abpsCardsInqRequest(AccountsEntity entityObj) throws Exception {

		mca80InData.setMca80_in_message_id(5980);
		mca80InData.setMca80_in_req_time(new java.util.Date().getTime());
		mca80InData.setMca80_in_term_id("00000000SG");
		mca80InData.setMca80_in_user(entityObj.getStrCreateUser());
		mca80InData.setMca80_in_version(4);
		mca80HeaderData.setMca80_in_data(mca80InData);
		utlCwsMessageInterface801.setMca80_header_data(mca80HeaderData);

		euica80InArea.setIca80_di_card_nbr(entityObj.getStrCardNmbr());
		euica80InArea.setIca80_di_org(entityObj.getStrCardOrg());
		utlCwsMessageInterface801.setEuica80_in_area(euica80InArea);

		euaca024Operation.setUtl_cws_message_interface801(utlCwsMessageInterface801);
		abpsCardsInqReq.setEUACA024Operation(euaca024Operation);

		com.google.gson.Gson gson = new com.google.gson.Gson();
		String request = gson.toJson(abpsCardsInqReq);

		System.out.println("JSON_MAPPER    *** " + request);
		return request;
	}

}

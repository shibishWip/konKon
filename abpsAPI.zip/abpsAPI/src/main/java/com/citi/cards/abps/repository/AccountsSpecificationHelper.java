package com.citi.cards.abps.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.citi.cards.abps.entity.pojo.AccountsEntity;

@Component
public class AccountsSpecificationHelper {

	public static Specification<AccountsEntity> findAccounts(final Map conditions) {

		return new Specification<AccountsEntity>() {/// for criterial query, we
													/// don't need to declare a
													/// query (method) for every
													/// needed combination
			public Predicate toPredicate(Root<AccountsEntity> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				List<Predicate> list = new ArrayList<Predicate>();
				Set set = conditions.keySet();

				if (set != null && set.size() > 0) {
					for (Object obj : set) {
						String key = (String) obj;
						String value = String.valueOf(conditions.get(key));
						if (value != null && !("".equalsIgnoreCase(value) || "null".equalsIgnoreCase(value)))
							list.add(cb.equal(root.get(key).as(String.class), value));

					}
				}
				Predicate[] p = new Predicate[list.size()];
				return cb.and(list.toArray(p));

			}

		};
	}

}

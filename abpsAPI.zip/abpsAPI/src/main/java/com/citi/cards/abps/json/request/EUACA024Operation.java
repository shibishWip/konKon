package com.citi.cards.abps.json.request;

import org.springframework.stereotype.Component;

@Component
public class EUACA024Operation {
	private UtlCwsMessageInterface801 utl_cws_message_interface801;

	public UtlCwsMessageInterface801 getUtl_cws_message_interface801() {
		return utl_cws_message_interface801;
	}

	public void setUtl_cws_message_interface801(UtlCwsMessageInterface801 utl_cws_message_interface801) {
		this.utl_cws_message_interface801 = utl_cws_message_interface801;
	}

	@Override
	public String toString() {
		return "ClassPojo [utl_cws_message_interface801 = " + utl_cws_message_interface801 + "]";
	}
}

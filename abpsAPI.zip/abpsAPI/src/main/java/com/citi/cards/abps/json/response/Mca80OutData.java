
package com.citi.cards.abps.json.response;

import org.springframework.stereotype.Component;

@Component

public class Mca80OutData {

	private long mca80_out_resp_time;

	private int mca80_out_resp_code;

	private String mca80_out_term_id;

	private int mca80_out_resp_format;

	private String mca80_out_more_ind;

	private String mca80_out_resp_flag;

	private int mca80_out_message_id;

	private int mca80_out_version;

	private String mca80_out_user;

	public long getMca80_out_resp_time() {
		return mca80_out_resp_time;
	}

	public void setMca80_out_resp_time(long mca80_out_resp_time) {
		this.mca80_out_resp_time = mca80_out_resp_time;
	}

	public int getMca80_out_resp_code() {
		return mca80_out_resp_code;
	}

	public void setMca80_out_resp_code(int mca80_out_resp_code) {
		this.mca80_out_resp_code = mca80_out_resp_code;
	}

	public String getMca80_out_term_id() {
		return mca80_out_term_id;
	}

	public void setMca80_out_term_id(String mca80_out_term_id) {
		this.mca80_out_term_id = mca80_out_term_id;
	}

	public int getMca80_out_resp_format() {
		return mca80_out_resp_format;
	}

	public void setMca80_out_resp_format(int mca80_out_resp_format) {
		this.mca80_out_resp_format = mca80_out_resp_format;
	}

	public String getMca80_out_more_ind() {
		return mca80_out_more_ind;
	}

	public void setMca80_out_more_ind(String mca80_out_more_ind) {
		this.mca80_out_more_ind = mca80_out_more_ind;
	}

	public String getMca80_out_resp_flag() {
		return mca80_out_resp_flag;
	}

	public void setMca80_out_resp_flag(String mca80_out_resp_flag) {
		this.mca80_out_resp_flag = mca80_out_resp_flag;
	}

	public int getMca80_out_message_id() {
		return mca80_out_message_id;
	}

	public void setMca80_out_message_id(int mca80_out_message_id) {
		this.mca80_out_message_id = mca80_out_message_id;
	}

	public int getMca80_out_version() {
		return mca80_out_version;
	}

	public void setMca80_out_version(int mca80_out_version) {
		this.mca80_out_version = mca80_out_version;
	}

	public String getMca80_out_user() {
		return mca80_out_user;
	}

	public void setMca80_out_user(String mca80_out_user) {
		this.mca80_out_user = mca80_out_user;
	}

	@Override
	public String toString() {
		return "ClassPojo [mca80_out_resp_time = " + mca80_out_resp_time + ", mca80_out_resp_code = "
				+ mca80_out_resp_code + ", mca80_out_term_id = " + mca80_out_term_id + ", mca80_out_resp_format = "
				+ mca80_out_resp_format + ", mca80_out_more_ind = " + mca80_out_more_ind + ", mca80_out_resp_flag = "
				+ mca80_out_resp_flag + ", mca80_out_message_id = " + mca80_out_message_id + ", mca80_out_version = "
				+ mca80_out_version + ", mca80_out_user = " + mca80_out_user + "]";
	}
}

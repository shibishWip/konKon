package com.citi.cards.abps.entity.pojo;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "EUUM_UTIL_MERCH")
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantsPKClass implements Serializable {
	@Id
	@Column(name = "MERCH_ORG")
	private short StrMerchOrg;
	@Id
	@Column(name = "MERCH_NMBR")
	private BigDecimal StrMerchNmbr;

	public short getStrMerchOrg() {
		return StrMerchOrg;
	}

	public void setStrMerchOrg(short strMerchOrg) {
		StrMerchOrg = strMerchOrg;
	}

	public BigDecimal getStrMerchNmbr() {
		return StrMerchNmbr;
	}

	public void setStrMerchNmbr(BigDecimal strMerchNmbr) {
		StrMerchNmbr = strMerchNmbr;
	}

}

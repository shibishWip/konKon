
package com.citi.cards.abps.json.response;

import org.springframework.stereotype.Component;

@Component

public class Euica80OutArea {

	private Ica80OutAreaCrd ica80_out_area_crd;

	private Ica80OutAreaAct ica80_out_area_act;

	private Ica80OutAreaSys ica80_out_area_sys;

	public Ica80OutAreaCrd getIca80_out_area_crd() {
		return ica80_out_area_crd;
	}

	public void setIca80_out_area_crd(Ica80OutAreaCrd ica80_out_area_crd) {
		this.ica80_out_area_crd = ica80_out_area_crd;
	}

	public Ica80OutAreaAct getIca80_out_area_act() {
		return ica80_out_area_act;
	}

	public void setIca80_out_area_act(Ica80OutAreaAct ica80_out_area_act) {
		this.ica80_out_area_act = ica80_out_area_act;
	}

	public Ica80OutAreaSys getIca80_out_area_sys() {
		return ica80_out_area_sys;
	}

	public void setIca80_out_area_sys(Ica80OutAreaSys ica80_out_area_sys) {
		this.ica80_out_area_sys = ica80_out_area_sys;
	}

	@Override
	public String toString() {
		return "ClassPojo [ica80_out_area_crd = " + ica80_out_area_crd + ", ica80_out_area_act = " + ica80_out_area_act
				+ ", ica80_out_area_sys = " + ica80_out_area_sys + "]";
	}
}

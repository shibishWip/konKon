
package com.citi.cards.abps.json.response;

import org.springframework.stereotype.Component;

@Component

public class Ica80OutAreaAct {

	private double ica80_do_act_amt_memo_cr;

	private double ica80_do_act_amt_memo_db;

	private int ica80_do_act_rel_org;

	private String ica80_do_act_crlimit;

	private int ica80_do_act_cycle_due;

	private String ica80_do_act_status;

	private String ica80_do_act_risk_level;

	private double ica80_do_act_curr_balance;

	private String ica80_do_act_block_code_2;

	private double ica80_do_act_amnt_disp_items;

	private String ica80_do_act_rel_nbr;

	private String ica80_do_act_block_code_1;

	public double getIca80_do_act_amt_memo_cr() {
		return ica80_do_act_amt_memo_cr;
	}

	public void setIca80_do_act_amt_memo_cr(double ica80_do_act_amt_memo_cr) {
		this.ica80_do_act_amt_memo_cr = ica80_do_act_amt_memo_cr;
	}

	public double getIca80_do_act_amt_memo_db() {
		return ica80_do_act_amt_memo_db;
	}

	public void setIca80_do_act_amt_memo_db(double ica80_do_act_amt_memo_db) {
		this.ica80_do_act_amt_memo_db = ica80_do_act_amt_memo_db;
	}

	public int getIca80_do_act_rel_org() {
		return ica80_do_act_rel_org;
	}

	public void setIca80_do_act_rel_org(int ica80_do_act_rel_org) {
		this.ica80_do_act_rel_org = ica80_do_act_rel_org;
	}

	public String getIca80_do_act_crlimit() {
		return ica80_do_act_crlimit;
	}

	public void setIca80_do_act_crlimit(String ica80_do_act_crlimit) {
		this.ica80_do_act_crlimit = ica80_do_act_crlimit;
	}

	public int getIca80_do_act_cycle_due() {
		return ica80_do_act_cycle_due;
	}

	public void setIca80_do_act_cycle_due(int ica80_do_act_cycle_due) {
		this.ica80_do_act_cycle_due = ica80_do_act_cycle_due;
	}

	public String getIca80_do_act_status() {
		return ica80_do_act_status;
	}

	public void setIca80_do_act_status(String ica80_do_act_status) {
		this.ica80_do_act_status = ica80_do_act_status;
	}

	public String getIca80_do_act_risk_level() {
		return ica80_do_act_risk_level;
	}

	public void setIca80_do_act_risk_level(String ica80_do_act_risk_level) {
		this.ica80_do_act_risk_level = ica80_do_act_risk_level;
	}

	public double getIca80_do_act_curr_balance() {
		return ica80_do_act_curr_balance;
	}

	public void setIca80_do_act_curr_balance(double ica80_do_act_curr_balance) {
		this.ica80_do_act_curr_balance = ica80_do_act_curr_balance;
	}

	public String getIca80_do_act_block_code_2() {
		return ica80_do_act_block_code_2;
	}

	public void setIca80_do_act_block_code_2(String ica80_do_act_block_code_2) {
		this.ica80_do_act_block_code_2 = ica80_do_act_block_code_2;
	}

	public double getIca80_do_act_amnt_disp_items() {
		return ica80_do_act_amnt_disp_items;
	}

	public void setIca80_do_act_amnt_disp_items(double ica80_do_act_amnt_disp_items) {
		this.ica80_do_act_amnt_disp_items = ica80_do_act_amnt_disp_items;
	}

	public String getIca80_do_act_rel_nbr() {
		return ica80_do_act_rel_nbr;
	}

	public void setIca80_do_act_rel_nbr(String ica80_do_act_rel_nbr) {
		this.ica80_do_act_rel_nbr = ica80_do_act_rel_nbr;
	}

	public String getIca80_do_act_block_code_1() {
		return ica80_do_act_block_code_1;
	}

	public void setIca80_do_act_block_code_1(String ica80_do_act_block_code_1) {
		this.ica80_do_act_block_code_1 = ica80_do_act_block_code_1;
	}

	@Override
	public String toString() {
		return "ClassPojo [ica80_do_act_amt_memo_cr = " + ica80_do_act_amt_memo_cr + ", ica80_do_act_amt_memo_db = "
				+ ica80_do_act_amt_memo_db + ", ica80_do_act_rel_org = " + ica80_do_act_rel_org
				+ ", ica80_do_act_crlimit = " + ica80_do_act_crlimit + ", ica80_do_act_cycle_due = "
				+ ica80_do_act_cycle_due + ", ica80_do_act_status = " + ica80_do_act_status
				+ ", ica80_do_act_risk_level = " + ica80_do_act_risk_level + ", ica80_do_act_curr_balance = "
				+ ica80_do_act_curr_balance + ", ica80_do_act_block_code_2 = " + ica80_do_act_block_code_2
				+ ", ica80_do_act_amnt_disp_items = " + ica80_do_act_amnt_disp_items + ", ica80_do_act_rel_nbr = "
				+ ica80_do_act_rel_nbr + ", ica80_do_act_block_code_1 = " + ica80_do_act_block_code_1 + "]";
	}
}

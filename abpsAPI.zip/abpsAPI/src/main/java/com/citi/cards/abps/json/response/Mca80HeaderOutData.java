
package com.citi.cards.abps.json.response;

import org.springframework.stereotype.Component;

@Component

public class Mca80HeaderOutData {

	private Mca80OutData mca80_out_data;

	public Mca80OutData getMca80_out_data() {
		return mca80_out_data;
	}

	public void setMca80_out_data(Mca80OutData mca80_out_data) {
		this.mca80_out_data = mca80_out_data;
	}

	@Override
	public String toString() {
		return "ClassPojo [mca80_out_data = " + mca80_out_data + "]";
	}

}

package com.citi.cards.abps.entity;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class SuccessEntity {
	private String entity;
	private String keyField;
	private String KeyValue;
	private String action;

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getKeyField() {
		return keyField;
	}

	public void setKeyField(String keyField) {
		this.keyField = keyField;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getKeyValue() {
		return KeyValue;
	}

	public void setKeyValue(String keyValue) {
		KeyValue = keyValue;
	}

	public SuccessEntity() {

	}

	public SuccessEntity(String keyField, String keyValue) {
		this.keyField = keyField;
		this.KeyValue = keyValue;
	}
}

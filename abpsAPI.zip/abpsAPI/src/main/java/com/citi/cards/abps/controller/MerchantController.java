package com.citi.cards.abps.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.cards.abps.entity.pojo.MerchantsEntity;
import com.citi.cards.abps.service.MerchantsBasicService;
import com.citi.cards.abps.util.UtilityBean;

@RestController
@RequestMapping("/Merchants")
public class MerchantController extends BaseController {

	@Autowired
	MerchantsBasicService abpsMerchantService;

	@RequestMapping(value = "/MERCHLIST", method = RequestMethod.POST)
	public @ResponseBody Map<String, List<MerchantsEntity>> listUnderwriterRecords(@RequestBody String str,
			HttpServletResponse response) {
		System.out.println("Merchant Listingg " +str);

		UtilityBean.setAccessControll(response);

		Map retMap = new HashMap();

		try {
			Map conditions = (Map) UtilityBean.convert2ObjectFromStr(str, Map.class);
			List UnderwriterList = abpsMerchantService.find(conditions);
			retMap = genRetMap(retMap, UnderwriterList);
		} catch (Exception e) {
			e.printStackTrace();
			retMap = genRetMap(retMap, new Exception(e));
		} finally {
			// System.out.println("Merchant Listingg Final");
		}
		return retMap;

	}

}

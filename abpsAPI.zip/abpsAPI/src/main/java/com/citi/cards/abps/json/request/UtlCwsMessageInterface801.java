package com.citi.cards.abps.json.request;

import org.springframework.stereotype.Component;

@Component
public class UtlCwsMessageInterface801 {
	private Mca80HeaderData mca80_header_data;

	private Euica80InArea euica80_in_area;

	public Mca80HeaderData getMca80_header_data() {
		return mca80_header_data;
	}

	public void setMca80_header_data(Mca80HeaderData mca80_header_data) {
		this.mca80_header_data = mca80_header_data;
	}

	public Euica80InArea getEuica80_in_area() {
		return euica80_in_area;
	}

	public void setEuica80_in_area(Euica80InArea euica80_in_area) {
		this.euica80_in_area = euica80_in_area;
	}

	@Override
	public String toString() {
		return "ClassPojo [Mca80HeaderData = " + mca80_header_data + ", euica80_in_area = " + euica80_in_area + "]";
	}
}

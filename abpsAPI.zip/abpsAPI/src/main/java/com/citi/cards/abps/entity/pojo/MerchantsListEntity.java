package com.citi.cards.abps.entity.pojo;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "EUUM_UTIL_MERCH")
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantsListEntity implements Serializable {

	@Id
	@Column(name = "MERCH_ORG")
	private short StrMerchOrg;
	@Id
	@Column(name = "MERCH_NMBR")
	private BigDecimal StrMerchNmbr;
	@Column(name = "DESCRIPTION")
	private String StrDescription;
	@Column(name = "PYMT_CHANNEL")
	private String StrPymtChannel;

	public BigDecimal getStrMerchNmbr() {
		return StrMerchNmbr;
	}

	public void setStrMerchNmbr(BigDecimal strMerchNmbr) {
		StrMerchNmbr = strMerchNmbr;
	}

	public String getStrDescription() {
		return StrDescription;
	}

	public void setStrDescription(String strDescription) {
		StrDescription = strDescription;
	}

	public short getStrMerchOrg() {
		return StrMerchOrg;
	}

	public void setStrMerchOrg(short strMerchOrg) {
		StrMerchOrg = strMerchOrg;
	}

	public String getStrPymtChannel() {
		return StrPymtChannel;
	}

	public void setStrPymtChannel(String strPymtChannel) {
		StrPymtChannel = strPymtChannel;
	}

}

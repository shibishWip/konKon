package com.citi.cards.abps.entity;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope
public class LoginBean {

	public LoginBean() {
	}

	@NotEmpty(message = "Please enter your User Name.")
	private String StrCreateUser;

	private String strPassword;
	private String StrCardNmbr;
	private short StrCardOrg;
	private short StrCardLogo;
	private String sessionId;

	/**
	 * @return the strCreateUser
	 */
	public String getStrCreateUser() {
		return StrCreateUser;
	}

	/**
	 * @param strCreateUser
	 *            the strCreateUser to set
	 */
	public void setStrCreateUser(String strCreateUser) {
		StrCreateUser = strCreateUser;
	}

	/**
	 * @return the strPassword
	 */
	public String getStrPassword() {
		return strPassword;
	}

	/**
	 * @param strPassword
	 *            the strPassword to set
	 */
	public void setStrPassword(String strPassword) {
		this.strPassword = strPassword;
	}

	/**
	 * @return the strCardNmbr
	 */
	public String getStrCardNmbr() {
		return StrCardNmbr;
	}

	/**
	 * @param strCardNmbr
	 *            the strCardNmbr to set
	 */
	public void setStrCardNmbr(String strCardNmbr) {
		StrCardNmbr = strCardNmbr;
	}

	/**
	 * @return the strCardOrg
	 */
	public short getStrCardOrg() {
		return StrCardOrg;
	}

	/**
	 * @param strCardOrg
	 *            the strCardOrg to set
	 */
	public void setStrCardOrg(short strCardOrg) {
		StrCardOrg = strCardOrg;
	}

	/**
	 * @return the strCardLogo
	 */
	public short getStrCardLogo() {
		return StrCardLogo;
	}

	/**
	 * @param strCardLogo
	 *            the strCardLogo to set
	 */
	public void setStrCardLogo(short strCardLogo) {
		StrCardLogo = strCardLogo;
	}

	/**
	 * @return the sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}

	/**
	 * @param sessionId
	 *            the sessionId to set
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

}

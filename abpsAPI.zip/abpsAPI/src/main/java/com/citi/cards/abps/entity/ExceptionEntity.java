package com.citi.cards.abps.entity;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class ExceptionEntity {
	private String message;
	private String errType;
	private String errCode;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrType() {
		return errType;
	}

	public void setErrType(String errType) {
		this.errType = errType;
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public ExceptionEntity() {

	}

	public ExceptionEntity(String errCode, String errType, String message) {
		this.errType = errType;
		this.errCode = errCode;
		this.message = message;

	}

}

/**
 * 
 */
package com.citi.cards.abps.util;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citi.cards.abps.entity.ExceptionEntity;
import com.citi.cards.abps.entity.pojo.AccountsEntity;
import com.citi.cards.abps.entity.pojo.MerchantsEntity;
import com.citi.cards.abps.json.response.AbpsCardsInqRes;
import com.citi.cards.abps.jsoncore.ConnectItJson;
import com.citi.cards.abps.jsoncore.JsonCardResponse;
import com.citi.cards.abps.service.impl.MerchantsServiceImpl;

/**
 * @author ag07254
 *
 */
@Component
public class RegistrationDataCheck {

	@Autowired
	ConnectItJson connectItJson;
	@Autowired
	MerchantsServiceImpl abpsMerchantService;
	@Autowired
	JsonCardResponse jsonCardResponse;

	private static final String MAXDATE = "9999-12-31";
	private static final String MINDATE = "1951-01-01";
	private static final String MINDATEWITHTIMESTAMP = "1951-01-01 00:00:00.000000";
	private static final int CARDLOWVALUE = 16;

	private static final String[] STATUSREASON = { "00", "01", "02", "03", "13", "14", "54", "55", "56", "57", "66",
			"67", "68", "73", "74,75", "76", "77", "78", "89", "99", "47", "48,49 ", "08", "09,79", "25,000", "001",
			"002,003", "013", "014", "054,055", "056", "057", "066,67", "68", "073", "074", "075", "076", "077",
			"078,	089", "099", "047", "048,	049", "008", "009", "079", "025", "300", "301", "302", "303", "304",
			"305", "306", "307", "308", "309", "310", "311", "312", "313", "314", "315", "316", "317", "318", "319",
			"320", "321", "322", "323", "324", "325", "326", "327", "328", "329", "330", "331", "332", "333", "334",
			"335", "336", "337", "338", "339", "340", "341", "342", "343", "344", "345", "346", "347", "348", "349",
			"350", "351", "352", "353", "344", "355", "356" };

	private static String SPACES = " ";
	private static ExceptionEntity exceptionEntity = null;
	MerchantsEntity merchantsEntity = null;

	public ExceptionEntity dataCheck(AccountsEntity accountsEntity, MerchantsEntity merchantsEntity) throws Exception {

/*		String jsonStr = connectItJson.getJsonService(accountsEntity);
		com.google.gson.Gson gson = new com.google.gson.Gson();
		AbpsCardsInqRes abpsCardsInqRes = gson.fromJson(jsonStr, AbpsCardsInqRes.class);

		if (jsonStr != null) {
			//exceptionEntity = jsonCardResponse.otherValidations(merchantsEntity, abpsCardsInqRes);

			if (exceptionEntity.getErrCode().equals("0000")) {*/
				if (accountsEntity != null) {
					setDefault(accountsEntity);
					if (isGreaterThanZero(accountsEntity.getStrCardOrg())) {
						accountsEntity.setStrCustOrg(accountsEntity.getStrCardOrg());
						accountsEntity.setStrAcctOrg(accountsEntity.getStrCardOrg());
						if (isCardLogoValid(accountsEntity)) {
							if (isCardNmbrValid(accountsEntity)) {
								if (accountsEntity.getStrMerchOrg() == merchantsEntity.getStrMerchOrg()) {
									if (accountsEntity.getStrMerchNmbr().longValue() == merchantsEntity
											.getStrMerchNmbr().longValue()) {
										if (isUtilAcctNmbrValid(accountsEntity, merchantsEntity)) {
											if (isPymtChannelValid(accountsEntity)) {
												if (isStatusValid(accountsEntity.getStrStatus())) {
													accountsEntity.setStrCurrUtilStat(accountsEntity.getStrStatus());
													if (isStatusReasonValid(accountsEntity)) {
														accountsEntity.setStrCurrUtilStatRsn(
																accountsEntity.getStrStatusReason());
														if (isPaymentStatusValid(accountsEntity)) {
															if (isPaymentFreqValid(accountsEntity)) {
																if (ispaymentCycleValid(accountsEntity)) {
																	if (isPaymentStatusDateValid(accountsEntity)) {
																		if (isPaymentNbrRemValid(accountsEntity)) {
																			if (isPaymentFreeRemValid(accountsEntity)) {
																				if (iscardChkFlagValid(
																						accountsEntity)) {
																					if (isCardSeqNoValid(
																							accountsEntity)) {
																						if (isFirstPaymentDateValid(
																								accountsEntity)) {
																							if (isRefNmbrValild(
																									accountsEntity)) {
																								if (!isAllWhitespace(
																										accountsEntity
																												.getStrExBankCode())) {
																									if (!isAllWhitespace(
																											accountsEntity
																													.getStrExBranchCode())) {
																										if (!isAllWhitespace(
																												accountsEntity
																														.getStrBankAbbrev())) {
																											if (isGreaterThanZero(
																													accountsEntity
																															.getStrBankPayAmnt())) {
																												exceptionEntity = new ExceptionEntity(
																														"0000",
																														"success",
																														"All Validations are success");
																											} else {
																												exceptionEntity = new ExceptionEntity(
																														"9999",
																														"BankPayAmnt",
																														"6000 - Cap Amount Should not be empty. Please enter a value!!!");
																											}
																										} else {
																											exceptionEntity = new ExceptionEntity(
																													"9999",
																													"BankAbbrev",
																													"6001 - Bank Abbrevation Should not be empty. Please Enter!!!");
																										}
																									} else {
																										exceptionEntity = new ExceptionEntity(
																												"9999",
																												"ExBranchCode",
																												"6002 - BranchCode Should not be empty. Please Enter!!!");
																									}
																								} else {
																									exceptionEntity = new ExceptionEntity(
																											"9999",
																											"ExBankCode",
																											"6003 - BankCode Should not be empty. Please Enter!!!");
																								}
																							} else {
																								exceptionEntity = new ExceptionEntity(
																										"9999",
																										"StrUtilRefNmbr",
																										"6004- Utility NO# Should not be Spaces");
																							}
																						} else {
																							exceptionEntity = new ExceptionEntity(
																									"9999",
																									"StrFirstPaymentDate",
																									"600 - FirstPaymentDate Should be greater than 1951-01-01 and less than 99999-12-31");
																						}
																					} else {
																						exceptionEntity = new ExceptionEntity(
																								"9999", "StrCardSeqNo",
																								"6006 -Card Sequence No should be 1 ");
																					}
																				} else {
																					exceptionEntity = new ExceptionEntity(
																							"9999", "StrcardChkFlag",
																							"6009 - StrcardChkFlag Should be 1 or 2 or 3");
																				}
																			} else {
																				exceptionEntity = new ExceptionEntity(
																						"9999", "StrPaymentFreeRem",
																						"6010 - PaymentFreeRem Should be Numeric");
																			}
																		} else {
																			exceptionEntity = new ExceptionEntity(
																					"9999", "StrPaymentNbrRem",
																					"6011 - PaymentNbrRem Should be Numeric");
																		}
																	} else {
																		exceptionEntity = new ExceptionEntity("9999",
																				"StrPaymentStatusDate",
																				" 6012 - PaymentStatusDate Should be greater than 1951-01-01 and less than 99999-12-31");
																	}
																} else {
																	exceptionEntity = new ExceptionEntity("9999",
																			"StrPaymentCycle",
																			"6013 - PaymentCycle value range should be between 0 to 31 or can be 99");
																}
															} else {
																exceptionEntity = new ExceptionEntity("9999",
																		"StrPaymentFreq",
																		"6014 - PaymentFreq should be M,Y,2,3,4,6,5,D,W or Spaces");
															}
														} else {
															exceptionEntity = new ExceptionEntity("9999",
																	"StrPaymentStatus",
																	"6015 - PaymentStatus should be I or A or P or C or S or Spaces");
														}
													} else {
														exceptionEntity = new ExceptionEntity("9999", "StrStatusReason",
																"6016 - StrStatusReason Should be less than 400");
													}
												} else {
													exceptionEntity = new ExceptionEntity("9999", "StrStatus",
															"6017 - StrStatus Should be A or C or S or P or R");
												}
											} else {
												exceptionEntity = new ExceptionEntity("9999", "StrPymtChannel",
														"6018 - PaymentChannel Should be 0 / 1 / 2 / 3 / empty. Please enter a valid value!!!");
											}
										} else {
											exceptionEntity = new ExceptionEntity("9999", "StrUtilAcctNmbr",
													"6019 - UtilAcctNmbr Should not be Spaces or if Spaces, then Merch Type should be 'R'");
										}
									} else {
										exceptionEntity = new ExceptionEntity("9999", "StrMerchNmbr",
												"6020 - Merch Number Mismatch");
									}
								} else {
									exceptionEntity = new ExceptionEntity("9999", "StrMerchOrg", "6022 - Merch Org Mismatch");
								}
							} else {
								exceptionEntity = new ExceptionEntity("9999", "StrCardNmbr",
										"6023 - Card Nmbr should not be spaces or low values");
							}
						} else {
							exceptionEntity = new ExceptionEntity("9999", "StrCardLogo",
									"6024 - Card Logo should not be Zero");
						}
					} else {
						exceptionEntity = new ExceptionEntity("9999", "StrCardOrg",
								"6025 - Card Org should be greater than Zero");
					}
				}
			//}
		//}
		return exceptionEntity;
	}

	private boolean isGreaterThanZero(short strCardOrg) {
		boolean flag = false;
		if (strCardOrg > 0)
			flag = true;
		return flag;
	}

	private static AccountsEntity setDefault(AccountsEntity accountsEntity)
			throws IllegalArgumentException, IllegalAccessException, ParseException {
		// System.out.println(accountsEntity.getStrCardNmbr());
		for (Field f : accountsEntity.getClass().getDeclaredFields()) {
			f.setAccessible(true);
			// System.out.println(f.getType().getName());
			if (!f.getType().isPrimitive()) {
				if (f.getType().getName().endsWith("String")) {
					if (f.get(accountsEntity) == null) {
						f.set(accountsEntity, " ");
					}
				} else if (f.getType().getName().endsWith("BigDecimal")) {
					if (f.get(accountsEntity) == null) {
						f.set(accountsEntity, new BigDecimal(0));
					}
				} else if (f.getType().getName().endsWith("Date")) {
					if (f.get(accountsEntity) == null) {
						f.set(accountsEntity, getMinDate());
					}
				} else if (f.getType().getName().endsWith("Timestamp")) {
					if (f.get(accountsEntity) == null) {
						f.set(accountsEntity, getMinDateWithTimeStamp());
					}
				}
			}
		}
		accountsEntity.setStrEnrlUsrid(accountsEntity.getStrCreateUser());
		accountsEntity.setStrFixPymtExpMmyy((short) 9999);
		accountsEntity.setStrFixPymtEffDate(getMinDate());
		accountsEntity.setStrFixPymtAmt(new BigDecimal(0));
		accountsEntity.setStrEnrolDate(getCurrentDate());
		if (accountsEntity.getStrStatus().equals("P")) {
			accountsEntity.setStrEnrlAcdte(getMinDate());
		} else {
			accountsEntity.setStrEnrlAcdte(getCurrentDate());
		}

		accountsEntity.setStrLastPymtAmt(new BigDecimal(0));
		accountsEntity.setStrLastPymtCard(SPACES);
		accountsEntity.setStrReactivatedUser("SYSTEM");
		accountsEntity.setStrCancellationUser(SPACES);
		accountsEntity.setStrRecurPymtRejects((short) 0);
		accountsEntity.setStrMaintUser(accountsEntity.getStrCreateUser());
		accountsEntity.setStrVerifyUser(SPACES);
		accountsEntity.setStrReserveData(SPACES);
		accountsEntity.setStrStatMaintDte(getMinDate());
		accountsEntity.setStrRegExpDate(getMinDate());
		accountsEntity.setStrPymtEndDate(getMinDate());
		accountsEntity.setStrLastPymtDate(getMinDate());
		accountsEntity.setStrReactivatedDate(getMinDateWithTimeStamp());
		accountsEntity.setStrCancellationDate(getMinDateWithTimeStamp());
		accountsEntity.setStrVerifyTimeStamp(getMinDateWithTimeStamp());
		accountsEntity.setStrCreateTimeStamp(getCurrentTimeStamp());
		accountsEntity.setStrMaintTimeStamp(getCurrentTimeStamp());

		if ((accountsEntity.getStrUtilAcctNmbr2().isEmpty())) {
			accountsEntity.setStrUtilAcctNmbr2(SPACES);
		}
		if (isAllWhitespace(accountsEntity.getStrBillPayCycleDt())
				|| Integer.parseInt(accountsEntity.getStrBillPayCycleDt()) < 0
				|| Integer.parseInt(accountsEntity.getStrBillPayCycleDt()) > 31) {
			accountsEntity.setStrBillPayCycleDt("0");
		}
		if (isAllWhitespace(accountsEntity.getStrBillPayCycleDue())
				|| Integer.parseInt(accountsEntity.getStrBillPayCycleDue()) < 0
				|| Integer.parseInt(accountsEntity.getStrBillPayCycleDue()) > 31) {
			accountsEntity.setStrBillPayCycleDue("0");
		}
		srcValidation(accountsEntity);
		accountsEntity.setStrStatusDate(getMinDate());
		accountsEntity.setStrFixPymtFreeNbr((short) 0);
		accountsEntity.setStrGiftPymtNbrTot((short) 0);
		// System.out.println(accountsEntity);
		return accountsEntity;
	}

	private static Timestamp getCurrentTimeStamp() {
		return new Timestamp(new java.util.Date().getTime());
	}

	private static Date getCurrentDate() {
		return new Date(new java.util.Date().getTime());
	}

	private static Date getMinDate() throws ParseException {
		return Date.valueOf(MINDATE);
	}

	private static Date getMaxDate() throws ParseException {
		return Date.valueOf(MAXDATE);
	}

	private static Timestamp getMinDateWithTimeStamp() throws ParseException {
		return Timestamp.valueOf(MINDATEWITHTIMESTAMP);
	}

	/*
	 * private static boolean isBicCodeFlagValid(AccountsEntity accountsEntity){
	 * boolean flag = false; if(accountsEntity.getStrBicCodeFlag().equals("Y")
	 * || isAllWhitespace(accountsEntity.getStrBicCodeFlag())){ flag = true; }
	 * return flag; } private static boolean isBicCodeValid(AccountsEntity
	 * accountsEntity){ boolean flag = true;
	 * if(accountsEntity.getStrBicCodeFlag().equals("Y")){
	 * if(isAllWhitespace(accountsEntity.getStrBicCode())){ flag = false; } }
	 * return flag; }
	 */
	private static boolean isFirstPaymentDateValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (isAllWhitespace(accountsEntity.getStrFixPymt1stPydte().toString()))
			try {
				accountsEntity.setStrFixPymt1stPydte(getMinDate());
				flag = true;
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
		else
			try {
				if (isValidDate(accountsEntity.getStrFixPymt1stPydte()))
					flag = true;
			} catch (ParseException e) {
				e.printStackTrace();
			}
		return flag;
	}

	private static boolean isCardSeqNoValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (accountsEntity.getStrAltCardChkFlag().equals("1")) {
			if (isNumber(accountsEntity.getStrCardSeqNo()) || isAllWhitespace(accountsEntity.getStrCardSeqNo() + "")
					|| accountsEntity.getStrCardSeqNo() < 0) {
				accountsEntity.setStrCardSeqNo((short) 1);
				flag = true;
			}
		} else
			flag = true;
		return flag;
	}

	private static boolean isBankCodeValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (true)
			flag = true;
		return flag;
	}

	private static boolean isRefNmbrValild(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (!isAllWhitespace(accountsEntity.getStrUtilAcctNmbr()))
			flag = true;
		return flag;
	}

	private static boolean iscardChkFlagValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (isBetweenZeroToThree(accountsEntity.getStrAltCardChkFlag())) {
			flag = true;
		} else if (Integer.parseInt(accountsEntity.getStrAltCardChkFlag()) < 0
				|| isAllWhitespace(accountsEntity.getStrAltCardChkFlag())) {
			accountsEntity.setStrAltCardChkFlag("0");
			flag = true;
		} else
			flag = false;
		return flag;
	}
	/*
	 * private static void paymentExpMmyyValidation(AccountsEntity
	 * accountsEntity){ if(!isNumber(accountsEntity.getStrFixPymtExpMmyy()))
	 * accountsEntity.setStrFixPymtExpMmyy((short)9999); }
	 */

	private static boolean isPaymentNbrRemValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (isNumber(accountsEntity.getStrFixPymtNbrRem())
				&& !isAllWhitespace(accountsEntity.getStrFixPymtNbrRem() + ""))
			flag = true;
		else {
			if (isAllWhitespace(accountsEntity.getStrFixPymtNbrRem() + "")
					|| accountsEntity.getStrFixPymtNbrRem() < 0) {
				accountsEntity.setStrFixPymtNbrRem((short) 0);
				flag = true;
			} else
				flag = false;
		}
		return flag;
	}

	private static boolean isPaymentFreeRemValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (isNumber(accountsEntity.getStrFixPymtFreeRem())
				&& !isAllWhitespace(accountsEntity.getStrFixPymtFreeRem() + ""))
			flag = true;
		else {
			if (isAllWhitespace(accountsEntity.getStrFixPymtFreeRem() + "")
					|| accountsEntity.getStrFixPymtFreeRem() < 0) {
				accountsEntity.setStrFixPymtFreeRem((short) 0);
				flag = true;
			} else
				flag = false;
		}
		return flag;
	}

	private static boolean isPaymentStatusDateValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (isAllWhitespace(accountsEntity.getStrFixPymtStatDate().toString()))
			try {
				accountsEntity.setStrFixPymtStatDate(getMinDate());
				flag = true;
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
		else
			try {
				if (isValidDate(accountsEntity.getStrFixPymtStatDate()))
					flag = true;
			} catch (ParseException e) {
				e.printStackTrace();
			}
		return flag;
	}

	/*
	 * private static boolean isPaymentEffectDateValid(AccountsEntity
	 * accountsEntity){ boolean flag = false;
	 * if(isAllWhitespace(accountsEntity.getStrFixPymtEffDate().toString())) try
	 * { accountsEntity.setStrFixPymtEffDate(getMinDate()); flag = true; } catch
	 * (ParseException e) { e.printStackTrace(); } else try {
	 * if(isValidDate(accountsEntity.getStrFixPymtEffDate())) flag = true; }
	 * catch (ParseException e) { e.printStackTrace(); } return flag; }
	 */
	private static void srcValidation(AccountsEntity accountsEntity) {
		if (isAllWhitespace(accountsEntity.getStrSource()))
			accountsEntity.setStrSource("O");
	}

	private static boolean isCardNmbrValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if ((!isAllWhitespace(accountsEntity.getStrCardNmbr()))
				&& accountsEntity.getStrCardNmbr().length() >= CARDLOWVALUE)
			flag = true;
		return flag;
	}

	private static boolean isCardLogoValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (accountsEntity.getStrCardLogo() != 0)
			flag = true;
		return flag;
	}

	private static boolean isPymtChannelValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (isAllWhitespace(accountsEntity.getStrPymtChannel())) {
			accountsEntity.setStrPymtChannel("1");
			flag = true;
		} else if ((isBetweenZeroToThree(accountsEntity.getStrPymtChannel())))
			flag = true;
		else
			flag = false;
		return flag;
	}

	private static boolean isUtilAcctNmbrValid(AccountsEntity accountsEntity, MerchantsEntity merchantsEntity) {
		boolean flag = false;
		if (!(isAllWhitespace(accountsEntity.getStrUtilAcctNmbr())))
			flag = true;
		else if (isAllWhitespace(accountsEntity.getStrUtilAcctNmbr()) && merchantsEntity.getStrMerchType().equals("R"))
			flag = true;
		else
			flag = false;
		return flag;
	}

	private static boolean isStatusReasonValid(AccountsEntity accountsEntity) {

		boolean flag = false;
		if (isAllWhitespace(accountsEntity.getStrStatusReason())) {
			accountsEntity.setStrStatusReason("0");
			flag = true;
		} else if (Integer.parseInt(accountsEntity.getStrStatusReason()) < 400) {
			int count = 0;
			for (int i = 0; i < STATUSREASON.length; i++) {
				if (Integer.parseInt(accountsEntity.getStrStatusReason()) == Integer.parseInt(STATUSREASON[i]))
					count = 1;
			}
			if (count == 1)
				flag = true;
		} else
			flag = false;
		return flag;
	}

	private static boolean isPaymentStatusValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if (accountsEntity.getStrFixPymtStatus().equals('I') || accountsEntity.getStrFixPymtStatus().equals('A')
				|| accountsEntity.getStrFixPymtStatus().equals('P') || accountsEntity.getStrFixPymtStatus().equals('C')
				|| accountsEntity.getStrFixPymtStatus().equals('S')
				|| isAllWhitespace(accountsEntity.getStrFixPymtStatus()))
			flag = true;
		else
			accountsEntity.setStrFixPymtStatus(SPACES);
		return flag;
	}

	private static boolean isPaymentFreqValid(AccountsEntity accountsEntity) {
		boolean flag = false;

		if (accountsEntity.getStrFixPymtFreq().equals('M') || accountsEntity.getStrFixPymtFreq().equals('Y')
				|| accountsEntity.getStrFixPymtFreq().equals('2') || accountsEntity.getStrFixPymtFreq().equals('3')
				|| accountsEntity.getStrFixPymtFreq().equals('4') || accountsEntity.getStrFixPymtFreq().equals('6')
				|| accountsEntity.getStrFixPymtFreq().equals('5') || accountsEntity.getStrFixPymtFreq().equals('D')
				|| accountsEntity.getStrFixPymtFreq().equals('W')
				|| isAllWhitespace(accountsEntity.getStrFixPymtFreq()))
			flag = true;
		else
			accountsEntity.setStrFixPymtStatus(SPACES);
		return flag;
	}

	private static boolean ispaymentCycleValid(AccountsEntity accountsEntity) {
		boolean flag = false;
		if ((accountsEntity.getStrFixPymtCycle() >= 0 && accountsEntity.getStrFixPymtCycle() <= 31)
				|| accountsEntity.getStrFixPymtCycle() == 99) {
			flag = true;
		} else if (accountsEntity.getStrFixPymtCycle() < 0
				|| isAllWhitespace(accountsEntity.getStrFixPymtCycle() + "")) {
			accountsEntity.setStrFixPymtCycle((short) 0);
			flag = true;
		} else
			flag = false;
		return flag;
	}

	private static boolean isStatusValid(String string) {

		boolean flag = false;
		if (string.equals("A") || string.equals("C") || string.equals("S") || string.equals("P") || string.equals("R"))
			flag = true;
		return flag;
	}

	// REUSABLE DATA MEMBERS
	//
	//
	private static boolean isEmpty(BigDecimal bigDecimal) {

		boolean flag = true;
		if (bigDecimal != null && bigDecimal.longValue() > 0) // may negative
			flag = false;
		return flag;

	}

	private static boolean isEmpty(String value) {

		boolean flag = true;
		if (value != null && value.trim().length() > 0)
			flag = false;
		return flag;
	}

	private static boolean isNotEmpty(String value) {
		return (!(isEmpty(value)));
	}

	private static boolean isGreaterThanZero(BigDecimal bigDecimal) {

		boolean flag = false;
		if (bigDecimal.longValue() > 0)
			flag = true;
		return flag;
	}

	private static boolean isBetweenZeroToThree(String string) {/// datatype
																/// doubt

		boolean flag = false;
		if (!isAllWhitespace(string) && Integer.parseInt(string) >= 0 && Integer.parseInt(string) <= 3)
			flag = true;
		return flag;
	}

	private static boolean isAllWhitespace(String string) {
		boolean flag = false;
		if (string.trim().length() != string.length() || string.trim().isEmpty())
			flag = true;
		return flag;
	}

	private static boolean isValidDate(Date date) throws ParseException {
		boolean flag = false;
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		// Date date1 = (Date) sdf.parse(sdf.format(date));
		Date date2 = getMinDate();
		Date date3 = getMaxDate();
		if (date.compareTo(date2) >= 0 && date.compareTo(date3) <= 0)
			flag = true;
		return flag;
	}

	private static boolean isNumber(short s) {
		boolean flag = false;
		if (s >= Short.MIN_VALUE && s < Short.MAX_VALUE)
			flag = true;
		return flag;
	}

}

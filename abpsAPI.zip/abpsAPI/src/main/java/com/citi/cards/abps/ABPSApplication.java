package com.citi.cards.abps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ABPSApplication {

	public static void main(String[] args) {

		SpringApplication.run(ABPSApplication.class, args);
	}

}


package com.citi.cards.abps.json.response;

import org.springframework.stereotype.Component;

@Component
public class AbpsCardsInqRes {
	private EUACA024OperationResponse EUACA024OperationResponse;

	public EUACA024OperationResponse getEUACA024OperationResponse() {
		return EUACA024OperationResponse;
	}

	public void setEUACA024OperationResponse(EUACA024OperationResponse EUACA024OperationResponse) {
		this.EUACA024OperationResponse = EUACA024OperationResponse;
	}

	@Override
	public String toString() {
		return "ClassPojo [EUACA024OperationResponse = " + EUACA024OperationResponse + "]";
	}
}
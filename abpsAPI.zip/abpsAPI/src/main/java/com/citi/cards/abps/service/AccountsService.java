package com.citi.cards.abps.service;

import com.citi.cards.abps.entity.pojo.AccountsEntity;
import com.citi.cards.abps.entity.pojo.AccountsListEntity;
import com.citi.cards.abps.entity.pojo.AccountsPKClass;

public interface AccountsService extends AccountsBasicService<AccountsListEntity, AccountsEntity> {
	public AccountsEntity enquiry(String cardNum) throws Exception;

	public void save(AccountsEntity objABPSEntity) throws Exception;

	boolean exist(AccountsPKClass bean) throws Exception;

}

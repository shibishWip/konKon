package com.citi.cards.abps.service;

import java.math.BigDecimal;

import com.citi.cards.abps.entity.pojo.MerchantsEntity;
import com.citi.cards.abps.entity.pojo.MerchantsListEntity;

public interface MerchantsService extends MerchantsBasicService<MerchantsListEntity, MerchantsEntity> {
	public MerchantsEntity enquiry(short StrMerchOrg, BigDecimal StrMerchNmbr) throws Exception;
}

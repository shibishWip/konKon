package com.citi.cards.abps.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citi.cards.abps.entity.pojo.MerchantsEntity;
import com.citi.cards.abps.entity.pojo.MerchantsListEntity;
import com.citi.cards.abps.util.UtilityBean;

@Repository
public class MerchantsRepository {

	@PersistenceContext
	private EntityManager em;

	public List findByConditions(Map conditions) throws Exception {
		List accountsList = new ArrayList();
		try {
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<MerchantsListEntity> query = cb.createQuery(MerchantsListEntity.class);
			Root<MerchantsListEntity> root = query.from(MerchantsListEntity.class);
			Predicate predicate = UtilityBean.getPredicate(root, query, cb, conditions);

			query.where(predicate);

			List<Order> orderList = new ArrayList<Order>();
			orderList.add(cb.desc(root.get("StrMerchOrg").as(String.class)));

			Query q = em.createQuery(query.select(root));
			accountsList = q.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return accountsList;
	}

	public MerchantsEntity enquiry(MerchantsEntity primarkKey) throws Exception {

		MerchantsEntity merchantsEntity = new MerchantsEntity();
		merchantsEntity.setStrMerchOrg(primarkKey.getStrMerchOrg());
		merchantsEntity.setStrMerchNmbr(primarkKey.getStrMerchNmbr());
		try {
			merchantsEntity = em.find(MerchantsEntity.class, primarkKey);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return merchantsEntity;
	}

	public boolean exist(MerchantsEntity primarykey) throws Exception {
		MerchantsEntity merchantsEntity = enquiry(primarykey);
		if (merchantsEntity != null) {
			return true;
		} else {
			return false;
		}
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public void save(MerchantsEntity obj) throws Exception {
		try {
			em.persist(obj);
			em.flush();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public void update(MerchantsEntity obj) throws Exception {
		try {
			em.merge(obj);
			em.flush();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public void delete(MerchantsEntity obj) throws Exception {
		try {
			em.remove(obj);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

	}
}

package com.citi.cards.abps.entity.pojo;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Entity
@Table(name = "EUUA_UTIL_ACCT")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountsPKClass implements Serializable {
	private static final ObjectMapper objectMapper = new ObjectMapper()
			.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

	@Id
	@Column(name = "CARD_ORG")
	private short StrCardOrg;
	@Id
	@Column(name = "CARD_LOGO")
	private short StrCardLogo;
	@Id
	@Column(name = "CARD_NMBR")
	private String StrCardNmbr;
	@Id
	@Column(name = "MERCH_ORG")
	private short StrMerchOrg;
	@Id
	@Column(name = "MERCH_NMBR")
	private BigDecimal StrMerchNmbr;
	@Id
	@Column(name = "UTIL_ACCT_NMBR")
	private String StrUtilAcctNmbr;

	public short getStrCardOrg() {
		return StrCardOrg;
	}

	public void setStrCardOrg(short strCardOrg) {
		StrCardOrg = strCardOrg;
	}

	public short getStrCardLogo() {
		return StrCardLogo;
	}

	public void setStrCardLogo(short strCardLogo) {
		StrCardLogo = strCardLogo;
	}

	public String getStrCardNmbr() {
		return StrCardNmbr;
	}

	public void setStrCardNmbr(String strCardNmbr) {
		StrCardNmbr = strCardNmbr;
	}

	public short getStrMerchOrg() {
		return StrMerchOrg;
	}

	public void setStrMerchOrg(short strMerchOrg) {
		StrMerchOrg = strMerchOrg;
	}

	public BigDecimal getStrMerchNmbr() {
		return StrMerchNmbr;
	}

	public void setStrMerchNmbr(BigDecimal strMerchNmbr) {
		StrMerchNmbr = strMerchNmbr;
	}

	public String getStrUtilAcctNmbr() {
		return StrUtilAcctNmbr;
	}

	public void setStrUtilAcctNmbr(String strUtilAcctNmbr) {
		StrUtilAcctNmbr = strUtilAcctNmbr;
	}

	public static ObjectMapper getObjectmapper() {
		return objectMapper;
	}

}

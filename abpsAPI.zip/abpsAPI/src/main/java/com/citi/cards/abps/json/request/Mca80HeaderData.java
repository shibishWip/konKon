package com.citi.cards.abps.json.request;

import org.springframework.stereotype.Component;

@Component
public class Mca80HeaderData {
	private Mca80InData mca80_in_data;

	public Mca80InData getMca80_in_data() {
		return mca80_in_data;
	}

	public void setMca80_in_data(Mca80InData mca80_in_data) {
		this.mca80_in_data = mca80_in_data;
	}

	@Override
	public String toString() {
		return "ClassPojo [mca80_in_data = " + mca80_in_data + "]";
	}
}

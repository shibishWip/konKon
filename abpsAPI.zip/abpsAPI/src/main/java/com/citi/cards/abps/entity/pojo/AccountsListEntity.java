package com.citi.cards.abps.entity.pojo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "EUUA_UTIL_ACCT")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountsListEntity implements Serializable {

	@Id
	@Column(name = "CARD_ORG")
	private short StrCardOrg;
	@Id
	@Column(name = "CARD_LOGO")
	private short StrCardLogo;
	@Id
	@Column(name = "CARD_NMBR")
	private String StrCardNmbr;
	@Id
	@Column(name = "MERCH_ORG")
	private short StrMerchOrg;
	@Id
	@Column(name = "MERCH_NMBR")
	private BigDecimal StrMerchNmbr;
	@Id
	@Column(name = "UTIL_ACCT_NMBR")
	private String StrUtilAcctNmbr;

	@Column(name = "STATUS")
	private String StrStatus;
	@Column(name = "PYMT_CHANNEL")
	private String StrPymtChannel;
	@Column(name = "STATUS_REASON")
	private String StrStatusReason;
	@Column(name = "ENROL_DATE")
	private Date StrEnrolDate;
	@Column(name = "UTIL_OWNER_NAME")
	private String StrUtilOwnerName;
	@Column(name = "PROG_CODE")
	private String StrProgCode;
	@Column(name = "UTIL_ACCT_NMBR2")
	private String StrUtilAcctNmbr2;
	@Column(name = "CREATE_USER")
	private String StrCreateUser;
	@Column(name = "MAINT_TIME_STAMP")
	private Timestamp StrMaintTimeStamp;
	@Column(name = "MAINT_USER")
	private String StrMaintUser;
	@Column(name = "REACTIVATED_DATE")
	private Timestamp StrReactivatedDate;
	@Column(name = "REACTIVATED_USER")
	private String StrReactivatedUser;
	@Column(name = "BILL_PAY_CYCLE_DT")
	private String StrBillPayCycleDt;
	@Column(name = "BILL_PAY_CYCLE_DUE")
	private String StrBillPayCycleDue;
	@Column(name = "ALT_CARD_CHK_FLAG")
	private String StrAltCardChkFlag;
	@Column(name = "FIX_PYMT_STATUS")
	private String StrFixPymtStatus;
	@Column(name = "FIX_PYMT_FREQ")
	private String StrFixPymtFreq;
	@Column(name = "FIX_PYMT_CYCLE")
	private short StrFixPymtCycle;
	@Column(name = "FIX_PYMT_AMT")
	private BigDecimal StrFixPymtAmt;
	@Column(name = "FIX_PYMT_EFF_DATE")
	private Date StrFixPymtEffDate;
	@Column(name = "FIX_PYMT_STAT_DATE")
	private Date StrFixPymtStatDate;
	@Column(name = "FIX_PYMT_NBR_TOT")
	private short StrFixPymtNbrTot;
	@Column(name = "FIX_PYMT_NBR_REM")
	private short StrFixPymtNbrRem;
	@Column(name = "FIX_PYMT_FREE_NBR")
	private short StrFixPymtFreeNbr;
	@Column(name = "FIX_PYMT_FREE_REM")
	private short StrFixPymtFreeRem;
	@Column(name = "GIFT_PYMT_NBR_TOT")
	private short StrGiftPymtNbrTot;
	@Column(name = "GIFT_PYMT_NBR_REM")
	private short StrGiftPymtNbrRem;
	@Column(name = "FIX_PYMT_EXP_MMYY")
	private short StrFixPymtExpMmyy;
	@Column(name = "FIX_PYMT_1ST_PYDTE")
	private Date StrFixPymt1stPydte;
	@Column(name = "USER_TEXT_01")
	private String StrUserText01;
	@Column(name = "USER_TEXT_02")
	private String StrUserText02;
	@Column(name = "USER_TEXT_03")
	private String StrUserText03;
	@Column(name = "USER_TEXT_04")
	private String StrUserText04;
	@Column(name = "USER_TEXT_05")
	private String StrUserText05;
	@Column(name = "ACCT_NMBR")
	private String StrAcctNmbr;

	public String getStrAcctNmbr() {
		return StrAcctNmbr;
	}

	public void setStrAcctNmbr(String strAcctNmbr) {
		StrAcctNmbr = strAcctNmbr;
	}

	public short getStrCardOrg() {
		return StrCardOrg;
	}

	public void setStrCardOrg(short strCardOrg) {
		StrCardOrg = strCardOrg;
	}

	public short getStrCardLogo() {
		return StrCardLogo;
	}

	public void setStrCardLogo(short strCardLogo) {
		StrCardLogo = strCardLogo;
	}

	public String getStrCardNmbr() {
		return StrCardNmbr;
	}

	public void setStrCardNmbr(String strCardNmbr) {
		StrCardNmbr = strCardNmbr;
	}

	public short getStrMerchOrg() {
		return StrMerchOrg;
	}

	public void setStrMerchOrg(short strMerchOrg) {
		StrMerchOrg = strMerchOrg;
	}

	public BigDecimal getStrMerchNmbr() {
		return StrMerchNmbr;
	}

	public void setStrMerchNmbr(BigDecimal strMerchNmbr) {
		StrMerchNmbr = strMerchNmbr;
	}

	public String getStrUtilAcctNmbr() {
		return StrUtilAcctNmbr;
	}

	public void setStrUtilAcctNmbr(String strUtilAcctNmbr) {
		StrUtilAcctNmbr = strUtilAcctNmbr;
	}

	public String getStrStatus() {
		return StrStatus;
	}

	public void setStrStatus(String strStatus) {
		StrStatus = strStatus;
	}

	public String getStrPymtChannel() {
		return StrPymtChannel;
	}

	public void setStrPymtChannel(String strPymtChannel) {
		StrPymtChannel = strPymtChannel;
	}

	public String getStrStatusReason() {
		return StrStatusReason;
	}

	public void setStrStatusReason(String strStatusReason) {
		StrStatusReason = strStatusReason;
	}

	public Date getStrEnrolDate() {
		return StrEnrolDate;
	}

	public void setStrEnrolDate(Date strEnrolDate) {
		StrEnrolDate = strEnrolDate;
	}

	public String getStrUtilOwnerName() {
		return StrUtilOwnerName;
	}

	public void setStrUtilOwnerName(String strUtilOwnerName) {
		StrUtilOwnerName = strUtilOwnerName;
	}

	public String getStrProgCode() {
		return StrProgCode;
	}

	public void setStrProgCode(String strProgCode) {
		StrProgCode = strProgCode;
	}

	public String getStrUtilAcctNmbr2() {
		return StrUtilAcctNmbr2;
	}

	public void setStrUtilAcctNmbr2(String strUtilAcctNmbr2) {
		StrUtilAcctNmbr2 = strUtilAcctNmbr2;
	}

	public String getStrCreateUser() {
		return StrCreateUser;
	}

	public void setStrCreateUser(String strCreateUser) {
		StrCreateUser = strCreateUser;
	}

	public Timestamp getStrMaintTimeStamp() {
		return StrMaintTimeStamp;
	}

	public void setStrMaintTimeStamp(Timestamp strMaintTimeStamp) {
		StrMaintTimeStamp = strMaintTimeStamp;
	}

	public String getStrMaintUser() {
		return StrMaintUser;
	}

	public void setStrMaintUser(String strMaintUser) {
		StrMaintUser = strMaintUser;
	}

	public Timestamp getStrReactivatedDate() {
		return StrReactivatedDate;
	}

	public void setStrReactivatedDate(Timestamp strReactivatedDate) {
		StrReactivatedDate = strReactivatedDate;
	}

	public String getStrReactivatedUser() {
		return StrReactivatedUser;
	}

	public void setStrReactivatedUser(String strReactivatedUser) {
		StrReactivatedUser = strReactivatedUser;
	}

	public String getStrBillPayCycleDt() {
		return StrBillPayCycleDt;
	}

	public void setStrBillPayCycleDt(String strBillPayCycleDt) {
		StrBillPayCycleDt = strBillPayCycleDt;
	}

	public String getStrBillPayCycleDue() {
		return StrBillPayCycleDue;
	}

	public void setStrBillPayCycleDue(String strBillPayCycleDue) {
		StrBillPayCycleDue = strBillPayCycleDue;
	}

	public String getStrAltCardChkFlag() {
		return StrAltCardChkFlag;
	}

	public void setStrAltCardChkFlag(String strAltCardChkFlag) {
		StrAltCardChkFlag = strAltCardChkFlag;
	}

	public String getStrFixPymtStatus() {
		return StrFixPymtStatus;
	}

	public void setStrFixPymtStatus(String strFixPymtStatus) {
		StrFixPymtStatus = strFixPymtStatus;
	}

	public String getStrFixPymtFreq() {
		return StrFixPymtFreq;
	}

	public void setStrFixPymtFreq(String strFixPymtFreq) {
		StrFixPymtFreq = strFixPymtFreq;
	}

	public short getStrFixPymtCycle() {
		return StrFixPymtCycle;
	}

	public void setStrFixPymtCycle(short strFixPymtCycle) {
		StrFixPymtCycle = strFixPymtCycle;
	}

	public BigDecimal getStrFixPymtAmt() {
		return StrFixPymtAmt;
	}

	public void setStrFixPymtAmt(BigDecimal strFixPymtAmt) {
		StrFixPymtAmt = strFixPymtAmt;
	}

	public Date getStrFixPymtEffDate() {
		return StrFixPymtEffDate;
	}

	public void setStrFixPymtEffDate(Date strFixPymtEffDate) {
		StrFixPymtEffDate = strFixPymtEffDate;
	}

	public Date getStrFixPymtStatDate() {
		return StrFixPymtStatDate;
	}

	public void setStrFixPymtStatDate(Date strFixPymtStatDate) {
		StrFixPymtStatDate = strFixPymtStatDate;
	}

	public short getStrFixPymtNbrTot() {
		return StrFixPymtNbrTot;
	}

	public void setStrFixPymtNbrTot(short strFixPymtNbrTot) {
		StrFixPymtNbrTot = strFixPymtNbrTot;
	}

	public short getStrFixPymtNbrRem() {
		return StrFixPymtNbrRem;
	}

	public void setStrFixPymtNbrRem(short strFixPymtNbrRem) {
		StrFixPymtNbrRem = strFixPymtNbrRem;
	}

	public short getStrFixPymtFreeNbr() {
		return StrFixPymtFreeNbr;
	}

	public void setStrFixPymtFreeNbr(short strFixPymtFreeNbr) {
		StrFixPymtFreeNbr = strFixPymtFreeNbr;
	}

	public short getStrFixPymtFreeRem() {
		return StrFixPymtFreeRem;
	}

	public void setStrFixPymtFreeRem(short strFixPymtFreeRem) {
		StrFixPymtFreeRem = strFixPymtFreeRem;
	}

	public short getStrGiftPymtNbrTot() {
		return StrGiftPymtNbrTot;
	}

	public void setStrGiftPymtNbrTot(short strGiftPymtNbrTot) {
		StrGiftPymtNbrTot = strGiftPymtNbrTot;
	}

	public short getStrGiftPymtNbrRem() {
		return StrGiftPymtNbrRem;
	}

	public void setStrGiftPymtNbrRem(short strGiftPymtNbrRem) {
		StrGiftPymtNbrRem = strGiftPymtNbrRem;
	}

	public short getStrFixPymtExpMmyy() {
		return StrFixPymtExpMmyy;
	}

	public void setStrFixPymtExpMmyy(short strFixPymtExpMmyy) {
		StrFixPymtExpMmyy = strFixPymtExpMmyy;
	}

	public Date getStrFixPymt1stPydte() {
		return StrFixPymt1stPydte;
	}

	public void setStrFixPymt1stPydte(Date strFixPymt1stPydte) {
		StrFixPymt1stPydte = strFixPymt1stPydte;
	}

	public String getStrUserText01() {
		return StrUserText01;
	}

	public void setStrUserText01(String strUserText01) {
		StrUserText01 = strUserText01;
	}

	public String getStrUserText02() {
		return StrUserText02;
	}

	public void setStrUserText02(String strUserText02) {
		StrUserText02 = strUserText02;
	}

	public String getStrUserText03() {
		return StrUserText03;
	}

	public void setStrUserText03(String strUserText03) {
		StrUserText03 = strUserText03;
	}

	public String getStrUserText04() {
		return StrUserText04;
	}

	public void setStrUserText04(String strUserText04) {
		StrUserText04 = strUserText04;
	}

	public String getStrUserText05() {
		return StrUserText05;
	}

	public void setStrUserText05(String strUserText05) {
		StrUserText05 = strUserText05;
	}

	@Override
	public String toString() {
		return "AccountsListEntity [StrCardOrg=" + StrCardOrg + ", StrCardLogo=" + StrCardLogo + ", StrCardNmbr="
				+ StrCardNmbr + ", StrMerchOrg=" + StrMerchOrg + ", StrMerchNmbr=" + StrMerchNmbr + ", StrUtilAcctNmbr="
				+ StrUtilAcctNmbr + ", StrStatus=" + StrStatus + ", StrPymtChannel=" + StrPymtChannel
				+ ", StrStatusReason=" + StrStatusReason + ", StrEnrolDate=" + StrEnrolDate + ", StrUtilOwnerName="
				+ StrUtilOwnerName + ", StrProgCode=" + StrProgCode + ", StrUtilAcctNmbr2=" + StrUtilAcctNmbr2
				+ ", StrCreateUser=" + StrCreateUser + ", StrMaintTimeStamp=" + StrMaintTimeStamp + ", StrMaintUser="
				+ StrMaintUser + ", StrReactivatedDate=" + StrReactivatedDate + ", StrReactivatedUser="
				+ StrReactivatedUser + ", StrBillPayCycleDt=" + StrBillPayCycleDt + ", StrBillPayCycleDue="
				+ StrBillPayCycleDue + ", StrAltCardChkFlag=" + StrAltCardChkFlag + ", StrFixPymtStatus="
				+ StrFixPymtStatus + ", StrFixPymtFreq=" + StrFixPymtFreq + ", StrFixPymtCycle=" + StrFixPymtCycle
				+ ", StrFixPymtAmt=" + StrFixPymtAmt + ", StrFixPymtEffDate=" + StrFixPymtEffDate
				+ ", StrFixPymtStatDate=" + StrFixPymtStatDate + ", StrFixPymtNbrTot=" + StrFixPymtNbrTot
				+ ", StrFixPymtNbrRem=" + StrFixPymtNbrRem + ", StrFixPymtFreeNbr=" + StrFixPymtFreeNbr
				+ ", StrFixPymtFreeRem=" + StrFixPymtFreeRem + ", StrGiftPymtNbrTot=" + StrGiftPymtNbrTot
				+ ", StrGiftPymtNbrRem=" + StrGiftPymtNbrRem + ", StrFixPymtExpMmyy=" + StrFixPymtExpMmyy
				+ ", StrFixPymt1stPydte=" + StrFixPymt1stPydte + ", StrUserText01=" + StrUserText01 + ", StrUserText02="
				+ StrUserText02 + ", StrUserText03=" + StrUserText03 + ", StrUserText04=" + StrUserText04
				+ ", StrUserText05=" + StrUserText05 + "]";
	}

	/*
	 * @Column(name="CARD_SEQ_NO") private short StrCardSeqNo;
	 * 
	 * @Column(name="CUST_ORG") private short StrCustOrg;
	 * 
	 * @Column(name="CUST_NMBR") private String StrCustNmbr;
	 * 
	 * @Column(name="UTIL_REF_NMBR") private String StrUtilRefNmbr;
	 * 
	 * @Column(name="STATUS_DATE") private Date StrStatusDate;
	 * 
	 * @Column(name="SOURCE") private String StrSource;
	 * 
	 * @Column(name="LAST_PYMT_DATE") private Date StrLastPymtDate;
	 * 
	 * @Column(name="LAST_PYMT_AMT") private BigDecimal StrLastPymtAmt;
	 * 
	 * @Column(name="LAST_PYMT_CARD") private String StrLastPymtCard;
	 * 
	 * @Column(name="CURR_UTIL_STAT") private String StrCurrUtilStat;
	 * 
	 * @Column(name="CURR_UTIL_STAT_RSN") private String StrCurrUtilStatRsn;
	 * 
	 * @Column(name="CURR_UTIL_STAT_DTE") private Date StrCurrUtilStatDte;
	 * 
	 * @Column(name="CANCELLATION_DATE") private Timestamp StrCancellationDate;
	 * 
	 * @Column(name="CANCELLATION_USER") private String StrCancellationUser;
	 * 
	 * @Column(name="RECUR_PYMT_REJECTS") private short StrRecurPymtRejects;
	 * 
	 * @Column(name="CREATE_TIME_STAMP") private Timestamp StrCreateTimeStamp;
	 * 
	 * @Column(name="VERIFY_TIME_STAMP") private Timestamp StrVerifyTimeStamp;
	 * 
	 * @Column(name="VERIFY_USER") private String StrVerifyUser;
	 * 
	 * @Column(name="PYMT_END_DATE") private Date StrPymtEndDate;
	 * 
	 * @Column(name="RECURR_PYMT_IND") private String StrRecurrPymtInd;
	 * 
	 * @Column(name="UNMH_IND") private String StrUnmhInd;
	 * 
	 * @Column(name="MICROFILM") private String StrMicrofilm;
	 * 
	 * @Column(name="AGENT_CODE ") private String StrAgentCode;
	 * 
	 * @Column(name="CUST_ID") private String StrCustId;
	 * 
	 * @Column(name="UTIL_TYPE") private String StrUtilType;
	 * 
	 * @Column(name="EX_BANK_CODE") private String StrExBankCode;
	 * 
	 * @Column(name="EX_BRANCH_CODE") private String StrExBranchCode;
	 * 
	 * @Column(name="BANK_ABBREV") private String StrBankAbbrev;
	 * 
	 * @Column(name="BANK_PAY_AMNT") private BigDecimal StrBankPayAmnt;
	 * 
	 * @Column(name="HANDPHONE") private String StrHandphone;
	 * 
	 * @Column(name="PYMT_MODE") private String StrPymtMode;
	 * 
	 * @Column(name="REG_EXP_DATE") private Date StrRegExpDate;
	 * 
	 * @Column(name="STAT_MAINT_DTE") private Date StrStatMaintDte;
	 * 
	 * @Column(name="XFER_IND") private String StrXferInd;
	 * 
	 * @Column(name="ENRL_ACDTE") private Date StrEnrlAcdte;
	 * 
	 * @Column(name="ENRL_USRID") private String StrEnrlUsrid;
	 * 
	 * @Column(name="ACCT_ORG") private short StrAcctOrg;
	 * 
	 * @Column(name="ECSCUS_UNIQUE_NO") private String StrEcscusUniqueNo;
	 * 
	 * @Column(name="RESERVE_DATA") private String StrReserveData;
	 */

}

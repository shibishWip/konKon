package com.citi.cards.abps.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface MasterBasicService<T1, T2> {// T1 list entity, T2 details
												// Entity

	public List<T1> find(Map conditions) throws Exception;

	/**
	 * 
	 * find one entity by condition
	 * 
	 * @param query
	 * @return
	 */
	public T2 enquiry(BigDecimal merchantNmbr) throws Exception;

	/**
	 * 
	 * update
	 * 
	 * @param query
	 * @param update
	 * @return
	 */
	public void update(T2 bean) throws Exception;

	/**
	 * 
	 * @param bean
	 */
	public void save(T2 bean) throws Exception;

	/**
	 * 
	 * 
	 */
	public void delete(T2 bean) throws Exception;

	/**
	 * 
	 * @param bean
	 * @return
	 * @throws Exception
	 */
	public boolean exist(T2 bean) throws Exception;

	/**
	 * 
	 * @param bean
	 * @param status
	 */
	public void updateStatus(T2 bean, String status) throws Exception;

}

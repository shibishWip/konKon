package com.citi.cards.abps.controller;

import java.util.Map;

import com.citi.cards.abps.entity.ExceptionEntity;
import com.citi.cards.abps.entity.SuccessEntity;

public class BaseController {

	/**
	 * 
	 * @param keyField
	 * @param action
	 * @return successEntity
	 */
	public SuccessEntity genSuccessEntity(SuccessEntity se, String action, String entity) {

		se.setAction(action);
		se.setEntity(entity);

		return se;
	}

	/**
	 * 
	 * @param keyField
	 * @param keyValue
	 * @return
	 */
	public SuccessEntity genSuccessEntity(String keyField, String keyValue) {
		SuccessEntity se = new SuccessEntity();
		se.setKeyField(keyField);
		se.setKeyValue(keyValue);
		return se;
	}

	public Map<String, Object> genRetMap(Map<String, Object> map, Object obj) {
		map.put("responseBody", obj);
		return map;
	}

	/**
	 * 
	 * @param keyField
	 * @param action
	 * @return successEntity
	 */
	protected ExceptionEntity genExceptionEntity(String errCode, String errType, String message) {
		ExceptionEntity ee = new ExceptionEntity();
		ee.setErrCode(errCode);
		ee.setErrType(errType);
		ee.setMessage(message);

		return ee;
	}

	/**
	 * 
	 * @param keyField
	 * @param action
	 * @return successEntity
	 */
	protected ExceptionEntity genExceptionEntity(String errCode, String errType, Exception error) {
		ExceptionEntity ee = new ExceptionEntity();
		ee.setErrCode(errCode);
		ee.setErrType(errType);
		ee.setMessage(error.getMessage());

		return ee;
	}
}

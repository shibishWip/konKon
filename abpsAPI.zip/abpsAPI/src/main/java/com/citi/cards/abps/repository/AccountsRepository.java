package com.citi.cards.abps.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citi.cards.abps.entity.pojo.AccountsEntity;
import com.citi.cards.abps.entity.pojo.AccountsListEntity;
import com.citi.cards.abps.entity.pojo.AccountsPKClass;
import com.citi.cards.abps.entity.pojo.MerchantsListEntity;
import com.citi.cards.abps.util.UtilityBean;

@Repository

public class AccountsRepository {

	@PersistenceContext
	private EntityManager em;

	public List findByConditions(Map conditions) throws Exception {
		List AccountsList = new ArrayList();
		try {

			CriteriaBuilder cbJoin = em.getCriteriaBuilder();
			CriteriaQuery<?> queryJoin = cbJoin.createQuery();
			Root<AccountsListEntity> AccountsRoot = queryJoin.from(AccountsListEntity.class);
			Root<MerchantsListEntity> MerchantsRoot = queryJoin.from(MerchantsListEntity.class);
			Expression<Boolean> expression1 = cbJoin.and(
					UtilityBean.getPredicate(AccountsRoot, queryJoin, cbJoin, conditions),
					cbJoin.equal(AccountsRoot.get("StrMerchNmbr"), MerchantsRoot.get("StrMerchNmbr")),
					cbJoin.equal(AccountsRoot.get("StrMerchOrg"), MerchantsRoot.get("StrMerchOrg")));
			Query testQuery = em.createQuery(queryJoin.multiselect(MerchantsRoot, AccountsRoot).where(expression1));
			AccountsList = testQuery.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return AccountsList;
	}

	public AccountsEntity enquiry(AccountsEntity primarkKey) throws Exception {
		AccountsEntity accountsEntity = null;
		try {
			accountsEntity = em.find(AccountsEntity.class, primarkKey);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return accountsEntity;
	}

	public boolean exist(AccountsEntity primarkKey) throws Exception {
		AccountsEntity accountsEntity = enquiry(primarkKey);

		if (accountsEntity != null) {
			return true;
		} else {
			return false;
		}
	}

	public AccountsPKClass enquiry(AccountsPKClass primarkKey) throws Exception {
		AccountsPKClass accountsPKClass = null;
		try {
			accountsPKClass = em.find(AccountsPKClass.class, primarkKey);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return accountsPKClass;
	}

	public boolean exist(AccountsPKClass primarkKey) throws Exception {
		AccountsPKClass accountsEntity = enquiry(primarkKey);

		if (accountsEntity != null) {
			return true;
		} else {
			return false;
		}
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public void save(AccountsEntity obj) throws Exception {
		try {
			em.persist(obj);
			em.flush();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public void update(AccountsEntity obj) throws Exception {
		try {
			em.merge(obj);
			em.flush();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public void delete(AccountsEntity obj) throws Exception {
		try {
			em.remove(em.merge(obj));
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

	}
}

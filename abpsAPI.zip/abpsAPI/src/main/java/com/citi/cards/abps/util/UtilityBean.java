package com.citi.cards.abps.util;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UtilityBean {

	private static final ObjectMapper JSON_MAPPER = new ObjectMapper();

	public static Object convert2ObjectFromStr(String str, Class klass)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objM = new ObjectMapper();
		Object obj = objM.readValue(str, klass);
		return obj;
	}

	public static String convertObjectToJson(Object obj) throws JsonProcessingException {
		String jsonObj = JSON_MAPPER.writeValueAsString(obj);
		return jsonObj;
	}

	public static Predicate getPredicate(Root<?> root, CriteriaQuery<?> query, CriteriaBuilder cb, Map conditions) {

		List<Predicate> list = new ArrayList<Predicate>();
		Set set = conditions.keySet();

		if (set != null && set.size() > 0) {
			for (Object obj : set) {
				String key = (String) obj;
				String value = String.valueOf(conditions.get(key));
				if (value != null && !("".equalsIgnoreCase(value) || "null".equalsIgnoreCase(value)))
					list.add(cb.equal(root.get(key).as(String.class), value));

			}
		}

		Predicate[] p = new Predicate[list.size()];
		return cb.and(list.toArray(p));
	}

	public static String getDateStr() {
		java.util.Date date = new java.util.Date();
		SimpleDateFormat df = new SimpleDateFormat("ddMMMyyyy");
		return df.format(date);
	}

	public static java.sql.Date getDate() {
		java.sql.Date dt = new java.sql.Date(new java.util.Date().getTime());
		return dt;
	}

	/**
	 * 
	 * @return timestamps
	 */
	public static String timestamp2string() {
		Timestamp t = new Timestamp(new java.util.Date().getTime());
		String s = String.valueOf(t);
		return s;
	}

	public static Timestamp getTimestamp() {
		return new Timestamp(new java.util.Date().getTime());
	}

	public static void setAccessControll(HttpServletResponse response) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
	}

	public static boolean isEmpty(String value) {
		if (value != null && value.trim().length() > 0) {
			return false;
		} else {
			return true;
		}
	}

	public static boolean isNotEmpty(String value) {
		return (!(isEmpty(value)));
	}

}

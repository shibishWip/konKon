package com.citi.cards.abps.jsoncore;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.citi.cards.abps.entity.ExceptionEntity;
import com.citi.cards.abps.entity.pojo.MerchantsEntity;
import com.citi.cards.abps.json.response.AbpsCardsInqRes;
import com.citi.cards.abps.json.response.EUACA024OperationResponse;
import com.citi.cards.abps.json.response.Euica80OutArea;
import com.citi.cards.abps.json.response.Ica80OutAreaAct;
import com.citi.cards.abps.json.response.Ica80OutAreaCrd;
import com.citi.cards.abps.json.response.Mca80HeaderOutData;
import com.citi.cards.abps.json.response.Mca80OutData;
import com.citi.cards.abps.json.response.UtlCwsMessageInterface802;

@Component
public class JsonCardResponse {

	private ExceptionEntity exceptionEntity = null;
	// For numeric \d
	// For String A-Za-z
	// For Space \dA-Za-z (alphaNumeric)
	private String UTILACCTFORMAT = "[\\d][\\d][\\d][-][A-Za-z][\\dA-Za-z]";

	public ExceptionEntity otherValidations(MerchantsEntity merchantsEntity, AbpsCardsInqRes respentity)
			throws ParseException, FileNotFoundException {

		EUACA024OperationResponse euaca024OperationResponse = respentity.getEUACA024OperationResponse();
		UtlCwsMessageInterface802 utlCwsMessageInterface802 = euaca024OperationResponse
				.getUtl_cws_message_interface802();
		Euica80OutArea euica80OutArea = utlCwsMessageInterface802.getEuica80_out_area();
		Mca80HeaderOutData mca80HeaderOutData = utlCwsMessageInterface802.getMca80_header_out_data();
		Mca80OutData mca80OutData = mca80HeaderOutData.getMca80_out_data();
		Ica80OutAreaAct ica80OutAreaAct = euica80OutArea.getIca80_out_area_act();
		Ica80OutAreaCrd ica80OutAreaCrd = euica80OutArea.getIca80_out_area_crd();

		int response_code = mca80OutData.getMca80_out_resp_code();

		if (response_code == 0) {

			SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD");
			java.util.Date date_exp = (java.util.Date) sdf.parse(ica80OutAreaCrd.getIca80_do_crd_date_expire());
			Date date_expire = new Date(date_exp.getTime());

			String crd_block_code = ica80OutAreaCrd.getIca80_do_crd_block_code();
			String crd_status = ica80OutAreaCrd.getIca80_do_crd_status();
			String act_block_code_1 = ica80OutAreaAct.getIca80_do_act_block_code_1();
			String act_block_code_2 = ica80OutAreaAct.getIca80_do_act_block_code_2();
			String act_status = ica80OutAreaAct.getIca80_do_act_status();

			boolean flag = false;
			if (merchantsEntity.getStrStatus().equals("A")) {
				if (crd_status != merchantsEntity.getStrEnrolCardStatus()
						&& act_status != merchantsEntity.getStrEnrolCardStatus()) {
					if (merchantsEntity.getStrEnrolBlk().contains(crd_block_code)
							|| merchantsEntity.getStrEnrolBlk().contains(act_block_code_1)
							|| merchantsEntity.getStrEnrolBlk().contains(act_block_code_2)) {
						flag = true;
						exceptionEntity = new ExceptionEntity("0000", "JsonValidation", "JSONVALIDATION is success");
					} else {
						exceptionEntity = new ExceptionEntity("9999", "BlockCode", "6026 - Block Code Invalid");
					}
				} else {
					exceptionEntity = new ExceptionEntity("9999", "Card Status", "6027 - Card Status & Act Status invalid");
				}
			} else {
				exceptionEntity = new ExceptionEntity("9999", "MerchStatus", "6028 - Merchant is not active");
			}

			if (flag) {
				if (merchantsEntity.getStrEnrolExpChk().equals('Y'))
					if (!((date_expire.compareTo(new java.sql.Date(new java.util.Date().getTime()))) > 0))
						exceptionEntity = new ExceptionEntity("9999", "ExpiryDate", "6029 - Card Expired");

				if (merchantsEntity.getStrUtilFmtCheck().equals("Y"))
					if (!isUtilAcctFmtValid(merchantsEntity))
						exceptionEntity = new ExceptionEntity("9999", "UtilAcctFmtValid", "6030 - Utility Account format Invalid");

			}

		} else {
			exceptionEntity = new ExceptionEntity("9999", "JSON Error", " " + getErrorDetail(response_code));
		}

		return exceptionEntity;
	}

	private boolean isUtilAcctFmtValid(MerchantsEntity merchantsEntity) {
		boolean flag = false;
		Pattern p = Pattern.compile(UTILACCTFORMAT);
		Matcher matcher = p.matcher(merchantsEntity.getStrUtilAcctFmt());// 999-ab
		if (matcher.find())
			if (matcher.group(0).length() == merchantsEntity.getStrUtilAcctFmt().length())
				flag = true;
		return flag;
	}

	public String getErrorDetail(int scStr) throws FileNotFoundException {

		String localStr = null;
		// ClassLoader loader = Thread.currentThread().getContextClassLoader();
		String errFile = ConnectItJson.class.getClassLoader().getResource("errorcode.txt").getFile();

		try (BufferedReader br = new BufferedReader(new FileReader(errFile))) {

			String sCurrentLine;
			while ((sCurrentLine = br.readLine()) != null) {
				// System.out.println(sCurrentLine);
				if (sCurrentLine.contains(scStr + "")) {
					// System.out.println("sCurrentLine " + sCurrentLine);
					localStr = sCurrentLine.toUpperCase();
					break;
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		if (localStr == null) {
			localStr = scStr + "";
		}
		return localStr;

	}

}

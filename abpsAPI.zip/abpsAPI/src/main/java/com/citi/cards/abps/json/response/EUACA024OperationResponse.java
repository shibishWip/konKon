
package com.citi.cards.abps.json.response;

import org.springframework.stereotype.Component;

@Component
public class EUACA024OperationResponse {

	private UtlCwsMessageInterface802 utl_cws_message_interface802;

	public UtlCwsMessageInterface802 getUtl_cws_message_interface802() {
		return utl_cws_message_interface802;
	}

	public void setUtl_cws_message_interface802(UtlCwsMessageInterface802 utl_cws_message_interface802) {
		this.utl_cws_message_interface802 = utl_cws_message_interface802;
	}

	@Override
	public String toString() {
		return "ClassPojo [utl_cws_message_interface802 = " + utl_cws_message_interface802 + "]";
	}
}


package com.citi.cards.abps.json.response;

import org.springframework.stereotype.Component;

@Component

public class Ica80OutAreaSys {

	private String ica80_do_sys_todays_julian;

	private String ica80_do_sys_dte_nxt_proc;

	private String ica80_do_org_base_curr_ind;

	private int ica80_do_sys_date_format;

	private int ica80_do_sys_todays_calendar;

	private String ica80_do_org_c_processing;

	private String ica80_do_org_country;

	private String ica80_do_sys_mbs_intfa_flag;

	public String getIca80_do_sys_todays_julian() {
		return ica80_do_sys_todays_julian;
	}

	public void setIca80_do_sys_todays_julian(String ica80_do_sys_todays_julian) {
		this.ica80_do_sys_todays_julian = ica80_do_sys_todays_julian;
	}

	public String getIca80_do_sys_dte_nxt_proc() {
		return ica80_do_sys_dte_nxt_proc;
	}

	public void setIca80_do_sys_dte_nxt_proc(String ica80_do_sys_dte_nxt_proc) {
		this.ica80_do_sys_dte_nxt_proc = ica80_do_sys_dte_nxt_proc;
	}

	public String getIca80_do_org_base_curr_ind() {
		return ica80_do_org_base_curr_ind;
	}

	public void setIca80_do_org_base_curr_ind(String ica80_do_org_base_curr_ind) {
		this.ica80_do_org_base_curr_ind = ica80_do_org_base_curr_ind;
	}

	public int getIca80_do_sys_date_format() {
		return ica80_do_sys_date_format;
	}

	public void setIca80_do_sys_date_format(int ica80_do_sys_date_format) {
		this.ica80_do_sys_date_format = ica80_do_sys_date_format;
	}

	public int getIca80_do_sys_todays_calendar() {
		return ica80_do_sys_todays_calendar;
	}

	public void setIca80_do_sys_todays_calendar(int ica80_do_sys_todays_calendar) {
		this.ica80_do_sys_todays_calendar = ica80_do_sys_todays_calendar;
	}

	public String getIca80_do_org_c_processing() {
		return ica80_do_org_c_processing;
	}

	public void setIca80_do_org_c_processing(String ica80_do_org_c_processing) {
		this.ica80_do_org_c_processing = ica80_do_org_c_processing;
	}

	public String getIca80_do_org_country() {
		return ica80_do_org_country;
	}

	public void setIca80_do_org_country(String ica80_do_org_country) {
		this.ica80_do_org_country = ica80_do_org_country;
	}

	public String getIca80_do_sys_mbs_intfa_flag() {
		return ica80_do_sys_mbs_intfa_flag;
	}

	public void setIca80_do_sys_mbs_intfa_flag(String ica80_do_sys_mbs_intfa_flag) {
		this.ica80_do_sys_mbs_intfa_flag = ica80_do_sys_mbs_intfa_flag;
	}

	@Override
	public String toString() {
		return "ClassPojo [ica80_do_sys_todays_julian = " + ica80_do_sys_todays_julian
				+ ", ica80_do_sys_dte_nxt_proc = " + ica80_do_sys_dte_nxt_proc + ", ica80_do_org_base_curr_ind = "
				+ ica80_do_org_base_curr_ind + ", ica80_do_sys_date_format = " + ica80_do_sys_date_format
				+ ", ica80_do_sys_todays_calendar = " + ica80_do_sys_todays_calendar + ", ica80_do_org_c_processing = "
				+ ica80_do_org_c_processing + ", ica80_do_org_country = " + ica80_do_org_country
				+ ", ica80_do_sys_mbs_intfa_flag = " + ica80_do_sys_mbs_intfa_flag + "]";
	}
}

package com.citi.cards.abps.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.citi.cards.abps.entity.LoginBean;

@Controller
@SpringBootApplication
@SessionAttributes("login")
@RequestMapping({ "/ABPSLogin" })
public class LoginController extends BaseController {

	@Autowired
	HttpSession session;
	String strUserName = "AG07254-pp51274-jv40005-cs01391-gm80086";
	String strPassword = "ag07254-pp51274-jv40005-cs01391-gm80086";
	String strSessionID = "";

	@RequestMapping("/login")
	public ModelAndView login() {
		ModelAndView model = new ModelAndView("login");
		return model;
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ModelAndView LoginAuthorization(@ModelAttribute("loginBean") LoginBean logiBean,
			@RequestParam(value = "error", required = false) String error, HttpServletRequest request) {

		// ModelAndView model = new ModelAndView("content");
		ModelAndView model = new ModelAndView();
		model.addObject("logiBean", logiBean);

		session.setAttribute("USER_NAME", logiBean.getStrCreateUser());
		session.setAttribute("CARD_NUMBER", logiBean.getStrCardNmbr());
		session.setAttribute("ORG", logiBean.getStrCardOrg());
		session.setAttribute("LOGO", logiBean.getStrCardLogo());

		String[] strUserValue = strUserName.split("-");
		String[] strPassValue = strPassword.split("-");

		if (logiBean.getStrCreateUser().equals("") || logiBean.getStrPassword().equals("")
				|| (logiBean.getStrCardLogo() == ' ') || (logiBean.getStrCardOrg() == ' ')) {
			model.addObject("error", "Manadatory Fields should not be blank!");
			model.setViewName("login");
			return model;
		} else if ((logiBean.getStrCreateUser().equals(strUserValue[0])
				|| logiBean.getStrCreateUser().equals(strUserValue[1])
				|| logiBean.getStrCreateUser().equals(strUserValue[2])
				|| logiBean.getStrCreateUser().equals(strUserValue[3])
				|| logiBean.getStrCreateUser().equals(strUserValue[4]))
				&& (logiBean.getStrPassword().equals(strPassValue[0])
						|| logiBean.getStrPassword().equals(strPassValue[1])
						|| logiBean.getStrPassword().equals(strPassValue[2])
						|| logiBean.getStrPassword().equals(strPassValue[3])
						|| logiBean.getStrPassword().equals(strPassValue[4]))) {
			model.setViewName("registration");
			return model;
		} else if (logiBean.getStrCreateUser().equals("")) {
			model.addObject("error", "Invalid Username!");
			model.setViewName("login");
			return model;
		} else if (logiBean.getStrPassword().equals("")) {
			model.addObject("error", "Invalid Password!");
			model.setViewName("login");
			return model;
		} else if (logiBean.getStrCardNmbr().equals("")) {
			model.addObject("error", "Card Number should not be blank!");
			model.setViewName("login");
			return model;
		} else {
			model.addObject("error", "Invalid Username and Password!");
			model.setViewName("login");
			return model;
		}

	}

	@RequestMapping("/registration")
	public ModelAndView Registration(@ModelAttribute("loginBean") LoginBean logiBean) {

		ModelAndView model = new ModelAndView();
		strSessionID = session.getId();
		boolean strSessionIDNew = session.isNew();

		model.setViewName("login");
		return model;
	}
}

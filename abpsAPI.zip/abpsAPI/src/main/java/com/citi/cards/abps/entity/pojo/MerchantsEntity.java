package com.citi.cards.abps.entity.pojo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EUUM_UTIL_MERCH")

public class MerchantsEntity implements Serializable {

	@Id
	@Column(name = "MERCH_ORG")
	private short StrMerchOrg;
	@Id
	@Column(name = "MERCH_NMBR")
	private BigDecimal StrMerchNmbr;

	@Column(name = "DESCRIPTION")
	private String StrDescription;
	@Column(name = "STATUS")
	private String StrStatus;
	@Column(name = "UTIL_AC_TITLE")
	private String StrUtilAcTitle;
	@Column(name = "ENROL_OPTION")
	private String StrEnrolOption;
	@Column(name = "REJ_TXN_ENROL")
	private String StrRejTxnEnrol;
	@Column(name = "BANK_NAME")
	private String StrBankName;
	@Column(name = "BANK_ACCT_NMBR")
	private String StrBankAcctNmbr;
	@Column(name = "UTIL_FMT_CHECK")
	private String StrUtilFmtCheck;
	@Column(name = "UTIL_ACCT_FMT")
	private String StrUtilAcctFmt;
	@Column(name = "ENROL_CYCLE_DUE")
	private String StrEnrolCycleDue;
	@Column(name = "ENROL_CARD_STATUS")
	private String StrEnrolCardStatus;
	@Column(name = "ENROL_BLK")
	private String StrEnrolBlk;
	@Column(name = "ENROL_EXP_CHK")
	private String StrEnrolExpChk;
	@Column(name = "PMT_TXN_CODE")
	private short StrPmtTxnCode;
	@Column(name = "FEE_TXN_CODE")
	private short StrFeeTxnCode;
	@Column(name = "AC_DESC_REQD")
	private String StrAcDescReqd;
	@Column(name = "PYMT_CHANNEL")
	private String StrPymtChannel;
	@Column(name = "CH_FEE_RATE_IND")
	private String StrChFeeRateInd;
	@Column(name = "CH_FEE_RATE")
	private BigDecimal StrChFeeRate;
	@Column(name = "BTH_BTH_BLK_CODE")
	private String StrBthBthBlkCode;
	@Column(name = "BTH_BTH_STATUS")
	private String StrBthBthStatus;
	@Column(name = "BTH_BTH_CYCLE_DUE")
	private String StrBthBthCycleDue;
	@Column(name = "BTH_BTH_EXP_CHK")
	private String StrBthBthExpChk;
	@Column(name = "FORCE_PT_BLK_CODE")
	private String StrForcePtBlkCode;
	@Column(name = "FORCE_PT_STATUS")
	private String StrForcePtStatus;
	@Column(name = "FORCE_PT_CYCLE_DUE")
	private String StrForcePtCycleDue;
	@Column(name = "FORCE_PT_EXP_CHK")
	private String StrForcePtExpChk;
	@Column(name = "AUTO_XFR")
	private String StrAutoXfr;
	@Column(name = "MIN_TRANS_AMT")
	private BigDecimal StrMransAmt;
	@Column(name = "MAX_TRANS_AMT")
	private BigDecimal StrMaxTransAmt;
	@Column(name = "OTB_CHK_REQD")
	private String StrOtbChkReqd;
	@Column(name = "OTB_PERCENT")
	private BigDecimal StrOtbPercent;
	@Column(name = "ENROL_CYCLE_NO")
	private String StrEnrolCycleNo;
	@Column(name = "PYMT_CYCLE_NO")
	private String StrPymtCycleNo;
	@Column(name = "UTIL_ACCT_TYP_IND")
	private String StrUtilAcctTypInd;
	@Column(name = "MULTIPLE_BILL_IND")
	private String StrMultipleBillInd;
	@Column(name = "FORCE_POST_LIMIT")
	private BigDecimal StrForcePostLimit;
	@Column(name = "OLA_AUTH_AMT_LIMIT")
	private BigDecimal StrOlaAuthAmtLimit;
	@Column(name = "ENROL_AUTH_REQD")
	private String StrEnrolAuthReqd;
	@Column(name = "PYMT_AUTH_REQD")
	private String StrPymtAuthReqd;
	@Column(name = "USER_TEXT_01")
	private String StrUserText01;
	@Column(name = "USER_TEXT_02")
	private String StrUserText02;
	@Column(name = "MAIN_MERCH")
	private String StrMainMerch;
	@Column(name = "MIN_AGE")
	private short StrMinAge;
	@Column(name = "MAX_AGE")
	private short StrMaxAge;
	@Column(name = "FIX_PYMT_CYCLE")
	private short StrFixPymtCycle;
	@Column(name = "FIX_PYMT_FREQ")
	private String StrFixPymtFreq;
	@Column(name = "FIX_PYMT_AMT")
	private BigDecimal StrFixPymtAmt;
	@Column(name = "FREE_MONTHS")
	private short StrFreeMonths;
	@Column(name = "TOTAL_FIX_PYMTS")
	private short StrTotalFixPymts;
	@Column(name = "MERCH_TYPE")
	private String StrMerchType;
	@Column(name = "MERCH_FEE_TXN_CODE")
	private short StrMerchFeeTxnCode;
	@Column(name = "MERCH_FEE_RATE_IND")
	private String StrMerchFeeRateInd;
	@Column(name = "MERCH_FEE_RATE")
	private BigDecimal StrMerchFeeRate;
	@Column(name = "CH_FEE_TXN_CODE")
	private short StrChFeeTxnCode;
	@Column(name = "DEBIT_TXN_CODE")
	private short StrDebitTxnCode;
	@Column(name = "CREDIT_TXN_CODE")
	private short StrCreditTxnCode;
	@Column(name = "VAT_TXN_CODE")
	private short StrVatTxnCode;
	@Column(name = "VAT_RATE_IND")
	private String StrVatRateInd;
	@Column(name = "VAT_RATE")
	private BigDecimal StrVatRate;
	@Column(name = "LTRCD_EN_APP")
	private String StrLtrcdEnApp;
	@Column(name = "LTRCD_EN_REJ")
	private String StrLtrcdEnRej;
	@Column(name = "LTRCD_EN_REINS")
	private String StrLtrcdEnReins;
	@Column(name = "LTRCD_EN_CANC")
	private String StrLtrcdEnCanc;
	@Column(name = "LTRCD_PY_APP")
	private String StrLtrcdPyApp;
	@Column(name = "LTRCD_PY_REJ")
	private String StrLtrcdPyRej;
	@Column(name = "NO_OF_GIFTS")
	private short StrNoOfGifts;
	@Column(name = "GIFT_TXN_CODE")
	private short StrGiftTxnCode;
	@Column(name = "MCC_VISA")
	private String StrMccVisa;
	@Column(name = "MCC_MC")
	private String StrMccMc;
	@Column(name = "MCC_OTHER")
	private String StrMccOther;
	@Column(name = "CONTACT_PERSON")
	private String StrContactPerson;
	@Column(name = "BIZ_PHONE")
	private String StrBizPhone;
	@Column(name = "BIZ_EMAIL")
	private String StrBizEmail;
	@Column(name = "MAX_PYMT_REJECTS")
	private short StrMaxPymtRejects;
	@Column(name = "CANCEL_CYCLE_DUE")
	private String StrCancelCycleDue;
	@Column(name = "CANCEL_CARD_STATUS")
	private String StrCancelCardStatus;
	@Column(name = "CANCEL_BLK")
	private String StrCancelBlk;
	@Column(name = "STMT_DESC")
	private String StrStmtDesc;
	@Column(name = "FORCE_ACTIVE")
	private String StrForceActive;
	@Column(name = "CREATE_TIME_STAMP")
	private Timestamp StrCreateTimeStamp;
	@Column(name = "CREATE_USER")
	private String StrCreateUser;
	@Column(name = "MAINT_TIME_STAMP")
	private Timestamp StrMaTimeStamp;
	@Column(name = "MAINT_USER")
	private String StrMaUser;
	@Column(name = "VERIFY_TIME_STAMP")
	private Timestamp StrVerifyTimeStamp;
	@Column(name = "VERIFY_USER")
	private String StrVerifyUser;
	@Column(name = "PRE_AUTH_REQ")
	private String StrPreAuthReq;
	@Column(name = "REQ_4_ICARD")
	private String StrReq4Icard;
	@Column(name = "SETUP_DATE")
	private Date StrSetupStr;
	@Column(name = "TXN_TYP_ALLOW")
	private String StrTxnTypAllow;
	@Column(name = "RESERVE_DATA")
	private String StrReserveData;

	public short getStrMerchOrg() {
		return StrMerchOrg;
	}

	public void setStrMerchOrg(short strMerchOrg) {
		StrMerchOrg = strMerchOrg;
	}

	public BigDecimal getStrMerchNmbr() {
		return StrMerchNmbr;
	}

	public void setStrMerchNmbr(BigDecimal strMerchNmbr) {
		StrMerchNmbr = strMerchNmbr;
	}

	public String getStrDescription() {
		return StrDescription;
	}

	public void setStrDescription(String strDescription) {
		StrDescription = strDescription;
	}

	public String getStrStatus() {
		return StrStatus;
	}

	public void setStrStatus(String strStatus) {
		StrStatus = strStatus;
	}

	public String getStrUtilAcTitle() {
		return StrUtilAcTitle;
	}

	public void setStrUtilAcTitle(String strUtilAcTitle) {
		StrUtilAcTitle = strUtilAcTitle;
	}

	public String getStrEnrolOption() {
		return StrEnrolOption;
	}

	public void setStrEnrolOption(String strEnrolOption) {
		StrEnrolOption = strEnrolOption;
	}

	public String getStrRejTxnEnrol() {
		return StrRejTxnEnrol;
	}

	public void setStrRejTxnEnrol(String strRejTxnEnrol) {
		StrRejTxnEnrol = strRejTxnEnrol;
	}

	public String getStrBankName() {
		return StrBankName;
	}

	public void setStrBankName(String strBankName) {
		StrBankName = strBankName;
	}

	public String getStrBankAcctNmbr() {
		return StrBankAcctNmbr;
	}

	public void setStrBankAcctNmbr(String strBankAcctNmbr) {
		StrBankAcctNmbr = strBankAcctNmbr;
	}

	public String getStrUtilFmtCheck() {
		return StrUtilFmtCheck;
	}

	public void setStrUtilFmtCheck(String strUtilFmtCheck) {
		StrUtilFmtCheck = strUtilFmtCheck;
	}

	public String getStrUtilAcctFmt() {
		return StrUtilAcctFmt;
	}

	public void setStrUtilAcctFmt(String strUtilAcctFmt) {
		StrUtilAcctFmt = strUtilAcctFmt;
	}

	public String getStrEnrolCycleDue() {
		return StrEnrolCycleDue;
	}

	public void setStrEnrolCycleDue(String strEnrolCycleDue) {
		StrEnrolCycleDue = strEnrolCycleDue;
	}

	public String getStrEnrolCardStatus() {
		return StrEnrolCardStatus;
	}

	public void setStrEnrolCardStatus(String strEnrolCardStatus) {
		StrEnrolCardStatus = strEnrolCardStatus;
	}

	public String getStrEnrolBlk() {
		return StrEnrolBlk;
	}

	public void setStrEnrolBlk(String strEnrolBlk) {
		StrEnrolBlk = strEnrolBlk;
	}

	public String getStrEnrolExpChk() {
		return StrEnrolExpChk;
	}

	public void setStrEnrolExpChk(String strEnrolExpChk) {
		StrEnrolExpChk = strEnrolExpChk;
	}

	public short getStrPmtTxnCode() {
		return StrPmtTxnCode;
	}

	public void setStrPmtTxnCode(short strPmtTxnCode) {
		StrPmtTxnCode = strPmtTxnCode;
	}

	public short getStrFeeTxnCode() {
		return StrFeeTxnCode;
	}

	public void setStrFeeTxnCode(short strFeeTxnCode) {
		StrFeeTxnCode = strFeeTxnCode;
	}

	public String getStrAcDescReqd() {
		return StrAcDescReqd;
	}

	public void setStrAcDescReqd(String strAcDescReqd) {
		StrAcDescReqd = strAcDescReqd;
	}

	public String getStrPymtChannel() {
		return StrPymtChannel;
	}

	public void setStrPymtChannel(String strPymtChannel) {
		StrPymtChannel = strPymtChannel;
	}

	public String getStrChFeeRateInd() {
		return StrChFeeRateInd;
	}

	public void setStrChFeeRateInd(String strChFeeRateInd) {
		StrChFeeRateInd = strChFeeRateInd;
	}

	public BigDecimal getStrChFeeRate() {
		return StrChFeeRate;
	}

	public void setStrChFeeRate(BigDecimal strChFeeRate) {
		StrChFeeRate = strChFeeRate;
	}

	public String getStrBthBthBlkCode() {
		return StrBthBthBlkCode;
	}

	public void setStrBthBthBlkCode(String strBthBthBlkCode) {
		StrBthBthBlkCode = strBthBthBlkCode;
	}

	public String getStrBthBthStatus() {
		return StrBthBthStatus;
	}

	public void setStrBthBthStatus(String strBthBthStatus) {
		StrBthBthStatus = strBthBthStatus;
	}

	public String getStrBthBthCycleDue() {
		return StrBthBthCycleDue;
	}

	public void setStrBthBthCycleDue(String strBthBthCycleDue) {
		StrBthBthCycleDue = strBthBthCycleDue;
	}

	public String getStrBthBthExpChk() {
		return StrBthBthExpChk;
	}

	public void setStrBthBthExpChk(String strBthBthExpChk) {
		StrBthBthExpChk = strBthBthExpChk;
	}

	public String getStrForcePtBlkCode() {
		return StrForcePtBlkCode;
	}

	public void setStrForcePtBlkCode(String strForcePtBlkCode) {
		StrForcePtBlkCode = strForcePtBlkCode;
	}

	public String getStrForcePtStatus() {
		return StrForcePtStatus;
	}

	public void setStrForcePtStatus(String strForcePtStatus) {
		StrForcePtStatus = strForcePtStatus;
	}

	public String getStrForcePtCycleDue() {
		return StrForcePtCycleDue;
	}

	public void setStrForcePtCycleDue(String strForcePtCycleDue) {
		StrForcePtCycleDue = strForcePtCycleDue;
	}

	public String getStrForcePtExpChk() {
		return StrForcePtExpChk;
	}

	public void setStrForcePtExpChk(String strForcePtExpChk) {
		StrForcePtExpChk = strForcePtExpChk;
	}

	public String getStrAutoXfr() {
		return StrAutoXfr;
	}

	public void setStrAutoXfr(String strAutoXfr) {
		StrAutoXfr = strAutoXfr;
	}

	public BigDecimal getStrMransAmt() {
		return StrMransAmt;
	}

	public void setStrMransAmt(BigDecimal strMransAmt) {
		StrMransAmt = strMransAmt;
	}

	public BigDecimal getStrMaxTransAmt() {
		return StrMaxTransAmt;
	}

	public void setStrMaxTransAmt(BigDecimal strMaxTransAmt) {
		StrMaxTransAmt = strMaxTransAmt;
	}

	public String getStrOtbChkReqd() {
		return StrOtbChkReqd;
	}

	public void setStrOtbChkReqd(String strOtbChkReqd) {
		StrOtbChkReqd = strOtbChkReqd;
	}

	public BigDecimal getStrOtbPercent() {
		return StrOtbPercent;
	}

	public void setStrOtbPercent(BigDecimal strOtbPercent) {
		StrOtbPercent = strOtbPercent;
	}

	public String getStrEnrolCycleNo() {
		return StrEnrolCycleNo;
	}

	public void setStrEnrolCycleNo(String strEnrolCycleNo) {
		StrEnrolCycleNo = strEnrolCycleNo;
	}

	public String getStrPymtCycleNo() {
		return StrPymtCycleNo;
	}

	public void setStrPymtCycleNo(String strPymtCycleNo) {
		StrPymtCycleNo = strPymtCycleNo;
	}

	public String getStrUtilAcctTypInd() {
		return StrUtilAcctTypInd;
	}

	public void setStrUtilAcctTypInd(String strUtilAcctTypInd) {
		StrUtilAcctTypInd = strUtilAcctTypInd;
	}

	public String getStrMultipleBillInd() {
		return StrMultipleBillInd;
	}

	public void setStrMultipleBillInd(String strMultipleBillInd) {
		StrMultipleBillInd = strMultipleBillInd;
	}

	public BigDecimal getStrForcePostLimit() {
		return StrForcePostLimit;
	}

	public void setStrForcePostLimit(BigDecimal strForcePostLimit) {
		StrForcePostLimit = strForcePostLimit;
	}

	public BigDecimal getStrOlaAuthAmtLimit() {
		return StrOlaAuthAmtLimit;
	}

	public void setStrOlaAuthAmtLimit(BigDecimal strOlaAuthAmtLimit) {
		StrOlaAuthAmtLimit = strOlaAuthAmtLimit;
	}

	public String getStrEnrolAuthReqd() {
		return StrEnrolAuthReqd;
	}

	public void setStrEnrolAuthReqd(String strEnrolAuthReqd) {
		StrEnrolAuthReqd = strEnrolAuthReqd;
	}

	public String getStrPymtAuthReqd() {
		return StrPymtAuthReqd;
	}

	public void setStrPymtAuthReqd(String strPymtAuthReqd) {
		StrPymtAuthReqd = strPymtAuthReqd;
	}

	public String getStrUserText01() {
		return StrUserText01;
	}

	public void setStrUserText01(String strUserText01) {
		StrUserText01 = strUserText01;
	}

	public String getStrUserText02() {
		return StrUserText02;
	}

	public void setStrUserText02(String strUserText02) {
		StrUserText02 = strUserText02;
	}

	public String getStrMainMerch() {
		return StrMainMerch;
	}

	public void setStrMainMerch(String strMainMerch) {
		StrMainMerch = strMainMerch;
	}

	public short getStrMinAge() {
		return StrMinAge;
	}

	public void setStrMinAge(short strMinAge) {
		StrMinAge = strMinAge;
	}

	public short getStrMaxAge() {
		return StrMaxAge;
	}

	public void setStrMaxAge(short strMaxAge) {
		StrMaxAge = strMaxAge;
	}

	public short getStrFixPymtCycle() {
		return StrFixPymtCycle;
	}

	public void setStrFixPymtCycle(short strFixPymtCycle) {
		StrFixPymtCycle = strFixPymtCycle;
	}

	public String getStrFixPymtFreq() {
		return StrFixPymtFreq;
	}

	public void setStrFixPymtFreq(String strFixPymtFreq) {
		StrFixPymtFreq = strFixPymtFreq;
	}

	public BigDecimal getStrFixPymtAmt() {
		return StrFixPymtAmt;
	}

	public void setStrFixPymtAmt(BigDecimal strFixPymtAmt) {
		StrFixPymtAmt = strFixPymtAmt;
	}

	public short getStrFreeMonths() {
		return StrFreeMonths;
	}

	public void setStrFreeMonths(short strFreeMonths) {
		StrFreeMonths = strFreeMonths;
	}

	public short getStrTotalFixPymts() {
		return StrTotalFixPymts;
	}

	public void setStrTotalFixPymts(short strTotalFixPymts) {
		StrTotalFixPymts = strTotalFixPymts;
	}

	public String getStrMerchType() {
		return StrMerchType;
	}

	public void setStrMerchType(String strMerchType) {
		StrMerchType = strMerchType;
	}

	public short getStrMerchFeeTxnCode() {
		return StrMerchFeeTxnCode;
	}

	public void setStrMerchFeeTxnCode(short strMerchFeeTxnCode) {
		StrMerchFeeTxnCode = strMerchFeeTxnCode;
	}

	public String getStrMerchFeeRateInd() {
		return StrMerchFeeRateInd;
	}

	public void setStrMerchFeeRateInd(String strMerchFeeRateInd) {
		StrMerchFeeRateInd = strMerchFeeRateInd;
	}

	public BigDecimal getStrMerchFeeRate() {
		return StrMerchFeeRate;
	}

	public void setStrMerchFeeRate(BigDecimal strMerchFeeRate) {
		StrMerchFeeRate = strMerchFeeRate;
	}

	public short getStrChFeeTxnCode() {
		return StrChFeeTxnCode;
	}

	public void setStrChFeeTxnCode(short strChFeeTxnCode) {
		StrChFeeTxnCode = strChFeeTxnCode;
	}

	public short getStrDebitTxnCode() {
		return StrDebitTxnCode;
	}

	public void setStrDebitTxnCode(short strDebitTxnCode) {
		StrDebitTxnCode = strDebitTxnCode;
	}

	public short getStrCreditTxnCode() {
		return StrCreditTxnCode;
	}

	public void setStrCreditTxnCode(short strCreditTxnCode) {
		StrCreditTxnCode = strCreditTxnCode;
	}

	public short getStrVatTxnCode() {
		return StrVatTxnCode;
	}

	public void setStrVatTxnCode(short strVatTxnCode) {
		StrVatTxnCode = strVatTxnCode;
	}

	public String getStrVatRateInd() {
		return StrVatRateInd;
	}

	public void setStrVatRateInd(String strVatRateInd) {
		StrVatRateInd = strVatRateInd;
	}

	public BigDecimal getStrVatRate() {
		return StrVatRate;
	}

	public void setStrVatRate(BigDecimal strVatRate) {
		StrVatRate = strVatRate;
	}

	public String getStrLtrcdEnApp() {
		return StrLtrcdEnApp;
	}

	public void setStrLtrcdEnApp(String strLtrcdEnApp) {
		StrLtrcdEnApp = strLtrcdEnApp;
	}

	public String getStrLtrcdEnRej() {
		return StrLtrcdEnRej;
	}

	public void setStrLtrcdEnRej(String strLtrcdEnRej) {
		StrLtrcdEnRej = strLtrcdEnRej;
	}

	public String getStrLtrcdEnReins() {
		return StrLtrcdEnReins;
	}

	public void setStrLtrcdEnReins(String strLtrcdEnReins) {
		StrLtrcdEnReins = strLtrcdEnReins;
	}

	public String getStrLtrcdEnCanc() {
		return StrLtrcdEnCanc;
	}

	public void setStrLtrcdEnCanc(String strLtrcdEnCanc) {
		StrLtrcdEnCanc = strLtrcdEnCanc;
	}

	public String getStrLtrcdPyApp() {
		return StrLtrcdPyApp;
	}

	public void setStrLtrcdPyApp(String strLtrcdPyApp) {
		StrLtrcdPyApp = strLtrcdPyApp;
	}

	public String getStrLtrcdPyRej() {
		return StrLtrcdPyRej;
	}

	public void setStrLtrcdPyRej(String strLtrcdPyRej) {
		StrLtrcdPyRej = strLtrcdPyRej;
	}

	public short getStrNoOfGifts() {
		return StrNoOfGifts;
	}

	public void setStrNoOfGifts(short strNoOfGifts) {
		StrNoOfGifts = strNoOfGifts;
	}

	public short getStrGiftTxnCode() {
		return StrGiftTxnCode;
	}

	public void setStrGiftTxnCode(short strGiftTxnCode) {
		StrGiftTxnCode = strGiftTxnCode;
	}

	public String getStrMccVisa() {
		return StrMccVisa;
	}

	public void setStrMccVisa(String strMccVisa) {
		StrMccVisa = strMccVisa;
	}

	public String getStrMccMc() {
		return StrMccMc;
	}

	public void setStrMccMc(String strMccMc) {
		StrMccMc = strMccMc;
	}

	public String getStrMccOther() {
		return StrMccOther;
	}

	public void setStrMccOther(String strMccOther) {
		StrMccOther = strMccOther;
	}

	public String getStrContactPerson() {
		return StrContactPerson;
	}

	public void setStrContactPerson(String strContactPerson) {
		StrContactPerson = strContactPerson;
	}

	public String getStrBizPhone() {
		return StrBizPhone;
	}

	public void setStrBizPhone(String strBizPhone) {
		StrBizPhone = strBizPhone;
	}

	public String getStrBizEmail() {
		return StrBizEmail;
	}

	public void setStrBizEmail(String strBizEmail) {
		StrBizEmail = strBizEmail;
	}

	public short getStrMaxPymtRejects() {
		return StrMaxPymtRejects;
	}

	public void setStrMaxPymtRejects(short strMaxPymtRejects) {
		StrMaxPymtRejects = strMaxPymtRejects;
	}

	public String getStrCancelCycleDue() {
		return StrCancelCycleDue;
	}

	public void setStrCancelCycleDue(String strCancelCycleDue) {
		StrCancelCycleDue = strCancelCycleDue;
	}

	public String getStrCancelCardStatus() {
		return StrCancelCardStatus;
	}

	public void setStrCancelCardStatus(String strCancelCardStatus) {
		StrCancelCardStatus = strCancelCardStatus;
	}

	public String getStrCancelBlk() {
		return StrCancelBlk;
	}

	public void setStrCancelBlk(String strCancelBlk) {
		StrCancelBlk = strCancelBlk;
	}

	public String getStrStmtDesc() {
		return StrStmtDesc;
	}

	public void setStrStmtDesc(String strStmtDesc) {
		StrStmtDesc = strStmtDesc;
	}

	public String getStrForceActive() {
		return StrForceActive;
	}

	public void setStrForceActive(String strForceActive) {
		StrForceActive = strForceActive;
	}

	public Timestamp getStrCreateTimeStamp() {
		return StrCreateTimeStamp;
	}

	public void setStrCreateTimeStamp(Timestamp strCreateTimeStamp) {
		StrCreateTimeStamp = strCreateTimeStamp;
	}

	public String getStrCreateUser() {
		return StrCreateUser;
	}

	public void setStrCreateUser(String strCreateUser) {
		StrCreateUser = strCreateUser;
	}

	public Timestamp getStrMaTimeStamp() {
		return StrMaTimeStamp;
	}

	public void setStrMaTimeStamp(Timestamp strMaTimeStamp) {
		StrMaTimeStamp = strMaTimeStamp;
	}

	public String getStrMaUser() {
		return StrMaUser;
	}

	public void setStrMaUser(String strMaUser) {
		StrMaUser = strMaUser;
	}

	public Timestamp getStrVerifyTimeStamp() {
		return StrVerifyTimeStamp;
	}

	public void setStrVerifyTimeStamp(Timestamp strVerifyTimeStamp) {
		StrVerifyTimeStamp = strVerifyTimeStamp;
	}

	public String getStrVerifyUser() {
		return StrVerifyUser;
	}

	public void setStrVerifyUser(String strVerifyUser) {
		StrVerifyUser = strVerifyUser;
	}

	public String getStrPreAuthReq() {
		return StrPreAuthReq;
	}

	public void setStrPreAuthReq(String strPreAuthReq) {
		StrPreAuthReq = strPreAuthReq;
	}

	public String getStrReq4Icard() {
		return StrReq4Icard;
	}

	public void setStrReq4Icard(String strReq4Icard) {
		StrReq4Icard = strReq4Icard;
	}

	public Date getStrSetupStr() {
		return StrSetupStr;
	}

	public void setStrSetupStr(Date strSetupStr) {
		StrSetupStr = strSetupStr;
	}

	public String getStrTxnTypAllow() {
		return StrTxnTypAllow;
	}

	public void setStrTxnTypAllow(String strTxnTypAllow) {
		StrTxnTypAllow = strTxnTypAllow;
	}

	public String getStrReserveData() {
		return StrReserveData;
	}

	public void setStrReserveData(String strReserveData) {
		StrReserveData = strReserveData;
	}

}

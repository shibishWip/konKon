package com.citi.cards.abps.repository;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class BasicRepository<T1, T2> {// T1 list entity Class, T2, details
										// Entity Class

	@PersistenceContext
	private EntityManager em;

	/**
	 * find entity list by conditions
	 * 
	 * @param query
	 */
	public List find() {
		return null;
	}

	/**
	 * 
	 * @param query
	 * @param klaz
	 * @return
	 */
	public List find(String query, Class klaz) {
		return null;
	}

	/**
	 * 
	 * find one entity by condition
	 * 
	 * @param query
	 * @return
	 */
	public T2 findOne(String query) {
		return null;
	}

	/**
	 * 
	 * update
	 * 
	 * @param query
	 * @param update
	 * @return
	 */
	public void update() {

	}

	/**
	 * 
	 * update
	 * 
	 * @param query
	 * @param update
	 * @return
	 */
	public void delete(T2 bean) {

	}

	/**
	 * 
	 * 
	 * @param bean
	 * @return
	 */
	public T2 save(T2 bean) {

		return bean;
	}

	/**
	 *
	 * 
	 * @param id
	 * @return
	 */
	public T2 get(String id, Class klaz) {
		return null;
	}

	/**
	 *
	 * 
	 * @param id
	 * @param collectionName
	 * 
	 * @return
	 */
	public T2 get(String id, String collectionName, Class klaz) {
		return null;
	}

	/**
	 *
	 * 
	 * @param id
	 * @param collectionName
	 * 
	 * @return
	 */
	public boolean exist(String query) {
		return false;
	}

	public <T> Class getEntityClass(int index) {
		Class<T> entityClass = null;
		Type t = getClass().getGenericSuperclass();
		if (t instanceof ParameterizedType) {
			Type[] p = ((ParameterizedType) t).getActualTypeArguments();
			entityClass = (Class<T>) p[index];
		}
		return entityClass;
	}

}

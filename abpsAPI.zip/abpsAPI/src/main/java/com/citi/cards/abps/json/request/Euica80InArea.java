package com.citi.cards.abps.json.request;

import org.springframework.stereotype.Component;

@Component
public class Euica80InArea {
	private short ica80_di_org;

	private String ica80_di_card_nbr;

	public short getIca80_di_org() {
		return ica80_di_org;
	}

	public void setIca80_di_org(short ica80_di_org) {
		this.ica80_di_org = ica80_di_org;
	}

	public String getIca80_di_card_nbr() {
		return ica80_di_card_nbr;
	}

	public void setIca80_di_card_nbr(String ica80_di_card_nbr) {
		this.ica80_di_card_nbr = ica80_di_card_nbr;
	}

	@Override
	public String toString() {
		return "ClassPojo [ica80_di_org = " + ica80_di_org + ", ica80_di_card_nbr = " + ica80_di_card_nbr + "]";
	}
}

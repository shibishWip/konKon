package com.citi.cards.abps.json.request;

import org.springframework.stereotype.Component;

@Component
public class Mca80InData {

	private int mca80_in_message_id;

	private String mca80_in_user;

	private int mca80_in_version;

	private String mca80_in_term_id;

	private long mca80_in_req_time;

	public int getMca80_in_message_id() {
		return mca80_in_message_id;
	}

	public void setMca80_in_message_id(int mca80_in_message_id) {
		this.mca80_in_message_id = mca80_in_message_id;
	}

	public String getMca80_in_user() {
		return mca80_in_user;
	}

	public void setMca80_in_user(String mca80_in_user) {
		this.mca80_in_user = mca80_in_user;
	}

	public int getMca80_in_version() {
		return mca80_in_version;
	}

	public void setMca80_in_version(int mca80_in_version) {
		this.mca80_in_version = mca80_in_version;
	}

	public String getMca80_in_term_id() {
		return mca80_in_term_id;
	}

	public void setMca80_in_term_id(String mca80_in_term_id) {
		this.mca80_in_term_id = mca80_in_term_id;
	}

	public long getMca80_in_req_time() {
		return mca80_in_req_time;
	}

	public void setMca80_in_req_time(long mca80_in_req_time) {
		this.mca80_in_req_time = mca80_in_req_time;
	}

	@Override
	public String toString() {
		return "ClassPojo [mca80_in_message_id = " + mca80_in_message_id + ", mca80_in_user = " + mca80_in_user
				+ ", mca80_in_version = " + mca80_in_version + ", mca80_in_term_id = " + mca80_in_term_id
				+ ", mca80_in_req_time = " + mca80_in_req_time + "]";
	}
}

package com.citi.cards.abps.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.cards.abps.entity.ExceptionEntity;
import com.citi.cards.abps.entity.SuccessEntity;
import com.citi.cards.abps.entity.pojo.AccountsEntity;
import com.citi.cards.abps.entity.pojo.AccountsListEntity;
import com.citi.cards.abps.entity.pojo.MerchantsEntity;
import com.citi.cards.abps.service.AccountsService;
import com.citi.cards.abps.service.MerchantsService;
import com.citi.cards.abps.util.DateSerializer;
import com.citi.cards.abps.util.RegistrationDataCheck;
import com.citi.cards.abps.util.UtilityBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@RestController
@RequestMapping("/Accounts")
public class AccountsController extends BaseController {

	@Autowired
	AccountsService abpsAccountsService;
	@Autowired
	MerchantsService abpsMerchantsService;
	@Autowired
	RegistrationDataCheck registrationDataCheck;
	@JsonIgnoreProperties(ignoreUnknown = true)

	public static final String DB2_DATE_FORMAT = "yyyy-MM-dd";
	public static final String TEXT_BOX_DATE_FORMAT = "dd-MMM-yyyy";
	public static final String CARD_FORMAT = "MMyy";

	@RequestMapping(value = "/ABPSLIST", method = RequestMethod.POST)
	public @ResponseBody Map<String, List<Object>> listABPSRecords(@RequestBody String str,
			HttpServletResponse response) {
		// System.out.println("AccountsController ABPSLISTING in" );
		UtilityBean.setAccessControll(response);
		System.out.println("listABPSRecords   "+str);
		Map retMap = new HashMap();

		List<String> responseStringArr = new ArrayList<String>();

		AccountsListEntity acc = null;

		try {
			Map conditions = (Map) UtilityBean.convert2ObjectFromStr(str, Map.class);
			List ABPSList = abpsAccountsService.find(conditions);
			retMap = genRetMap(retMap, ABPSList);

		} catch (Exception e) {
			e.printStackTrace();
			retMap = genRetMap(retMap, new Exception(e));
		} finally {
			// System.out.println(" AccountsController ABPSLISTING Finally " +
			// retMap);
		}
		return retMap;

	}

	@RequestMapping(value = "/ABPSADD", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> addBilling(@RequestBody String str) {
		// System.out.println("ADD in");

		System.out.println("addBilling   "+str);
		Map retMap = new HashMap();

		try {

			GsonBuilder gsonBuilder = new GsonBuilder();
			gsonBuilder.setDateFormat(DB2_DATE_FORMAT);
			gsonBuilder.registerTypeAdapter(Date.class, new DateSerializer());
			Gson gson = gsonBuilder.create();
			AccountsEntity objEntity = gson.fromJson(str, AccountsEntity.class);

			MerchantsEntity merchantsEntity = abpsMerchantsService.enquiry(objEntity.getStrMerchOrg(),
					objEntity.getStrMerchNmbr());
			ExceptionEntity exceptionEntity = registrationDataCheck.dataCheck(objEntity, merchantsEntity);

			/*
			 * System.out.println("exceptionEntity  getErrCode  ****    " +
			 * exceptionEntity.getErrCode()); System.out.println(
			 * "exceptionEntity  getErrType  ****    " +
			 * exceptionEntity.getErrType()); System.out.println(
			 * "exceptionEntity  getMessage  ****    " +
			 * exceptionEntity.getMessage());
			 */

			if (exceptionEntity.getErrCode().equals("0000")) {
				abpsAccountsService.save(objEntity);
				SuccessEntity se = genSuccessEntity("Billing CODE", objEntity.getStrStatusReason());
				retMap = genRetMap(retMap, genSuccessEntity(se, "NEW", "New Registration Sucess"));
			} else {
				retMap = genRetMap(retMap, exceptionEntity);
			}

		} catch (Exception e) {
			e.printStackTrace();
			e.getCause();
			e.getMessage();
			retMap = genRetMap(retMap, new Exception(e.getMessage()));
			Exception error = new Exception(e.getMessage());
			retMap = genRetMap(retMap, genExceptionEntity("9999", "ERROR ON DATA", error.getMessage()));

		} finally {
			// System.out.println("BillingController BillingADD out");
		}
		return retMap;
	}

}

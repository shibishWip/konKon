package com.citi.cards.abps.entity.pojo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author ag07254
 *
 */
@Entity
@Table(name = "EUUA_UTIL_ACCT")

public class AccountsEntity implements Serializable {

	@Id
	@Column(name = "CARD_ORG")
	private short StrCardOrg;
	@Id
	@Column(name = "CARD_LOGO")
	private short StrCardLogo;
	@Id
	@Column(name = "CARD_NMBR")
	private String StrCardNmbr;
	@Id
	@Column(name = "MERCH_ORG")
	private short StrMerchOrg;
	@Id
	@Column(name = "MERCH_NMBR")
	private BigDecimal StrMerchNmbr;
	@Id
	@Column(name = "UTIL_ACCT_NMBR")
	private String StrUtilAcctNmbr;

	@Column(name = "CARD_SEQ_NO")
	private short StrCardSeqNo;
	@Column(name = "ALT_CARD_CHK_FLAG")
	private String StrAltCardChkFlag;
	@Column(name = "CUST_ORG")
	private short StrCustOrg;
	@Column(name = "CUST_NMBR")
	private String StrCustNmbr;
	@Column(name = "UTIL_REF_NMBR")
	private String StrUtilRefNmbr;
	@Column(name = "UTIL_OWNER_NAME")
	private String StrUtilOwnerName;
	@Column(name = "STATUS")
	private String StrStatus;
	@Column(name = "STATUS_REASON")
	private String StrStatusReason;
	@Column(name = "ENROL_DATE")
	private Date StrEnrolDate;
	@Column(name = "STATUS_DATE")
	private Date StrStatusDate;
	@Column(name = "PYMT_CHANNEL")
	private String StrPymtChannel;
	@Column(name = "SOURCE")
	private String StrSource;
	@Column(name = "FIX_PYMT_STATUS")
	private String StrFixPymtStatus;
	@Column(name = "FIX_PYMT_FREQ")
	private String StrFixPymtFreq;
	@Column(name = "FIX_PYMT_CYCLE")
	private short StrFixPymtCycle;
	@Column(name = "FIX_PYMT_AMT")
	private BigDecimal StrFixPymtAmt;
	@Column(name = "FIX_PYMT_EFF_DATE")
	private Date StrFixPymtEffDate;
	@Column(name = "FIX_PYMT_STAT_DATE")
	private Date StrFixPymtStatDate;
	@Column(name = "LAST_PYMT_DATE")
	private Date StrLastPymtDate;
	@Column(name = "LAST_PYMT_AMT")
	private BigDecimal StrLastPymtAmt;
	@Column(name = "USER_TEXT_01")
	private String StrUserText01;
	@Column(name = "USER_TEXT_02")
	private String StrUserText02;
	@Column(name = "USER_TEXT_03")
	private String StrUserText03;
	@Column(name = "USER_TEXT_04")
	private String StrUserText04;
	@Column(name = "USER_TEXT_05")
	private String StrUserText05;
	@Column(name = "LAST_PYMT_CARD")
	private String StrLastPymtCard;
	@Column(name = "UTIL_ACCT_NMBR2")
	private String StrUtilAcctNmbr2;
	@Column(name = "CURR_UTIL_STAT")
	private String StrCurrUtilStat;
	@Column(name = "CURR_UTIL_STAT_RSN")
	private String StrCurrUtilStatRsn;
	@Column(name = "CURR_UTIL_STAT_DTE")
	private Date StrCurrUtilStatDte;
	@Column(name = "FIX_PYMT_NBR_TOT")
	private short StrFixPymtNbrTot;
	@Column(name = "FIX_PYMT_NBR_REM")
	private short StrFixPymtNbrRem;
	@Column(name = "FIX_PYMT_FREE_NBR")
	private short StrFixPymtFreeNbr;
	@Column(name = "FIX_PYMT_FREE_REM")
	private short StrFixPymtFreeRem;
	@Column(name = "GIFT_PYMT_NBR_TOT")
	private short StrGiftPymtNbrTot;
	@Column(name = "GIFT_PYMT_NBR_REM")
	private short StrGiftPymtNbrRem;
	@Column(name = "FIX_PYMT_EXP_MMYY")
	private short StrFixPymtExpMmyy;
	@Column(name = "FIX_PYMT_1ST_PYDTE")
	private Date StrFixPymt1stPydte;
	// @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REACTIVATED_DATE")
	private Timestamp StrReactivatedDate;
	@Column(name = "REACTIVATED_USER")
	private String StrReactivatedUser;
	// @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CANCELLATION_DATE")
	private Timestamp StrCancellationDate;
	@Column(name = "CANCELLATION_USER")
	private String StrCancellationUser;
	@Column(name = "RECUR_PYMT_REJECTS")
	private short StrRecurPymtRejects;
	@Column(name = "BILL_PAY_CYCLE_DT")
	private String StrBillPayCycleDt;
	@Column(name = "BILL_PAY_CYCLE_DUE")
	private String StrBillPayCycleDue;
	// @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME_STAMP")
	private Timestamp StrCreateTimeStamp;
	@Column(name = "CREATE_USER")
	private String StrCreateUser;
	/// @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MAINT_TIME_STAMP")
	private Timestamp StrMaintTimeStamp;
	@Column(name = "MAINT_USER")
	private String StrMaintUser;
	// @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "VERIFY_TIME_STAMP")
	private Timestamp StrVerifyTimeStamp;
	@Column(name = "VERIFY_USER")
	private String StrVerifyUser;
	@Column(name = "PYMT_END_DATE")
	private Date StrPymtEndDate;
	@Column(name = "RECURR_PYMT_IND")
	private String StrRecurrPymtInd;
	@Column(name = "UNMH_IND")
	private String StrUnmhInd;
	@Column(name = "MICROFILM")
	private String StrMicrofilm;
	@Column(name = "PROG_CODE")
	private String StrProgCode;
	@Column(name = "AGENT_CODE ")
	private String StrAgentCode;
	@Column(name = "CUST_ID")
	private String StrCustId;
	@Column(name = "UTIL_TYPE")
	private String StrUtilType;
	@Column(name = "EX_BANK_CODE")
	private String StrExBankCode;
	@Column(name = "EX_BRANCH_CODE")
	private String StrExBranchCode;
	@Column(name = "BANK_ABBREV")
	private String StrBankAbbrev;
	@Column(name = "BANK_PAY_AMNT")
	private BigDecimal StrBankPayAmnt;
	@Column(name = "HANDPHONE")
	private String StrHandphone;
	@Column(name = "PYMT_MODE")
	private String StrPymtMode;
	@Column(name = "REG_EXP_DATE")
	private Date StrRegExpDate;
	@Column(name = "STAT_MAINT_DTE")
	private Date StrStatMaintDte;
	@Column(name = "XFER_IND")
	private String StrXferInd;
	@Column(name = "ENRL_ACDTE")
	private Date StrEnrlAcdte;
	@Column(name = "ENRL_USRID")
	private String StrEnrlUsrid;
	@Column(name = "ACCT_ORG")
	private short StrAcctOrg;
	@Column(name = "ACCT_NMBR")
	private String StrAcctNmbr;
	@Column(name = "ECSCUS_UNIQUE_NO")
	private String StrEcscusUniqueNo;
	@Column(name = "RESERVE_DATA")
	private String StrReserveData;

	/*
	 * //private String StrBicCode; //private String StrBicCodeFlag;
	 * 
	 * public String getStrBicCode() { return StrBicCode; } public void
	 * setStrBicCode(String StrBicCode) { this.StrBicCode = StrBicCode; } public
	 * String getStrBicCodeFlag() { return StrBicCodeFlag; } public void
	 * setStrBicCodeFlag(String StrBicCodeFlag) { this.StrBicCodeFlag =
	 * StrBicCodeFlag; }
	 */
	
	public short getStrCardOrg() {
		return StrCardOrg;
	}

	public void setStrCardOrg(short StrCardOrg) {
		this.StrCardOrg = StrCardOrg;
	}

	public short getStrCardLogo() {
		return StrCardLogo;
	}

	public void setStrCardLogo(short StrCardLogo) {
		this.StrCardLogo = StrCardLogo;
	}

	public String getStrCardNmbr() {
		return StrCardNmbr;
	}

	public void setStrCardNmbr(String StrCardNmbr) {
		this.StrCardNmbr = StrCardNmbr;
	}

	public short getStrMerchOrg() {
		return StrMerchOrg;
	}

	public void setStrMerchOrg(short StrMerchOrg) {
		this.StrMerchOrg = StrMerchOrg;
	}

	public BigDecimal getStrMerchNmbr() {
		return StrMerchNmbr;
	}

	public void setStrMerchNmbr(BigDecimal StrMerchNmbr) {
		this.StrMerchNmbr = StrMerchNmbr;
	}

	public String getStrUtilAcctNmbr() {
		return StrUtilAcctNmbr;
	}

	public void setStrUtilAcctNmbr(String StrUtilAcctNmbr) {
		this.StrUtilAcctNmbr = StrUtilAcctNmbr;
	}

	public short getStrCardSeqNo() {
		return StrCardSeqNo;
	}

	public void setStrCardSeqNo(short StrCardSeqNo) {
		this.StrCardSeqNo = StrCardSeqNo;
	}

	public String getStrAltCardChkFlag() {
		return StrAltCardChkFlag;
	}

	public void setStrAltCardChkFlag(String StrAltCardChkFlag) {
		this.StrAltCardChkFlag = StrAltCardChkFlag;
	}

	public short getStrCustOrg() {
		return StrCustOrg;
	}

	public void setStrCustOrg(short StrCustOrg) {
		this.StrCustOrg = StrCustOrg;
	}

	public String getStrCustNmbr() {
		return StrCustNmbr;
	}

	public void setStrCustNmbr(String StrCustNmbr) {
		this.StrCustNmbr = StrCustNmbr;
	}

	public String getStrUtilRefNmbr() {
		return StrUtilRefNmbr;
	}

	public void setStrUtilRefNmbr(String StrUtilRefNmbr) {
		this.StrUtilRefNmbr = StrUtilRefNmbr;
	}

	public String getStrUtilOwnerName() {
		return StrUtilOwnerName;
	}

	public void setStrUtilOwnerName(String StrUtilOwnerName) {
		this.StrUtilOwnerName = StrUtilOwnerName;
	}

	public String getStrStatus() {
		return StrStatus;
	}

	public void setStrStatus(String StrStatus) {
		this.StrStatus = StrStatus;
	}

	public String getStrStatusReason() {
		return StrStatusReason;
	}

	public void setStrStatusReason(String StrStatusReason) {
		this.StrStatusReason = StrStatusReason;
	}

	public Date getStrEnrolDate() {
		return StrEnrolDate;
	}

	public void setStrEnrolDate(Date StrEnrolDate) {
		this.StrEnrolDate = StrEnrolDate;
	}

	public Date getStrStatusDate() {
		return StrStatusDate;
	}

	public void setStrStatusDate(Date StrStatusDate) {
		this.StrStatusDate = StrStatusDate;
	}

	public String getStrPymtChannel() {
		return StrPymtChannel;
	}

	public void setStrPymtChannel(String StrPymtChannel) {
		this.StrPymtChannel = StrPymtChannel;
	}

	public String getStrSource() {
		return StrSource;
	}

	public void setStrSource(String StrSource) {
		this.StrSource = StrSource;
	}

	public String getStrFixPymtStatus() {
		return StrFixPymtStatus;
	}

	public void setStrFixPymtStatus(String StrFixPymtStatus) {
		this.StrFixPymtStatus = StrFixPymtStatus;
	}

	public String getStrFixPymtFreq() {
		return StrFixPymtFreq;
	}

	public void setStrFixPymtFreq(String StrFixPymtFreq) {
		this.StrFixPymtFreq = StrFixPymtFreq;
	}

	public short getStrFixPymtCycle() {
		return StrFixPymtCycle;
	}

	public void setStrFixPymtCycle(short StrFixPymtCycle) {
		this.StrFixPymtCycle = StrFixPymtCycle;
	}

	public BigDecimal getStrFixPymtAmt() {
		return StrFixPymtAmt;
	}

	public void setStrFixPymtAmt(BigDecimal StrFixPymtAmt) {
		this.StrFixPymtAmt = StrFixPymtAmt;
	}

	public Date getStrFixPymtEffDate() {
		return StrFixPymtEffDate;
	}

	public void setStrFixPymtEffDate(Date StrFixPymtEffDate) {
		this.StrFixPymtEffDate = StrFixPymtEffDate;
	}

	public Date getStrFixPymtStatDate() {
		return StrFixPymtStatDate;
	}

	public void setStrFixPymtStatDate(Date StrFixPymtStatDate) {
		this.StrFixPymtStatDate = StrFixPymtStatDate;
	}

	public Date getStrLastPymtDate() {
		return StrLastPymtDate;
	}

	public void setStrLastPymtDate(Date StrLastPymtDate) {
		this.StrLastPymtDate = StrLastPymtDate;
	}

	public BigDecimal getStrLastPymtAmt() {
		return StrLastPymtAmt;
	}

	public void setStrLastPymtAmt(BigDecimal StrLastPymtAmt) {
		this.StrLastPymtAmt = StrLastPymtAmt;
	}

	public String getStrUserText01() {
		return StrUserText01;
	}

	public void setStrUserText01(String StrUserText01) {
		this.StrUserText01 = StrUserText01;
	}

	public String getStrUserText02() {
		return StrUserText02;
	}

	public void setStrUserText02(String StrUserText02) {
		this.StrUserText02 = StrUserText02;
	}

	public String getStrUserText03() {
		return StrUserText03;
	}

	public void setStrUserText03(String StrUserText03) {
		this.StrUserText03 = StrUserText03;
	}

	public String getStrUserText04() {
		return StrUserText04;
	}

	public void setStrUserText04(String StrUserText04) {
		this.StrUserText04 = StrUserText04;
	}

	public String getStrUserText05() {
		return StrUserText05;
	}

	public void setStrUserText05(String StrUserText05) {
		this.StrUserText05 = StrUserText05;
	}

	public String getStrLastPymtCard() {
		return StrLastPymtCard;
	}

	public void setStrLastPymtCard(String StrLastPymtCard) {
		this.StrLastPymtCard = StrLastPymtCard;
	}

	public String getStrUtilAcctNmbr2() {
		return StrUtilAcctNmbr2;
	}

	public void setStrUtilAcctNmbr2(String StrUtilAcctNmbr2) {
		this.StrUtilAcctNmbr2 = StrUtilAcctNmbr2;
	}

	public String getStrCurrUtilStat() {
		return StrCurrUtilStat;
	}

	public void setStrCurrUtilStat(String StrCurrUtilStat) {
		this.StrCurrUtilStat = StrCurrUtilStat;
	}

	public String getStrCurrUtilStatRsn() {
		return StrCurrUtilStatRsn;
	}

	public void setStrCurrUtilStatRsn(String StrCurrUtilStatRsn) {
		this.StrCurrUtilStatRsn = StrCurrUtilStatRsn;
	}

	public Date getStrCurrUtilStatDte() {
		return StrCurrUtilStatDte;
	}

	public void setStrCurrUtilStatDte(Date StrCurrUtilStatDte) {
		this.StrCurrUtilStatDte = StrCurrUtilStatDte;
	}

	public short getStrFixPymtNbrTot() {
		return StrFixPymtNbrTot;
	}

	public void setStrFixPymtNbrTot(short StrFixPymtNbrTot) {
		this.StrFixPymtNbrTot = StrFixPymtNbrTot;
	}

	public short getStrFixPymtNbrRem() {
		return StrFixPymtNbrRem;
	}

	public void setStrFixPymtNbrRem(short StrFixPymtNbrRem) {
		this.StrFixPymtNbrRem = StrFixPymtNbrRem;
	}

	public short getStrFixPymtFreeNbr() {
		return StrFixPymtFreeNbr;
	}

	public void setStrFixPymtFreeNbr(short StrFixPymtFreeNbr) {
		this.StrFixPymtFreeNbr = StrFixPymtFreeNbr;
	}

	public short getStrFixPymtFreeRem() {
		return StrFixPymtFreeRem;
	}

	public void setStrFixPymtFreeRem(short StrFixPymtFreeRem) {
		this.StrFixPymtFreeRem = StrFixPymtFreeRem;
	}

	public short getStrGiftPymtNbrTot() {
		return StrGiftPymtNbrTot;
	}

	public void setStrGiftPymtNbrTot(short StrGiftPymtNbrTot) {
		this.StrGiftPymtNbrTot = StrGiftPymtNbrTot;
	}

	public short getStrGiftPymtNbrRem() {
		return StrGiftPymtNbrRem;
	}

	public void setStrGiftPymtNbrRem(short StrGiftPymtNbrRem) {
		this.StrGiftPymtNbrRem = StrGiftPymtNbrRem;
	}

	public short getStrFixPymtExpMmyy() {
		return StrFixPymtExpMmyy;
	}

	public void setStrFixPymtExpMmyy(short StrFixPymtExpMmyy) {
		this.StrFixPymtExpMmyy = StrFixPymtExpMmyy;
	}

	public Date getStrFixPymt1stPydte() {
		return StrFixPymt1stPydte;
	}

	public void setStrFixPymt1stPydte(Date StrFixPymt1stPydte) {
		this.StrFixPymt1stPydte = StrFixPymt1stPydte;
	}

	public Timestamp getStrReactivatedDate() {
		return StrReactivatedDate;
	}

	public void setStrReactivatedDate(Timestamp StrReactivatedDate) {
		this.StrReactivatedDate = StrReactivatedDate;
	}

	public String getStrReactivatedUser() {
		return StrReactivatedUser;
	}

	public void setStrReactivatedUser(String StrReactivatedUser) {
		this.StrReactivatedUser = StrReactivatedUser;
	}

	public Timestamp getStrCancellationDate() {
		return StrCancellationDate;
	}

	public void setStrCancellationDate(Timestamp StrCancellationDate) {
		this.StrCancellationDate = StrCancellationDate;
	}

	public String getStrCancellationUser() {
		return StrCancellationUser;
	}

	public void setStrCancellationUser(String StrCancellationUser) {
		this.StrCancellationUser = StrCancellationUser;
	}

	public short getStrRecurPymtRejects() {
		return StrRecurPymtRejects;
	}

	public void setStrRecurPymtRejects(short StrRecurPymtRejects) {
		this.StrRecurPymtRejects = StrRecurPymtRejects;
	}

	public String getStrBillPayCycleDt() {
		return StrBillPayCycleDt;
	}

	public void setStrBillPayCycleDt(String StrBillPayCycleDt) {
		this.StrBillPayCycleDt = StrBillPayCycleDt;
	}

	public String getStrBillPayCycleDue() {
		return StrBillPayCycleDue;
	}

	public void setStrBillPayCycleDue(String StrBillPayCycleDue) {
		this.StrBillPayCycleDue = StrBillPayCycleDue;
	}

	public Timestamp getStrCreateTimeStamp() {
		return StrCreateTimeStamp;
	}

	public void setStrCreateTimeStamp(Timestamp StrCreateTimeStamp) {
		this.StrCreateTimeStamp = StrCreateTimeStamp;
	}

	public String getStrCreateUser() {
		return StrCreateUser;
	}

	public void setStrCreateUser(String StrCreateUser) {
		this.StrCreateUser = StrCreateUser;
	}

	public Timestamp getStrMaintTimeStamp() {
		return StrMaintTimeStamp;
	}

	public void setStrMaintTimeStamp(Timestamp StrMaintTimeStamp) {
		this.StrMaintTimeStamp = StrMaintTimeStamp;
	}

	public String getStrMaintUser() {
		return StrMaintUser;
	}

	public void setStrMaintUser(String StrMaintUser) {
		this.StrMaintUser = StrMaintUser;
	}

	public Timestamp getStrVerifyTimeStamp() {
		return StrVerifyTimeStamp;
	}

	public void setStrVerifyTimeStamp(Timestamp StrVerifyTimeStamp) {
		this.StrVerifyTimeStamp = StrVerifyTimeStamp;
	}

	public String getStrVerifyUser() {
		return StrVerifyUser;
	}

	public void setStrVerifyUser(String StrVerifyUser) {
		this.StrVerifyUser = StrVerifyUser;
	}

	public Date getStrPymtEndDate() {
		return StrPymtEndDate;
	}

	public void setStrPymtEndDate(Date StrPymtEndDate) {
		this.StrPymtEndDate = StrPymtEndDate;
	}

	public String getStrRecurrPymtInd() {
		return StrRecurrPymtInd;
	}

	public void setStrRecurrPymtInd(String StrRecurrPymtInd) {
		this.StrRecurrPymtInd = StrRecurrPymtInd;
	}

	public String getStrUnmhInd() {
		return StrUnmhInd;
	}

	public void setStrUnmhInd(String StrUnmhInd) {
		this.StrUnmhInd = StrUnmhInd;
	}

	public String getStrMicrofilm() {
		return StrMicrofilm;
	}

	public void setStrMicrofilm(String StrMicrofilm) {
		this.StrMicrofilm = StrMicrofilm;
	}

	public String getStrProgCode() {
		return StrProgCode;
	}

	public void setStrProgCode(String StrProgCode) {
		this.StrProgCode = StrProgCode;
	}

	public String getStrAgentCode() {
		return StrAgentCode;
	}

	public void setStrAgentCode(String StrAgentCode) {
		this.StrAgentCode = StrAgentCode;
	}

	public String getStrCustId() {
		return StrCustId;
	}

	public void setStrCustId(String StrCustId) {
		this.StrCustId = StrCustId;
	}

	public String getStrUtilType() {
		return StrUtilType;
	}

	public void setStrUtilType(String StrUtilType) {
		this.StrUtilType = StrUtilType;
	}

	public String getStrExBankCode() {
		return StrExBankCode;
	}

	public void setStrExBankCode(String StrExBankCode) {
		this.StrExBankCode = StrExBankCode;
	}

	public String getStrExBranchCode() {
		return StrExBranchCode;
	}

	public void setStrExBranchCode(String StrExBranchCode) {
		this.StrExBranchCode = StrExBranchCode;
	}

	public String getStrBankAbbrev() {
		return StrBankAbbrev;
	}

	public void setStrBankAbbrev(String StrBankAbbrev) {
		this.StrBankAbbrev = StrBankAbbrev;
	}

	public BigDecimal getStrBankPayAmnt() {
		return StrBankPayAmnt;
	}

	public void setStrBankPayAmnt(BigDecimal StrBankPayAmnt) {
		this.StrBankPayAmnt = StrBankPayAmnt;
	}

	public String getStrHandphone() {
		return StrHandphone;
	}

	public void setStrHandphone(String StrHandphone) {
		this.StrHandphone = StrHandphone;
	}

	public String getStrPymtMode() {
		return StrPymtMode;
	}

	public void setStrPymtMode(String StrPymtMode) {
		this.StrPymtMode = StrPymtMode;
	}

	public Date getStrRegExpDate() {
		return StrRegExpDate;
	}

	public void setStrRegExpDate(Date StrRegExpDate) {
		this.StrRegExpDate = StrRegExpDate;
	}

	public Date getStrStatMaintDte() {
		return StrStatMaintDte;
	}

	public void setStrStatMaintDte(Date StrStatMaintDte) {
		this.StrStatMaintDte = StrStatMaintDte;
	}

	public String getStrXferInd() {
		return StrXferInd;
	}

	public void setStrXferInd(String StrXferInd) {
		this.StrXferInd = StrXferInd;
	}

	public Date getStrEnrlAcdte() {
		return StrEnrlAcdte;
	}

	public void setStrEnrlAcdte(Date StrEnrlAcdte) {
		this.StrEnrlAcdte = StrEnrlAcdte;
	}

	public String getStrEnrlUsrid() {
		return StrEnrlUsrid;
	}

	public void setStrEnrlUsrid(String StrEnrlUsrid) {
		this.StrEnrlUsrid = StrEnrlUsrid;
	}

	public short getStrAcctOrg() {
		return StrAcctOrg;
	}

	public void setStrAcctOrg(short StrAcctOrg) {
		this.StrAcctOrg = StrAcctOrg;
	}

	public String getStrAcctNmbr() {
		return StrAcctNmbr;
	}

	public void setStrAcctNmbr(String StrAcctNmbr) {
		this.StrAcctNmbr = StrAcctNmbr;
	}

	public String getStrEcscusUniqueNo() {
		return StrEcscusUniqueNo;
	}

	public void setStrEcscusUniqueNo(String StrEcscusUniqueNo) {
		this.StrEcscusUniqueNo = StrEcscusUniqueNo;
	}

	public String getStrReserveData() {
		return StrReserveData;
	}

	public void setStrReserveData(String StrReserveData) {
		this.StrReserveData = StrReserveData;
	}

	@Override
	public String toString() {
		return "AccountsEntity [StrCardOrg=" + StrCardOrg + ",\n StrCardLogo=" + StrCardLogo + ",\n StrCardNmbr="
				+ StrCardNmbr + ",\n StrMerchOrg=" + StrMerchOrg + ",\n StrMerchNmbr=" + StrMerchNmbr
				+ ",\n StrUtilAcctNmbr=" + StrUtilAcctNmbr + ",\n StrCardSeqNo=" + StrCardSeqNo
				+ ",\n StrAltCardChkFlag=" + StrAltCardChkFlag + ",\n StrCustOrg=" + StrCustOrg + ",\n StrCustNmbr="
				+ StrCustNmbr + ",\n StrUtilRefNmbr=" + StrUtilRefNmbr + ",\n StrUtilOwnerName=" + StrUtilOwnerName
				+ ",\n StrStatus=" + StrStatus + ",\n StrStatusReason=" + StrStatusReason + ",\n StrEnrolDate="
				+ StrEnrolDate + ",\n StrStatusDate=" + StrStatusDate + ",\n StrPymtChannel=" + StrPymtChannel
				+ ",\n StrSource=" + StrSource + ",\n StrFixPymtStatus=" + StrFixPymtStatus + ",\n StrFixPymtFreq="
				+ StrFixPymtFreq + ",\n StrFixPymtCycle=" + StrFixPymtCycle + ",\n StrFixPymtAmt=" + StrFixPymtAmt
				+ ",\n StrFixPymtEffDate=" + StrFixPymtEffDate + ",\n StrFixPymtStatDate=" + StrFixPymtStatDate
				+ ",\n StrLastPymtDate=" + StrLastPymtDate + ",\n StrLastPymtAmt=" + StrLastPymtAmt
				+ ",\n StrUserText01=" + StrUserText01 + ",\n StrUserText02=" + StrUserText02 + ",\n StrUserText03="
				+ StrUserText03 + ",\n StrUserText04=" + StrUserText04 + ",\n StrUserText05=" + StrUserText05
				+ ",\n StrLastPymtCard=" + StrLastPymtCard + ",\n StrUtilAcctNmbr2=" + StrUtilAcctNmbr2
				+ ",\n StrCurrUtilStat=" + StrCurrUtilStat + ",\n StrCurrUtilStatRsn=" + StrCurrUtilStatRsn
				+ ",\n StrCurrUtilStatDte=" + StrCurrUtilStatDte + ",\n StrFixPymtNbrTot=" + StrFixPymtNbrTot
				+ ",\n StrFixPymtNbrRem=" + StrFixPymtNbrRem + ",\n StrFixPymtFreeNbr=" + StrFixPymtFreeNbr
				+ ",\n StrFixPymtFreeRem=" + StrFixPymtFreeRem + ",\n StrGiftPymtNbrTot=" + StrGiftPymtNbrTot
				+ ",\n StrGiftPymtNbrRem=" + StrGiftPymtNbrRem + ",\n StrFixPymtExpMmyy=" + StrFixPymtExpMmyy
				+ ",\n StrFixPymt1stPydte=" + StrFixPymt1stPydte + ",\n StrReactivatedDate=" + StrReactivatedDate
				+ ",\n StrReactivatedUser=" + StrReactivatedUser + ",\n StrCancellationDate=" + StrCancellationDate
				+ ",\n StrCancellationUser=" + StrCancellationUser + ",\n StrRecurPymtRejects=" + StrRecurPymtRejects
				+ ",\n StrBillPayCycleDt=" + StrBillPayCycleDt + ",\n StrBillPayCycleDue=" + StrBillPayCycleDue
				+ ",\n StrCreateTimeStamp=" + StrCreateTimeStamp + ",\n StrCreateUser=" + StrCreateUser
				+ ",\n StrMaintTimeStamp=" + StrMaintTimeStamp + ",\n StrMaintUser=" + StrMaintUser
				+ ",\n StrVerifyTimeStamp=" + StrVerifyTimeStamp + ",\n StrVerifyUser=" + StrVerifyUser
				+ ",\n StrPymtEndDate=" + StrPymtEndDate + ",\n StrRecurrPymtInd=" + StrRecurrPymtInd
				+ ",\n StrUnmhInd=" + StrUnmhInd + ",\n StrMicrofilm=" + StrMicrofilm + ",\n StrProgCode=" + StrProgCode
				+ ",\n StrAgentCode=" + StrAgentCode + ",\n StrCustId=" + StrCustId + ",\n StrUtilType=" + StrUtilType
				+ ",\n StrExBankCode=" + StrExBankCode + ",\n StrExBranchCode=" + StrExBranchCode + ",\n StrBankAbbrev="
				+ StrBankAbbrev + ",\n StrBankPayAmnt=" + StrBankPayAmnt + ",\n StrHandphone=" + StrHandphone
				+ ",\n StrPymtMode=" + StrPymtMode + ",\n StrRegExpDate=" + StrRegExpDate + ",\n StrStatMaintDte="
				+ StrStatMaintDte + ",\n StrXferInd=" + StrXferInd + ",\n StrEnrlAcdte=" + StrEnrlAcdte
				+ ",\n StrEnrlUsrid=" + StrEnrlUsrid + ",\n StrAcctOrg=" + StrAcctOrg + ",\n StrAcctNmbr=" + StrAcctNmbr
				+ ",\n StrEcscusUniqueNo=" + StrEcscusUniqueNo + ",\n StrReserveData=" + StrReserveData + "]";
	}

}

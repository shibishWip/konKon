package com.citi.cards.abps.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.citi.cards.abps.entity.pojo.MerchantsEntity;
import com.citi.cards.abps.entity.pojo.MerchantsListEntity;
import com.citi.cards.abps.entity.pojo.MerchantsPKClass;
import com.citi.cards.abps.repository.MerchantsRepository;
import com.citi.cards.abps.service.MerchantsService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class MerchantsServiceImpl implements MerchantsService {
	@Autowired
	MerchantsRepository MerchantsRep = new MerchantsRepository();
	@Autowired
	Environment env;

	@Override
	public List<MerchantsListEntity> find(Map conditions) throws Exception {
		ObjectMapper objM = new ObjectMapper();
		String retstr = objM.writeValueAsString(conditions);
		MerchantsEntity obj = objM.readValue(retstr, MerchantsEntity.class);

		return MerchantsRep.findByConditions(conditions);
	}

	@Override
	public MerchantsEntity enquiry(short StrMerchOrg, BigDecimal StrMerchNmbr) throws Exception {
		MerchantsEntity primarykey = getMercClass(StrMerchOrg, StrMerchNmbr);
		return MerchantsRep.enquiry(primarykey);
	}

	public MerchantsEntity getMercClass(short StrMerchOrg, BigDecimal StrMerchNmbr) {
		MerchantsEntity pkClass = new MerchantsEntity();
		pkClass.setStrMerchOrg(StrMerchOrg);
		pkClass.setStrMerchNmbr(StrMerchNmbr);
		return pkClass;
	}

	public MerchantsPKClass getPKClass(short StrMerchOrg, BigDecimal StrMerchNmbr) {
		MerchantsPKClass pkClass = new MerchantsPKClass();
		pkClass.setStrMerchOrg(StrMerchOrg);
		pkClass.setStrMerchNmbr(StrMerchNmbr);
		return pkClass;
	}

	@Override
	public void update(MerchantsEntity bean) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void save(MerchantsEntity bean) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(MerchantsEntity bean) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean exist(MerchantsEntity bean) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public MerchantsEntity enquiry(BigDecimal merchantNmbr) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}

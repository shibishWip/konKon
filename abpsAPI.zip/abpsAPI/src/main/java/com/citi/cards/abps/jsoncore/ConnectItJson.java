/**
 * 
 */
package com.citi.cards.abps.jsoncore;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citi.cards.abps.entity.ExceptionEntity;
import com.citi.cards.abps.entity.pojo.AccountsEntity;

/**
 * @author ag07254
 *
 */

@Component
public class ConnectItJson {
	@Autowired
	JsonCardRequest jsonCardRequest;
	private final static String url = "https://rusadvipa.gcb-us-hosts.citicorp.com:10153/v1/sg/card/abps/abpsCardsInq";

	private static String respJson;

	public static String fullPathOfKeyStore() {
		java.net.URL CertPath = ConnectItJson.class.getClassLoader().getResource("g2c_dev_usr.jks");
		File f1 = null;
		try {
			f1 = new File(CertPath.toURI());
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return f1.getAbsolutePath();
	}

	public String getJsonService(AccountsEntity entityObj) throws Exception {

		String jsonReq = jsonCardRequest.abpsCardsInqRequest(entityObj);
		try {

			if (jsonReq != null) {
				respJson = sslConnect(jsonReq);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return respJson;
	}

	public static String sslConnect(String body) throws KeyStoreException {

		final char[] PASSWORD = "gpdusr".toCharArray();
		final KeyStore keyStore = KeyStore.getInstance("JKS");
		// System.setProperty("javax.net.debug","all");

		try (final InputStream is = new FileInputStream(fullPathOfKeyStore())) {
			keyStore.load(is, PASSWORD);

			final SSLContext sslContext = SSLContexts.custom().useProtocol("TLS").loadTrustMaterial(keyStore)
					.loadKeyMaterial(keyStore, PASSWORD).build();

			/*
			 * SSLContext sslContext = SSLContexts.custom()
			 * .loadKeyMaterial(keyStore, JKS_PASSWORD) .build();
			 */

			// Prepare the HTTPClient.
			HttpClientBuilder builder = HttpClientBuilder.create();
			SSLConnectionSocketFactory sslConnectionFactory = new SSLConnectionSocketFactory(sslContext);
			builder.setSSLSocketFactory(sslConnectionFactory);
			Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory> create()
					.register("https", sslConnectionFactory).register("http", new PlainConnectionSocketFactory())
					.build();
			HttpClientConnectionManager ccm = new BasicHttpClientConnectionManager(registry);
			builder.setConnectionManager(ccm);

			// Perform a sample HTTP request.
			try (CloseableHttpClient httpClient = builder.build()) {

				HttpPost httppost = new HttpPost(url);
				StringEntity params = new StringEntity(body);
				httppost.addHeader("content-type", "application/json");
				httppost.setEntity(params);

				try (CloseableHttpResponse response = httpClient.execute(httppost)) {
					HttpEntity entity = response.getEntity();
					if (entity != null) {
						respJson = EntityUtils.toString(entity);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException | KeyStoreException | KeyManagementException | UnrecoverableKeyException
				| NoSuchAlgorithmException | CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return respJson;

	}

	protected static ExceptionEntity genExceptionEntity(String errCode, String errType, String message) {
		ExceptionEntity ee = new ExceptionEntity();
		ee.setErrCode(errCode);
		ee.setErrType(errType);
		ee.setMessage(message);

		return ee;
	}

	public static Map<String, Object> genRetMap(Map<String, Object> map, Object obj) {
		map.put("responseBody", obj);
		return map;
	}

}

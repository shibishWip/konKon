
package com.citi.cards.abps.json.response;

import org.springframework.stereotype.Component;

@Component
public class UtlCwsMessageInterface802 {

	private Mca80HeaderOutData mca80_header_out_data;

	private Euica80OutArea euica80_out_area;

	public Mca80HeaderOutData getMca80_header_out_data() {
		return mca80_header_out_data;
	}

	public void setMca80_header_out_data(Mca80HeaderOutData mca80_header_out_data) {
		this.mca80_header_out_data = mca80_header_out_data;
	}

	public Euica80OutArea getEuica80_out_area() {
		return euica80_out_area;
	}

	public void setEuica80_out_area(Euica80OutArea euica80_out_area) {
		this.euica80_out_area = euica80_out_area;
	}

	@Override
	public String toString() {
		return "ClassPojo [mca80_header_out_data = " + mca80_header_out_data + ", euica80_out_area = "
				+ euica80_out_area + "]";
	}
}

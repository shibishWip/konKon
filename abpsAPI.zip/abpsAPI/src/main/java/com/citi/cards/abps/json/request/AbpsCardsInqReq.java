package com.citi.cards.abps.json.request;

import org.springframework.stereotype.Component;

@Component
public class AbpsCardsInqReq {
	private EUACA024Operation EUACA024Operation;

	public EUACA024Operation getEUACA024Operation() {
		return EUACA024Operation;
	}

	public void setEUACA024Operation(EUACA024Operation EUACA024Operation) {
		this.EUACA024Operation = EUACA024Operation;
	}

	@Override
	public String toString() {
		return "ClassPojo [EUACA024Operation = " + EUACA024Operation + "]";
	}
}
